// background.js - Neural Phantom 4.1

let globalLogs = [];

// ── 参数追踪存储 ──
const paramTraceStore = [];   // 所有捕获到的请求参数事件
const MAX_PARAM_TRACES = 1000;

// ── 参数来源交叉匹配引擎 ──
const ParamSourceAnalyzer = {
    // 在响应体缓存中搜索某个值
    searchInResponses: function(value) {
        if (!value || value.length < 3) return [];
        const results = [];
        for (const log of globalLogs) {
            // 搜索 URL
            if (log.url && log.url.includes(value)) {
                results.push({ source: 'RESPONSE_URL', url: log.url, time: log.time, requestId: log.id });
            }
            // 搜索响应体缓存
            const cached = contentCache.get(log.id);
            if (cached) {
                const body = cached.base64Encoded ? (() => { try { return atob(cached.body); } catch(e) { return cached.body; } })() : cached.body;
                if (body && body.includes(value)) {
                    const idx = body.indexOf(value);
                    const preview = body.substring(Math.max(0, idx - 40), Math.min(body.length, idx + value.length + 40)).replace(/[\n\r]/g, ' ');
                    results.push({ source: 'RESPONSE_BODY', url: log.url, time: log.time, requestId: log.id, preview });
                }
            }
            // 搜索响应头
            if (log.responseHeaders) {
                for (const [k, v] of Object.entries(log.responseHeaders)) {
                    if (String(v).includes(value)) {
                        results.push({ source: 'RESPONSE_HEADER', url: log.url, time: log.time, requestId: log.id, headerKey: k, preview: `${k}: ${v}` });
                    }
                }
            }
        }
        return results;
    },

    // 分析单个参数的来源
    analyze: function(paramKey, paramValue) {
        if (!paramValue || paramValue.length < 2) return null;
        const val = String(paramValue);

        // 1. 先在响应体里找
        const fromResponse = this.searchInResponses(val);

        // 2. 再在其他请求的 URL/body 里找（检查是否从别的请求透传来的）
        const fromRequest = [];
        for (const trace of paramTraceStore) {
            for (const [k, v] of Object.entries(trace.params || {})) {
                if (k !== paramKey && String(v) === val) {
                    fromRequest.push({ source: 'OTHER_REQUEST_PARAM', paramKey: k, url: trace.url, method: trace.method, time: trace.time });
                }
            }
        }

        // 3. 在加密拦截里找（是否是加密函数的输出）
        // 这部分依赖 inject.js 侧的 CRYPTO_REPORT，这里主要做响应来源分析

        const verdict = fromResponse.length > 0 ? 'FROM_RESPONSE'
            : fromRequest.length > 0 ? 'FROM_REQUEST'
            : 'JS_COMPUTED';

        return {
            key: paramKey,
            value: val.substring(0, 100),
            verdict,           // FROM_RESPONSE | FROM_REQUEST | JS_COMPUTED
            fromResponse: fromResponse.slice(0, 5),
            fromRequest: fromRequest.slice(0, 5),
        };
    },

    // 批量分析一次请求里的所有参数
    analyzeTrace: function(trace) {
        const results = [];
        for (const [k, v] of Object.entries(trace.params || {})) {
            const r = this.analyze(k, v);
            if (r) results.push(r);
        }
        return results;
    }
};
let userFilters = [];
let contentCache = new Map();
const MAX_CACHE_SIZE = 500;

// requestId → debuggee+meta，等 loadingFinished 时取 body
const pendingDebuggees = new Map();

// ── Keep-alive：防止 AI 长请求期间 Service Worker 休眠 ──
chrome.runtime.onConnect.addListener((port) => {
    if (port.name === 'phantom-keepalive') {
        port.onDisconnect.addListener(() => {});
    }
});

// ── HAR 录制 ──
let harRecording = false;
let harSession = [];   // 录制期间的完整条目
let harStartTime = null;

// ── 多标签统一抓包：记录所有已附加 debugger 的 tabId ──
let attachedTabs = new Set();

// ── WebSocket 日志独立存储 ──
let wsLogs = [];
const MAX_WS_LOGS = 200;

// ── 收藏请求存储 ──
let starredIds = new Set();

// [1] 初始化：加载存储的过滤规则 + 收藏列表
chrome.storage.local.get(['userFilters', 'starredIds'], (res) => {
    if (res.userFilters) userFilters = res.userFilters;
    if (res.starredIds) starredIds = new Set(res.starredIds);
});

// [2] 密钥猎手：扩展版 — 覆盖更多密钥类型 + 敏感字段检测
const KeyHunter = {
    patterns: {
        "OpenAI_Key":       /sk-[a-zA-Z0-9]{48}/g,
        "OpenAI_Proj_Key":  /sk-proj-[a-zA-Z0-9_-]{50,}/g,
        "Anthropic_Key":    /sk-ant-[a-zA-Z0-9_-]{90,}/g,
        "Google_API":       /AIza[0-9A-Za-z-_]{35}/g,
        "Google_OAuth":     /ya29\.[0-9A-Za-z_-]{60,}/g,
        "AWS_Access_Key":   /AKIA[0-9A-Z]{16}/g,
        "AWS_Secret":       /(?<![A-Za-z0-9])[A-Za-z0-9\/+]{40}(?![A-Za-z0-9\/+])/g,
        "GitHub_Token":     /ghp_[a-zA-Z0-9]{36}/g,
        "GitHub_App":       /ghs_[a-zA-Z0-9]{36}/g,
        "Stripe_Key":       /sk_live_[0-9a-zA-Z]{24}/g,
        "Stripe_PK":        /pk_live_[0-9a-zA-Z]{24}/g,
        "JWT_Token":        /ey[a-zA-Z0-9_-]{10,}\.ey[a-zA-Z0-9_-]{10,}/g,
        "Private_Key_PEM":  /-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----/g,
        "WeChat_AppSecret": /[0-9a-f]{32}/g,
    },
    // 敏感 JSON 字段名检测
    sensitiveFields: [
        'password','passwd','secret','token','api_key','apikey','access_token',
        'refresh_token','private_key','credential','auth','authorization',
        'x-api-key','session','cookie','ssn','id_card','phone','mobile',
        'credit_card','card_number','cvv','bank_account'
    ],
    scan: function(text) {
        let findings = [];
        for (let [name, regex] of Object.entries(this.patterns)) {
            // AWS Secret 误报率高，跳过空白上下文
            if (name === 'AWS_Secret' && !text.includes('AWS') && !text.includes('amazon')) continue;
            // WeChat AppSecret 仅当上下文有明显标志时才报
            if (name === 'WeChat_AppSecret' && !text.toLowerCase().includes('wechat') && !text.toLowerCase().includes('appid')) continue;
            regex.lastIndex = 0;
            const matches = text.match(regex);
            if (matches) {
                findings.push({ type: name, keys: [...new Set(matches)] });
            }
        }
        return findings;
    },
    scanFields: function(text) {
        // 尝试解析 JSON，检查敏感字段
        let findings = [];
        try {
            const flattenKeys = (obj, prefix = '') => {
                if (typeof obj !== 'object' || obj === null) return;
                for (const [k, v] of Object.entries(obj)) {
                    const fullKey = prefix ? `${prefix}.${k}` : k;
                    const keyLow = k.toLowerCase().replace(/[-_]/g, '');
                    if (this.sensitiveFields.some(f => keyLow.includes(f.replace(/[-_]/g, '')))) {
                        if (v && String(v).length > 3) {
                            findings.push({ field: fullKey, preview: String(v).substring(0, 30) });
                        }
                    }
                    if (typeof v === 'object') flattenKeys(v, fullKey);
                }
            };
            const json = JSON.parse(text);
            flattenKeys(json);
        } catch (e) {}
        return findings;
    }
};

// [3] Tracer Engine: 全流量内容检索
const TracerEngine = {
    findValueSource: function(targetValue, logs) {
        if (!targetValue) return [];
        const results = [];
        logs.forEach(log => {
            try {
                let bodyContent = log.content;
                if (!bodyContent && contentCache.has(log.id)) {
                    const cached = contentCache.get(log.id);
                    bodyContent = cached.base64Encoded ? atob(cached.body) : cached.body;
                }
                if (bodyContent && typeof bodyContent === 'string' && bodyContent.includes(targetValue)) {
                    results.push({
                        type: 'RESPONSE_BODY',
                        url: log.url,
                        requestId: log.id,
                        time: log.time,
                        preview: this.getPreview(bodyContent, targetValue)
                    });
                }
                if (log.url.includes(targetValue)) {
                    results.push({
                        type: 'REQUEST_URL',
                        url: log.url,
                        requestId: log.id,
                        time: log.time,
                        preview: log.url
                    });
                }
            } catch (e) {}
        });
        return results;
    },
    getPreview: function(content, target) {
        const index = content.indexOf(target);
        const start = Math.max(0, index - 40);
        const end = Math.min(content.length, index + target.length + 40);
        let preview = content.substring(start, end).replace(/[\n\r]/g, ' ');
        if (start > 0) preview = "..." + preview;
        if (end < content.length) preview = preview + "...";
        return preview;
    }
};

// [4] Debugger 监听：捕获 POST 载荷与响应正文
chrome.debugger.onEvent.addListener(async (source, method, params) => {
    const { tabId } = source;
    const debuggee = { tabId };
    if (source.targetId) debuggee.targetId = source.targetId;

    // 适配 iframe 注入
    if (method === 'Target.attachedToTarget') {
        try {
            const tid = params.targetInfo?.targetId || params.sessionId;
            if (tid) chrome.debugger.sendCommand({ tabId, targetId: tid }, 'Network.enable');
        } catch (e) {}
    }

    // A. 抓取请求发出瞬间 (包含 POST Payload)
    if (method === 'Network.requestWillBeSent') {
        const { request, requestId } = params;
        updateLogs({
            id: requestId,
            tabId: tabId,
            targetId: source.targetId,
            url: request.url,
            method: request.method,
            postData: request.postData || '',
            requestHeaders: request.headers || {},
            status: 'Pending',
            time: new Date().toLocaleTimeString(),
            startTime: Date.now(),
            type: 'PENDING'
        });
    }

    // B. 抓取响应完成时刻
    if (method === 'Network.responseReceived') {
        const { response, requestId } = params;
        const url = response.url;
        const mime = response.mimeType;

        // 类型判定逻辑
        let type = 'OTHER';
        if (mime.includes('javascript') || url.includes('.js')) type = 'SCRIPT';
        else if (mime.includes('json')) type = 'XHR';
        else if (mime.includes('image')) type = 'IMAGE';
        else if (mime.includes('css')) type = 'CSS';
        else if (url.includes('.m3u8') || mime.includes('mpegurl')) type = 'MEDIA-M3U8';
        else if (mime.includes('video') || mime.includes('audio')) type = 'MEDIA';

        // GraphQL 检测
        const isGraphQL = url.includes('/graphql') || url.includes('/gql') ||
            response.requestHeaders?.['content-type']?.includes('application/json');

        // 只记录元数据，响应体等 loadingFinished 再取（那时才真正可读）
        updateLogs({
            id: requestId,
            status: response.status,
            type: type,
            url: url,
            isGraphQL: isGraphQL,
            responseTime: Date.now(),
            mimeType: mime,
            responseHeaders: response.headers || {},
        });
        // 把 debuggee 存起来供 loadingFinished 使用
        pendingDebuggees.set(requestId, { debuggee, tabId, type, url, isGraphQL, mime });
    }

    // B2. 响应体真正就绪时刻 — 在这里取 body，几乎不会失败
    if (method === 'Network.loadingFinished') {
        const { requestId } = params;
        const meta = pendingDebuggees.get(requestId);
        if (!meta) return;
        pendingDebuggees.delete(requestId);
        fetchAndCacheBody(meta.debuggee, requestId, meta);
    }

    // B3. 请求失败时标记
    if (method === 'Network.loadingFailed') {
        const { requestId, errorText, canceled } = params;
        const status = canceled ? 'Canceled' : 'Failed';
        updateLogs({ id: requestId, status, errorText: errorText || '' });
        const meta = pendingDebuggees.get(requestId);
        pendingDebuggees.delete(requestId);
        // 直接缓存失败信息，避免后续 getResponseBody 无效调用
        if (meta) {
            const reason = errorText || (canceled ? '请求被取消' : '网络请求失败');
            contentCache.set(requestId, {
                body: `// [Phantom] 请求失败，无响应体
// 状态: ${status}
// 原因: ${reason}
// URL: ${meta.url}`,
                base64Encoded: false,
                fetchFailed: true,
                requestFailed: true
            });
            chrome.runtime.sendMessage({ action: 'BODY_READY', requestId }).catch(() => {});
        }
    }

    // C. WebSocket 抓包
    if (method === 'Network.webSocketCreated') {
        wsLogs.push({ id: params.requestId, url: params.url, tabId, frames: [], time: new Date().toLocaleTimeString(), type: 'WS_CREATED' });
        chrome.runtime.sendMessage({ action: 'WS_EVENT', event: 'created', requestId: params.requestId, url: params.url, tabId }).catch(() => {});
    }
    if (method === 'Network.webSocketFrameSent') {
        const entry = wsLogs.find(w => w.id === params.requestId);
        const frame = { dir: 'SENT', data: params.response?.payloadData, time: new Date().toLocaleTimeString() };
        if (entry) entry.frames.push(frame);
        if (wsLogs.length > MAX_WS_LOGS) wsLogs.shift();
        chrome.runtime.sendMessage({ action: 'WS_FRAME', dir: 'SENT', requestId: params.requestId, frame }).catch(() => {});
    }
    if (method === 'Network.webSocketFrameReceived') {
        const entry = wsLogs.find(w => w.id === params.requestId);
        const frame = { dir: 'RECV', data: params.response?.payloadData, time: new Date().toLocaleTimeString() };
        if (entry) entry.frames.push(frame);
        chrome.runtime.sendMessage({ action: 'WS_FRAME', dir: 'RECV', requestId: params.requestId, frame }).catch(() => {});
    }
    if (method === 'Network.webSocketClosed') {
        chrome.runtime.sendMessage({ action: 'WS_EVENT', event: 'closed', requestId: params.requestId }).catch(() => {});
    }
});

// [4b] 响应体抓取与缓存 — 在 loadingFinished 后调用，成功率接近 100%
function fetchAndCacheBody(debuggee, requestId, meta) {
    const { tabId, type, url, isGraphQL } = meta;

    // 跳过纯二进制大文件（视频流本身不需要缓存文本）
    const skipTypes = ['IMAGE', 'MEDIA', 'OTHER'];
    // 图片保留（可能需要 base64 预览），其余大型二进制跳过
    const skipBinary = type === 'MEDIA';
    if (skipBinary) return;

    // debugger 失败 fallback：延迟重试（给浏览器时间准备缓存数据，避免注入fetch造成递归）
    const fetchFallback = () => {
        const delays = [300, 800, 2000]; // 三次延迟重试
        let idx = 0;
        const retryDebugger = () => {
            chrome.debugger.sendCommand(debuggee, 'Network.getResponseBody', { requestId }, (res) => {
                const err = chrome.runtime.lastError;
                if (!err && res && res.body != null) {
                    // 延迟重试成功
                    contentCache.set(requestId, { body: res.body, base64Encoded: res.base64Encoded });
                    if (contentCache.size > MAX_CACHE_SIZE) contentCache.delete(contentCache.keys().next().value);
                    let bodyText;
                    try { bodyText = res.base64Encoded ? atob(res.body) : res.body; }
                    catch(e) { bodyText = res.body; }
                    handleBodyText(bodyText, res.base64Encoded);
                    return;
                }
                if (idx < delays.length) {
                    setTimeout(retryDebugger, delays[idx++]);
                } else {
                    // 全部失败，标记为不可用
                    contentCache.set(requestId, {
                        body: `// [Phantom] 响应体不可用
// 原因: 缓存命中请求，debugger 无法读取响应体
// URL: ${url}
// 提示: 禁用浏览器缓存后刷新页面可解决此问题`,
                        base64Encoded: false,
                        fetchFailed: true
                    });
                    chrome.runtime.sendMessage({ action: 'BODY_READY', requestId }).catch(() => {});
                }
            });
        };
        setTimeout(retryDebugger, delays[idx++]);
    };

    const attempt = (retries) => {
        chrome.debugger.sendCommand(debuggee, 'Network.getResponseBody', { requestId }, (res) => {
            const err = chrome.runtime.lastError;

            if (err || !res) {
                if (retries > 0) {
                    setTimeout(() => attempt(retries - 1), 150);
                } else {
                    fetchFallback();
                }
                return;
            }

            // res.body 可以是空字符串（合法的空响应），只排除 null/undefined
            if (res.body == null) {
                contentCache.set(requestId, { body: '', base64Encoded: false, empty: true });
                return;
            }

            // 写入缓存
            contentCache.set(requestId, { body: res.body, base64Encoded: res.base64Encoded });
            if (contentCache.size > MAX_CACHE_SIZE) {
                contentCache.delete(contentCache.keys().next().value);
            }

            // 解码后进入统一处理
            let bodyText;
            if (res.base64Encoded) {
                try {
                    const raw = atob(res.body);
                    // 检测压缩文件魔数
                    const b0 = raw.charCodeAt(0), b1 = raw.charCodeAt(1), b2 = raw.charCodeAt(2);
                    const isGzip   = b0 === 0x1f && b1 === 0x8b;
                    const isBrotli = b0 === 0xce || b0 === 0xff; // Brotli 无固定魔数，但通常首字节特征
                    const isZstd   = b0 === 0x28 && b1 === 0xb5 && b2 === 0x2f;
                    if (isGzip || isZstd) {
                        // 二进制压缩内容，浏览器通常会自动解压，这里拿到的说明是原始流
                        const ext = url.split('?')[0].split('.').pop().toLowerCase();
                        contentCache.set(requestId, {
                            body: `// [Phantom] 压缩响应体 (${isGzip ? 'gzip' : 'zstd'})
// 文件: ${url}
// 大小: ${raw.length} bytes (base64 decoded)
// 提示: 浏览器已自动解压此文件供页面使用。
// 如需查看源码，请在 Network 面板中点击该资源。`,
                            base64Encoded: false,
                            compressed: true
                        });
                        handleBodyText(raw, true);
                        return;
                    }
                    bodyText = raw;
                } catch(e) { bodyText = res.body; }
            } else {
                bodyText = res.body;
            }
            handleBodyText(bodyText, res.base64Encoded);
        });
    };

    // 统一处理 body 文本：审计、通知、HAR、Schema、告警
    const handleBodyText = (bodyText, base64Encoded) => {
        // 写入缓存（fetch fallback 时 base64Encoded 为 false）
        if (!contentCache.has(requestId)) {
            contentCache.set(requestId, { body: bodyText, base64Encoded: !!base64Encoded });
            if (contentCache.size > MAX_CACHE_SIZE) {
                contentCache.delete(contentCache.keys().next().value);
            }
        }

        // 自动审计：密钥嗅探
        const foundKeys = KeyHunter.scan(bodyText);
        if (foundKeys.length > 0) {
            chrome.runtime.sendMessage({ action: 'KEY_FOUND', url, keys: foundKeys }).catch(() => {});
        }

        // 自动审计：敏感字段（仅 JSON）
        if (type === 'XHR') {
            const sensitiveFields = KeyHunter.scanFields(bodyText);
            if (sensitiveFields.length > 0) {
                chrome.runtime.sendMessage({ action: 'SENSITIVE_FIELD_FOUND', url, fields: sensitiveFields }).catch(() => {});
            }
            if (isGraphQL) {
                try {
                    const gqlData = JSON.parse(bodyText);
                    const opName = gqlData?.data ? Object.keys(gqlData.data)[0] : null;
                    updateLogs({ id: requestId, gqlOperation: opName });
                } catch (e) {}
            }
        }

        // M3U8 广告净化
        if (type === 'MEDIA-M3U8') {
            const { cleaned, hasAds } = cleanM3u8(bodyText);
            if (hasAds) {
                const dataUrl = `data:application/vnd.apple.mpegurl;base64,${btoa(unescape(encodeURIComponent(cleaned)))}`;
                chrome.tabs.sendMessage(tabId, { action: 'REDIRECT_M3U8', original: url, clean: dataUrl }).catch(() => {});
            }
        }

        // 通知面板：body 已就绪
        chrome.runtime.sendMessage({ action: 'BODY_READY', requestId }).catch(() => {});

        // HAR 录制
        if (harRecording) {
            const logEntry = globalLogs.find(l => l.id === requestId);
            if (logEntry) harSession.push({ ...logEntry, content: bodyText });
        }

        // Schema 变更检测
        if (type === 'XHR') {
            try {
                const parsed = JSON.parse(bodyText);
                const newSchema = extractSchema(parsed);
                const urlKey = url.replace(/[?#].*/, '').replace(/\/\d+\//g, '/{id}/');
                if (schemaSnapshots.has(urlKey)) {
                    const changes = diffSchema(schemaSnapshots.get(urlKey), newSchema);
                    if (changes.length > 0) {
                        chrome.runtime.sendMessage({ action: 'SCHEMA_CHANGED', url, changes }).catch(() => {});
                    }
                } else {
                    schemaSnapshots.set(urlKey, newSchema);
                }
            } catch (e) {}
        }

        // 条件告警检测
        const logEntry = globalLogs.find(l => l.id === requestId);
        if (logEntry) {
            logEntry.content = bodyText;
            checkAlertRules(logEntry);
        }
    };

    attempt(2); // 最多尝试 3 次（失败后自动 fetch fallback）
}

// ════════════════════════════════════════════════
// [HAR] 标准 HAR 1.2 构建 / 解析 / 回放
// ════════════════════════════════════════════════
function buildHAR(entries) {
    return {
        log: {
            version: '1.2',
            creator: { name: 'Neural Phantom', version: '4.1' },
            pages: [{
                startedDateTime: new Date(harStartTime).toISOString(),
                id: 'page_1', title: 'Recorded Session',
                pageTimings: { onContentLoad: 0, onLoad: 0 }
            }],
            entries: entries.map(e => ({
                startedDateTime: new Date(e.startTime || harStartTime).toISOString(),
                time: e.duration || 0,
                request: {
                    method: e.method || 'GET',
                    url: e.url,
                    httpVersion: 'HTTP/1.1',
                    headers: Object.entries(e.requestHeaders || {}).map(([k, v]) => ({ name: k, value: v })),
                    queryString: parseQueryString(e.url),
                    cookies: [],
                    headersSize: -1,
                    bodySize: e.postData ? e.postData.length : 0,
                    postData: e.postData ? { mimeType: 'application/json', text: e.postData } : undefined
                },
                response: {
                    status: e.status || 200,
                    statusText: String(e.status || 200),
                    httpVersion: 'HTTP/1.1',
                    headers: [],
                    cookies: [],
                    content: {
                        size: e.content ? e.content.length : 0,
                        mimeType: mimeFromType(e.type),
                        text: e.content || ''
                    },
                    redirectURL: '',
                    headersSize: -1,
                    bodySize: e.content ? e.content.length : -1
                },
                cache: {},
                timings: { send: 0, wait: e.duration || 0, receive: 0 },
                pageref: 'page_1'
            }))
        }
    };
}

function parseQueryString(url) {
    try {
        const u = new URL(url);
        return [...u.searchParams.entries()].map(([n, v]) => ({ name: n, value: v }));
    } catch (e) { return []; }
}

function mimeFromType(type) {
    const m = { XHR: 'application/json', SCRIPT: 'text/javascript', CSS: 'text/css', IMAGE: 'image/png', 'MEDIA-M3U8': 'application/vnd.apple.mpegurl' };
    return m[type] || 'text/plain';
}

function parseHAREntries(harText) {
    const har = JSON.parse(harText);
    return (har.log?.entries || []).map(e => ({
        url: e.request.url,
        method: e.request.method,
        postData: e.request.postData?.text || '',
        status: e.response.status,
        content: e.response.content?.text || '',
        duration: e.time || 0,
        requestHeaders: Object.fromEntries((e.request.headers || []).map(h => [h.name, h.value]))
    }));
}

async function replayHAR(entries, tabId) {
    if (!tabId) return;
    let delay = 0;
    for (const entry of entries) {
        setTimeout(() => {
            chrome.tabs.sendMessage(tabId, {
                action: 'HAR_REPLAY_REQUEST',
                url: entry.url, method: entry.method, body: entry.postData,
                headers: entry.requestHeaders
            }).catch(() => {});
        }, delay);
        delay += 50; // 50ms 间隔，避免并发洪泛
    }
}

// ════════════════════════════════════════════════
// [SCHEMA] 响应体 Schema 快照与变更检测
// ════════════════════════════════════════════════
const schemaSnapshots = new Map(); // url pattern → schema

function extractSchema(obj, depth = 0) {
    if (depth > 5) return '...';
    if (obj === null) return 'null';
    if (Array.isArray(obj)) return obj.length > 0 ? [extractSchema(obj[0], depth + 1)] : [];
    if (typeof obj === 'object') {
        const schema = {};
        for (const [k, v] of Object.entries(obj)) {
            schema[k] = extractSchema(v, depth + 1);
        }
        return schema;
    }
    return typeof obj;
}

function diffSchema(oldS, newS, path = '') {
    const changes = [];
    const allKeys = new Set([...Object.keys(oldS || {}), ...Object.keys(newS || {})]);
    for (const k of allKeys) {
        const fullPath = path ? `${path}.${k}` : k;
        if (!(k in (oldS || {}))) { changes.push({ type: 'ADDED', path: fullPath, newType: typeof newS[k] }); continue; }
        if (!(k in (newS || {}))) { changes.push({ type: 'REMOVED', path: fullPath, oldType: typeof oldS[k] }); continue; }
        const ot = Array.isArray(oldS[k]) ? 'array' : typeof oldS[k];
        const nt = Array.isArray(newS[k]) ? 'array' : typeof newS[k];
        if (ot !== nt) { changes.push({ type: 'TYPE_CHANGED', path: fullPath, oldType: ot, newType: nt }); continue; }
        if (ot === 'object' && nt === 'object') {
            changes.push(...diffSchema(oldS[k], newS[k], fullPath));
        }
    }
    return changes;
}

// ════════════════════════════════════════════════
// [ALERT] 条件告警引擎
// ════════════════════════════════════════════════
let alertRules = [];
chrome.storage.local.get(['alertRules'], r => { if (r.alertRules) alertRules = r.alertRules; });

function checkAlertRules(log) {
    for (const rule of alertRules) {
        if (!rule.enabled) continue;
        let hit = false;
        if (rule.type === 'STATUS' && log.status == rule.value) hit = true;
        if (rule.type === 'DURATION' && log.duration >= Number(rule.value)) hit = true;
        if (rule.type === 'URL_CONTAINS' && log.url.includes(rule.value)) hit = true;
        if (rule.type === 'BODY_CONTAINS' && log.content?.includes(rule.value)) hit = true;
        if (hit) {
            chrome.runtime.sendMessage({ action: 'ALERT_HIT', rule, log }).catch(() => {});
            // 桌面通知
            chrome.notifications?.create({
                type: 'basic',
                iconUrl: 'icons/icon48.png',
                title: `🔔 Phantom 告警: ${rule.name || rule.type}`,
                message: `${log.method} ${log.url.substring(0, 80)}`
            });
        }
    }
}

// ════════════════════════════════════════════════
// [DASHBOARD] 实时流量统计（供前端折线图使用）
// ════════════════════════════════════════════════
const trafficTimeline = []; // { ts, count, errors, totalMs }
let _bucketTs = 0;
let _bucketCount = 0;
let _bucketErrors = 0;
let _bucketMs = 0;

function recordTrafficBucket(log) {
    const now = Math.floor(Date.now() / 1000) * 1000; // 秒级 bucket
    if (now !== _bucketTs) {
        if (_bucketTs > 0) trafficTimeline.push({ ts: _bucketTs, count: _bucketCount, errors: _bucketErrors, avgMs: _bucketCount ? Math.round(_bucketMs / _bucketCount) : 0 });
        _bucketTs = now; _bucketCount = 0; _bucketErrors = 0; _bucketMs = 0;
        if (trafficTimeline.length > 120) trafficTimeline.shift(); // 保留最近 2 分钟
    }
    _bucketCount++;
    if (log.status >= 400) _bucketErrors++;
    if (log.duration) _bucketMs += log.duration;
}

// ════════════════════════════════════════════════
// [PENTEST] 安全头检测 / 漏洞扫描 / 端点提取 / 参数矿工
// ════════════════════════════════════════════════

const SecurityHeaders = {
    required: [
        { name: 'content-security-policy', label: 'Content-Security-Policy', severity: 'high', desc: '防止 XSS 和数据注入攻击' },
        { name: 'strict-transport-security', label: 'Strict-Transport-Security', severity: 'high', desc: '强制 HTTPS 连接' },
        { name: 'x-content-type-options', label: 'X-Content-Type-Options', severity: 'medium', desc: '防止 MIME 类型嗅探' },
        { name: 'x-frame-options', label: 'X-Frame-Options', severity: 'medium', desc: '防止点击劫持' },
        { name: 'x-xss-protection', label: 'X-XSS-Protection', severity: 'low', desc: '浏览器 XSS 过滤器（旧版）' },
        { name: 'referrer-policy', label: 'Referrer-Policy', severity: 'medium', desc: '控制 Referer 信息泄露' },
        { name: 'permissions-policy', label: 'Permissions-Policy', severity: 'medium', desc: '限制浏览器功能访问' },
        { name: 'cross-origin-opener-policy', label: 'Cross-Origin-Opener-Policy', severity: 'low', desc: '跨域窗口隔离' },
        { name: 'cross-origin-resource-policy', label: 'Cross-Origin-Resource-Policy', severity: 'low', desc: '跨域资源隔离' },
    ],
    leaky: ['server', 'x-powered-by', 'x-aspnet-version', 'x-aspnetmvc-version', 'x-generator'],
    scan(logs) {
        const results = [];
        const seen = new Set();
        logs.forEach(log => {
            if (!log.responseHeaders || log.type === 'IMAGE' || log.type === 'CSS') return;
            const h = {};
            for (const [k, v] of Object.entries(log.responseHeaders)) h[k.toLowerCase()] = v;
            const urlKey = log.url.replace(/[?#].*/, '');
            if (seen.has(urlKey)) return;
            seen.add(urlKey);
            const missing = this.required.filter(r => !h[r.name]);
            const leaked = this.leaky.filter(l => h[l]).map(l => ({ header: l, value: h[l] }));
            const score = Math.max(0, 100 - missing.length * 11);
            if (missing.length > 0 || leaked.length > 0) {
                results.push({ url: urlKey, score, missing, leaked, total: this.required.length });
            }
        });
        return results;
    }
};

const VulnScanner = {
    patterns: [
        { id: 'SQL_ERROR', label: 'SQL 错误泄露', severity: 'high', regex: /SQL syntax.*?MySQL|mysql_fetch|pg_query|ORA-\d{5}|SQLite3::query|SQLSTATE\[|microsoft sql native client|unclosed quotation mark/i },
        { id: 'STACK_TRACE', label: '堆栈跟踪泄露', severity: 'high', regex: /Traceback \(most recent|at [\w.$]+\([\w]+\.java:\d+\)|Fatal error.*?on line \d+|System\.NullReferenceException|TypeError:.*?\n\s+at /i },
        { id: 'VERSION_LEAK', label: '版本号泄露', severity: 'medium', regex: /PHP\/[\d.]+|Apache\/[\d.]+|nginx\/[\d.]+|Express\/[\d.]+|ASP\.NET|X-Powered-By/i },
        { id: 'INTERNAL_IP', label: '内网 IP 泄露', severity: 'medium', regex: /(?:^|[^\d])(10\.\d{1,3}\.\d{1,3}\.\d{1,3}|172\.(?:1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3}|192\.168\.\d{1,3}\.\d{1,3})(?:[^\d]|$)/ },
        { id: 'DEBUG_INFO', label: '调试信息泄露', severity: 'medium', regex: /DEBUG\s*=\s*True|DJANGO_SETTINGS_MODULE|Laravel.*?exception|WP_DEBUG|stack_trace|debug_mode/i },
        { id: 'PATH_DISCLOSURE', label: '服务器路径泄露', severity: 'low', regex: /\/(?:home|var|usr|opt|etc|www|srv)\/[\w\-./]{5,}|[A-Z]:\\(?:Users|Windows|inetpub|Program Files)\\[\w\-.\\ ]{5,}/i },
        { id: 'EMAIL_LEAK', label: '邮箱泄露', severity: 'info', regex: /[\w.+-]+@[\w-]+\.[\w.-]{2,}/g },
        { id: 'CORS_WILDCARD', label: 'CORS 通配符', severity: 'medium', regex: /access-control-allow-origin:\s*\*/i },
    ],
    scan(logs) {
        const findings = [];
        logs.forEach(log => {
            let body = log.content;
            if (!body && contentCache.has(log.id)) {
                const c = contentCache.get(log.id);
                try { body = c.base64Encoded ? atob(c.body) : c.body; } catch(e) { return; }
            }
            if (!body || typeof body !== 'string') return;
            // 头部也纳入扫描
            const headerStr = log.responseHeaders ? Object.entries(log.responseHeaders).map(([k,v])=>`${k}: ${v}`).join('\n') : '';
            const fullText = headerStr + '\n' + body;
            this.patterns.forEach(p => {
                p.regex.lastIndex = 0;
                const m = fullText.match(p.regex);
                if (m) {
                    findings.push({
                        id: p.id, label: p.label, severity: p.severity,
                        url: log.url, match: m[0].substring(0, 120),
                        requestId: log.id
                    });
                }
            });
        });
        return findings;
    }
};

const EndpointExtractor = {
    patterns: [
        /["'`](\/api\/[^\s"'`<>{}\[\]|\\^]{2,80})["'`]/g,
        /["'`](\/v[1-9]\d?\/[^\s"'`<>{}\[\]|\\^]{2,80})["'`]/g,
        /["'`](https?:\/\/[^\s"'`<>{}\[\]|\\^]{5,200})["'`]/g,
        /["'`](\/[\w\-]+\/[\w\-]+(?:\/[\w\-]+){0,4})["'`]/g,
        /fetch\(\s*["'`]([^"'`\s]{5,200})["'`]/g,
        /axios\.\w+\(\s*["'`]([^"'`\s]{5,200})["'`]/g,
        /\.(?:get|post|put|delete|patch)\(\s*["'`]([^"'`\s]{5,200})["'`]/gi,
        /url:\s*["'`]([^"'`\s]{5,200})["'`]/g,
    ],
    extract(logs) {
        const endpoints = new Map();
        logs.forEach(log => {
            if (log.type !== 'SCRIPT' && log.type !== 'XHR') return;
            let body = log.content;
            if (!body && contentCache.has(log.id)) {
                const c = contentCache.get(log.id);
                try { body = c.base64Encoded ? atob(c.body) : c.body; } catch(e) { return; }
            }
            if (!body || typeof body !== 'string' || body.length > 5000000) return;
            this.patterns.forEach(re => {
                re.lastIndex = 0;
                let m;
                while ((m = re.exec(body)) !== null) {
                    const ep = m[1];
                    if (ep.includes('{') || ep.includes('<') || ep.length < 4) continue;
                    if (/\.(png|jpg|gif|svg|ico|css|woff|ttf|eot)$/i.test(ep)) continue;
                    if (!endpoints.has(ep)) endpoints.set(ep, { endpoint: ep, sources: [] });
                    const entry = endpoints.get(ep);
                    if (entry.sources.length < 3) entry.sources.push(log.url.substring(0, 100));
                }
            });
        });
        return [...endpoints.values()].slice(0, 500);
    }
};

const ParamMiner = {
    mine(logs) {
        const params = new Map();
        const addParam = (name, value, source, location) => {
            const key = `${location}::${name}`;
            if (!params.has(key)) params.set(key, { name, location, values: new Set(), sources: new Set(), count: 0 });
            const p = params.get(key);
            p.count++;
            if (p.values.size < 5) p.values.add(String(value).substring(0, 80));
            if (p.sources.size < 3) p.sources.add(source.substring(0, 80));
        };
        logs.forEach(log => {
            // URL query params
            try {
                const u = new URL(log.url);
                u.searchParams.forEach((v, k) => addParam(k, v, log.url, 'Query'));
            } catch(e) {}
            // POST body params
            if (log.postData) {
                try {
                    const json = JSON.parse(log.postData);
                    const flatKeys = (obj, prefix) => {
                        if (!obj || typeof obj !== 'object') return;
                        for (const [k, v] of Object.entries(obj)) {
                            const full = prefix ? `${prefix}.${k}` : k;
                            if (typeof v === 'object' && v !== null && !Array.isArray(v)) flatKeys(v, full);
                            else addParam(full, v, log.url, 'Body');
                        }
                    };
                    flatKeys(json, '');
                } catch(e) {
                    // form-urlencoded
                    try {
                        const sp = new URLSearchParams(log.postData);
                        sp.forEach((v, k) => addParam(k, v, log.url, 'Body'));
                    } catch(e2) {}
                }
            }
            // Request headers (interesting ones)
            if (log.requestHeaders) {
                ['authorization','cookie','x-api-key','x-token','x-csrf-token','x-requested-with'].forEach(h => {
                    for (const [k, v] of Object.entries(log.requestHeaders)) {
                        if (k.toLowerCase() === h) addParam(k, v, log.url, 'Header');
                    }
                });
            }
        });
        return [...params.values()]
            .map(p => ({ ...p, values: [...p.values], sources: [...p.sources] }))
            .sort((a, b) => b.count - a.count)
            .slice(0, 500);
    }
};

// [5] M3U8 净化引擎：深度扫描低时长切片
function cleanM3u8(content) {
    const lines = content.split('\n');
    let cleaned = [];
    let hasAds = false;
    let nextLineIsAd = false;
    const strRules = userFilters.filter(f => !f.startsWith('/') || !f.endsWith('/'));

    for (let i = 0; i < lines.length; i++) {
        let line = lines[i].trim();
        if (!line) continue;

        let hitFilter = false;
        
        if (strRules.some(f => line.includes(f))) hitFilter = true;
        if (!hitFilter && (line.includes('ad-system') || line.includes('google_ad') || line.includes('doubleclick'))) {
            hitFilter = true;
        }
        
        // 扩展去广告：匹配时长小于 1.0 秒的切片
        if (line.startsWith('#EXTINF:')) {
            const duration = parseFloat(line.split(':')[1]);
            if (duration < 1.0) {
                nextLineIsAd = true;
            } else {
                nextLineIsAd = false;
            }
        } else if (!line.startsWith('#')) {
            if (nextLineIsAd) {
                hitFilter = true;
                nextLineIsAd = false;
            }
        }

        if (hitFilter) {
            hasAds = true;
            // 跳过可能紧跟在 #EXTINF 后面的 URL 行
            if (line.startsWith('#') && lines[i+1] && !lines[i+1].startsWith('#')) {
                i++;
            }
            continue;
        }
        cleaned.push(lines[i]);
    }
    return { cleaned: cleaned.join('\n'), hasAds: hasAds };
}

// [6] 日志更新与通信中心
function updateLogs(entry) {
    const existingIndex = globalLogs.findIndex(item => item.id === entry.id);
    if (existingIndex !== -1) {
        const existing = globalLogs[existingIndex];
        if (entry.responseTime && existing.startTime) {
            entry.duration = entry.responseTime - existing.startTime;
        }
        globalLogs[existingIndex] = { ...existing, ...entry };
        const updated = globalLogs[existingIndex];
        // 流量统计（仅首次状态更新时计入）
        if (entry.status && entry.status !== 'Pending') recordTrafficBucket(updated);
        chrome.runtime.sendMessage({ action: 'SYNC_LOG', data: updated }).catch(() => {});
    } else {
        globalLogs.unshift(entry);
        if (globalLogs.length > MAX_CACHE_SIZE) globalLogs.pop();
        chrome.runtime.sendMessage({ action: 'SYNC_LOG', data: entry }).catch(() => {});
    }
}

// 图标点击监听
chrome.action.onClicked.addListener((tab) => {
    if (tab && tab.id) {
        chrome.tabs.sendMessage(tab.id, { action: 'TOGGLE_PANEL' }).catch(() => {
            console.log('🍵 茶室提示: 页面尚未加载完成，请刷新网页后再试');
        });
    }
});

// 消息路由中枢 (AI, Tracer, Header伪造, WS, Perf, 收藏 等)
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'FETCH_COOKIES') {
        chrome.cookies.getAll({ url: sender.tab?.url || '' }, (cookies) => {
            sendResponse(cookies || []);
        });
        return true;
    }
    if (msg.action === 'GET_LOGS') { sendResponse(globalLogs); }

    // ── 参数追踪：接收来自 inject.js 的参数事件 ──
    if (msg.action === 'PARAM_TRACE_EVENT') {
        const trace = msg.trace;
        paramTraceStore.unshift(trace);
        if (paramTraceStore.length > MAX_PARAM_TRACES) paramTraceStore.pop();
        // 立即做交叉分析，推送结果给面板
        const analysis = ParamSourceAnalyzer.analyzeTrace(trace);
        if (analysis.length > 0) {
            chrome.runtime.sendMessage({ action: 'PARAM_ANALYZED', trace, analysis }).catch(() => {});
        }
    }

    // ── 主动查询某个参数值的来源 ──
    if (msg.action === 'ANALYZE_PARAM_SOURCE') {
        const result = ParamSourceAnalyzer.analyze(msg.key, msg.value);
        sendResponse({ result });
    }

    // ── 获取所有参数追踪记录 ──
    if (msg.action === 'GET_PARAM_TRACES') {
        sendResponse(paramTraceStore.slice(0, 200));
    }
    if (msg.action === 'CLEAR_LOGS') {
        globalLogs = []; contentCache.clear(); wsLogs = [];
        sendResponse(true);
    }
    // ── HAR 录制控制 ──
    if (msg.action === 'HAR_START') {
        harRecording = true;
        harSession = [];
        harStartTime = Date.now();
        sendResponse({ ok: true, time: harStartTime });
    }
    if (msg.action === 'HAR_STOP') {
        harRecording = false;
        sendResponse({ ok: true, count: harSession.length });
    }
    if (msg.action === 'HAR_EXPORT') {
        // 构造标准 HAR 1.2 格式
        const har = buildHAR(harSession);
        sendResponse({ har });
    }
    if (msg.action === 'HAR_REPLAY') {
        // 回放整个 HAR session（按时序发送所有请求）
        replayHAR(msg.entries, msg.tabId || sender.tab?.id);
        sendResponse({ ok: true });
    }
    if (msg.action === 'HAR_IMPORT') {
        // 导入 HAR 文件内容解析
        try {
            const entries = parseHAREntries(msg.harText);
            sendResponse({ ok: true, entries });
        } catch (e) {
            sendResponse({ error: e.message });
        }
    }
    if (msg.action === 'SEARCH_TRACER') {
        sendResponse({ results: TracerEngine.findValueSource(msg.keyword, globalLogs) });
    }
    if (msg.action === 'FETCH_BODY') {
        const cached = contentCache.get(msg.requestId);
        if (cached) {
            sendResponse(cached);
            return;
        }
        // 缓存未命中：尝试从 debugger 重新拉取响应体
        const logEntry = globalLogs.find(l => l.id === msg.requestId);
        if (logEntry && logEntry.tabId && attachedTabs.has(logEntry.tabId)) {
            const debuggee = { tabId: logEntry.tabId };
            chrome.debugger.sendCommand(debuggee, 'Network.getResponseBody', { requestId: msg.requestId }, (res) => {
                const err = chrome.runtime.lastError;
                if (err || !res || res.body == null) {
                    sendResponse({ error: "Expired" });
                } else {
                    contentCache.set(msg.requestId, { body: res.body, base64Encoded: res.base64Encoded });
                    sendResponse({ body: res.body, base64Encoded: res.base64Encoded });
                }
            });
        } else {
            sendResponse({ error: "Expired" });
        }
        return true;
    }
    if (msg.action === 'UPDATE_HEADER_RULES') {
        updateHeaderRules(msg.rules).then(() => sendResponse(true));
        return true;
    }
    // ── 收藏 / 标记 ──
    if (msg.action === 'TOGGLE_STAR') {
        if (starredIds.has(msg.id)) starredIds.delete(msg.id);
        else starredIds.add(msg.id);
        chrome.storage.local.set({ starredIds: [...starredIds] });
        sendResponse({ starred: starredIds.has(msg.id) });
    }
    if (msg.action === 'GET_STARRED') { sendResponse([...starredIds]); }
    // ── WebSocket 日志 ──
    if (msg.action === 'GET_WS_LOGS') { sendResponse(wsLogs); }
    // ── 性能分析 ──
    if (msg.action === 'GET_PERF_STATS') {
        const completed = globalLogs.filter(l => l.duration);
        const byType = {};
        completed.forEach(l => {
            if (!byType[l.type]) byType[l.type] = { count: 0, totalMs: 0, max: 0 };
            byType[l.type].count++;
            byType[l.type].totalMs += l.duration;
            if (l.duration > byType[l.type].max) byType[l.type].max = l.duration;
        });
        const slowest = [...completed].sort((a, b) => b.duration - a.duration).slice(0, 10);
        sendResponse({ byType, slowest });
    }
    // ── 实时流量 Dashboard ──
    if (msg.action === 'GET_TRAFFIC_TIMELINE') {
        const domainStats = {};
        globalLogs.forEach(l => {
            try { const h = new URL(l.url).hostname; domainStats[h] = (domainStats[h] || 0) + 1; } catch (e) {}
        });
        const statusStats = { '2xx': 0, '3xx': 0, '4xx': 0, '5xx': 0, pending: 0 };
        globalLogs.forEach(l => {
            const s = Number(l.status);
            if (!s || l.status === 'Pending') statusStats.pending++;
            else if (s < 300) statusStats['2xx']++;
            else if (s < 400) statusStats['3xx']++;
            else if (s < 500) statusStats['4xx']++;
            else statusStats['5xx']++;
        });
        sendResponse({ timeline: trafficTimeline, domainStats, statusStats, total: globalLogs.length });
    }
    // ── Schema 快照管理 ──
    if (msg.action === 'GET_SCHEMA_SNAPSHOTS') {
        sendResponse({ snapshots: [...schemaSnapshots.entries()].map(([url, schema]) => ({ url, schema: JSON.stringify(schema, null, 2) })) });
    }
    if (msg.action === 'DELETE_SCHEMA_SNAPSHOT') {
        schemaSnapshots.delete(msg.url);
        sendResponse({ ok: true });
    }
    if (msg.action === 'FORCE_SNAPSHOT') {
        // 强制刷新某 URL 的 schema 快照
        schemaSnapshots.delete(msg.url);
        sendResponse({ ok: true });
    }
    // ── 条件告警规则管理 ──
    if (msg.action === 'GET_ALERT_RULES') { sendResponse({ rules: alertRules }); }
    if (msg.action === 'SAVE_ALERT_RULES') {
        alertRules = msg.rules;
        chrome.storage.local.set({ alertRules });
        sendResponse({ ok: true });
    }
    // ── 规则集导入导出 ──
    if (msg.action === 'EXPORT_CONFIG') {
        chrome.storage.local.get(null, (allData) => {
            // 导出所有配置（排除 key 本身）
            const { openAIKey, ...safeData } = allData;
            sendResponse({ config: safeData });
        });
        return true;
    }
    if (msg.action === 'IMPORT_CONFIG') {
        try {
            const cfg = JSON.parse(msg.configText);
            chrome.storage.local.set(cfg, () => sendResponse({ ok: true }));
        } catch (e) { sendResponse({ error: e.message }); }
        return true;
    }
    // ── AI Fuzz ──
    if (msg.action === 'AI_FUZZ') {
        callOpenAI(msg.content, msg.apiKey, 'FUZZ', msg.model, msg.apiHost)
            .then(result => sendResponse({ result }))
            .catch(err => sendResponse({ error: err.message }));
        return true;
    }
    if (msg.action === 'ANALYZE_WITH_AI') {
        callOpenAI(msg.content, msg.apiKey, msg.promptType, msg.model, msg.apiHost)
            .then(result => sendResponse({ result }))
            .catch(err => sendResponse({ error: err.message }));
        return true;
    }
    if (msg.action === 'GET_AI_MODELS') {
        const host = (msg.apiHost || "https://api.openai.com").replace(/\/$/, '');
        fetch(`${host}/v1/models`, { headers: { 'Authorization': `Bearer ${msg.apiKey}` } })
            .then(r => r.json())
            .then(data => {
                if (data.error) throw new Error(data.error.message);
                sendResponse({ models: (data.data||[]).map(m => m.id).sort() });
            }).catch(err => sendResponse({ error: err.message }));
        return true;
    }
    if (msg.action === 'CHECK_AI_BALANCE') {
        const host = (msg.apiHost || "https://api.openai.com").replace(/\/$/, '');
        fetch(`${host}/v1/dashboard/billing/subscription`, { headers: { 'Authorization': `Bearer ${msg.apiKey}` } })
            .then(r => r.json()).then(data => sendResponse({ data }))
            .catch(err => sendResponse({ error: err.message }));
        return true;
    }
    // ── 安全头扫描 ──
    if (msg.action === 'SCAN_SECURITY_HEADERS') {
        try { sendResponse({ results: SecurityHeaders.scan(globalLogs) }); }
        catch(e) { sendResponse({ results: [], error: e.message }); }
    }
    // ── 端点提取 ──
    if (msg.action === 'EXTRACT_ENDPOINTS') {
        try { sendResponse({ results: EndpointExtractor.extract(globalLogs) }); }
        catch(e) { sendResponse({ results: [], error: e.message }); }
    }
    // ── 漏洞扫描 ──
    if (msg.action === 'SCAN_VULNS') {
        try { sendResponse({ results: VulnScanner.scan(globalLogs) }); }
        catch(e) { sendResponse({ results: [], error: e.message }); }
    }
    // ── 参数挖掘 ──
    if (msg.action === 'MINE_PARAMS') {
        try { sendResponse({ results: ParamMiner.mine(globalLogs) }); }
        catch(e) { sendResponse({ results: [], error: e.message }); }
    }
});

// 动态 Header 伪造
async function updateHeaderRules(headers) {
    const oldRules = await chrome.declarativeNetRequest.getDynamicRules();
    const removeRuleIds = oldRules.map(r => r.id);
    if (!headers || Object.keys(headers).length === 0) {
        await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds });
        return;
    }
    let idCounter = 1000;
    const addRules = Object.entries(headers).map(([key, value]) => ({
        id: idCounter++, priority: 1,
        action: { type: "modifyHeaders", requestHeaders: [{ header: key, operation: "set", value: value }] },
        condition: { urlFilter: "*", resourceTypes: ["main_frame", "sub_frame", "xmlhttprequest", "media", "script", "other"] }
    }));
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules });
}

// AI 反汇编大脑通信
async function callOpenAI(content, apiKey, promptType, model, apiHost) {
    const truncatedContent = content.substring(0, 20000); 
    let systemPrompt = "You are an elite Reverse Engineer and Security Researcher.";
    
    if (promptType === 'EXPLAIN') {
        systemPrompt += " Analyze the HTTP response. Explain its business logic, data structure, and highlight any potential security risks (PII leak, sensitive tokens).";
    } else if (promptType === 'TS_TYPE') {
        systemPrompt += " Generate strict TypeScript interfaces for this JSON data. Use JSDoc comments to describe fields based on values.";
    } else if (promptType === 'MOCK_DATA') {
        systemPrompt += `
        Task: Generate realistic Mock data based on this API response sample.
        1. Analyze the data structure and field semantics.
        2. Generate 5 realistic mock records that match the structure.
        3. Use realistic-looking fake data (real-sounding names, valid-format emails, plausible numbers).
        4. Output as a JSON array, ready to paste into a Mock server.
        Output Format: A single JSON code block.`;
    } else if (promptType === 'API_DOC') {
        systemPrompt += `
        Task: Generate API documentation from this HTTP request/response data.
        Output a Markdown document containing:
        1. **Endpoint**: URL, HTTP Method
        2. **Description**: What this API does (inferred from data)
        3. **Request Parameters**: Table of query params / body fields (name, type, required, description)
        4. **Response Fields**: Table of all response fields (name, type, description, example)
        5. **Example Request**: curl command
        6. **Example Response**: Formatted JSON
        Be concise and professional.`;
    } else if (promptType === 'DISASSEMBLE') {
        systemPrompt += `
        Task: De-obfuscate and Audit the provided JavaScript/Code snippet.
        1. [De-obfuscation]: Rename short variables (a, b, _0x...) to meaningful names based on context. 
        2. [Format]: Reconstruct the code into readable ES6+ syntax.
        3. [Audit]: Identify:
           - Hardcoded Secrets/API Keys.
           - Anti-debugging/Anti-tampering logic.
           - Suspicious network calls or eval() usage.
        Output Format: Markdown code block for the cleaned code, followed by a bullet point security report.
        `;
    } else if (promptType === 'FUZZ') {
        systemPrompt += `
        You are an API security tester. Given this HTTP request data, generate a JSON array of fuzz test cases.
        Each case is an object with: { "description": string, "method": string, "url": string, "body": string|null, "headers": object, "expectAnomaly": string }
        Generate 10 cases covering:
        1. Boundary values (empty string, very long string 10000+ chars, null, 0, -1, 99999999)
        2. Type confusion (string where number expected, array where object expected)
        3. SQL injection patterns in string params
        4. XSS payloads in string params
        5. Path traversal in URL params
        6. Authentication bypass (missing/malformed auth header)
        7. Negative/overflow numbers
        8. Unicode edge cases
        Output ONLY a valid JSON array, no explanation.`;
    } else if (promptType === 'CODE_GEN') {
        systemPrompt += `
        Given this HTTP request, generate code snippets in ALL of the following formats.
        Output as a JSON object with keys: curl, python, javascript, go, java
        Each value is a complete, ready-to-run code string.
        - curl: full curl command with headers and body
        - python: using requests library
        - javascript: using fetch API (async/await)
        - go: using net/http package
        - java: using OkHttp
        Output ONLY the JSON object, no explanation.`;
    } else if (promptType === 'SIGN_REVERSE') {
        systemPrompt += `
        You are an expert in cryptography and API reverse engineering.
        Given this captured encryption call, your task is:
        1. [Algorithm Identification]: Identify the exact algorithm, mode, and padding (e.g. AES-128-CBC with PKCS7, HMAC-SHA256).
        2. [Key/IV Analysis]: Analyze the key and IV format — is it hex, base64, UTF-8 string, derived from a fixed seed?
        3. [Reproduction Code]: Write a complete Python script using standard libraries (hashlib, hmac, Crypto) to reproduce this exact encryption call. Include sample input and expected output.
        4. [Security Assessment]: Note any weaknesses (hardcoded key, weak algorithm, predictable nonce, etc.)
        Format: Use markdown with clear section headers.`;
    } else if (promptType === 'BP_AI_SUGGEST') {
        systemPrompt += `
        You are an offensive security expert performing authorized API testing.
        Given this intercepted HTTP request, analyze it for the specified attack scenario and provide:
        1. [Analysis]: What this request does and why it's interesting for the given scenario.
        2. [Attack Plan]: Step by step what to modify and why.
        3. [Modified Request]: Output a JSON block with keys "url" and/or "body" containing the modified values.
        Format: Markdown + a single \`\`\`json block at the end with {"url": "...", "body": "..."}
        Only include keys you actually modified. Be specific and actionable.
        Scenario: {scenario}`.replace('{scenario}', content.includes('"scene"') ? JSON.parse(content).scene : 'general');
    } else if (promptType === 'SCRIPT_GEN') {
        systemPrompt += `
        Generate a JavaScript hook script for a browser extension response interceptor.
        The script has access to: url (string), method (string), response (string, the response body).
        The script should return the (optionally modified) response string.
        Async/await is supported. JSON.parse/stringify is available.
        Output ONLY the JavaScript code inside a \`\`\`javascript code block, no explanation.`;
    }

    const host = (apiHost || "https://api.openai.com").replace(/\/$/, '');
    
    try {
        const response = await fetch(`${host}/v1/chat/completions`, {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json', 
                'Authorization': `Bearer ${apiKey}` 
            },
            body: JSON.stringify({
                model: model || "gpt-3.5-turbo", 
                temperature: 0.2, 
                messages: [
                    { role: "system", content: systemPrompt }, 
                    { role: "user", content: `Code/Data Snippet:\n\`\`\`\n${truncatedContent}\n\`\`\`` }
                ]
            })
        });

        const data = await response.json();
        if (data.error) throw new Error(data.error.message);
        return data.choices[0].message.content;
    } catch (e) {
        throw e;
    }
}

// 自动重连调试器（多标签统一抓包）
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'loading' && tab.url?.startsWith('http')) {
        chrome.debugger.attach({ tabId }, '1.3').then(() => {
            attachedTabs.add(tabId);
            chrome.debugger.sendCommand({ tabId }, 'Network.enable');
            chrome.debugger.sendCommand({ tabId }, 'Network.enableWebSocketFrames', {}).catch(() => {});
            chrome.debugger.sendCommand({ tabId }, 'Target.setAutoAttach', {
                autoAttach: true, waitForDebuggerOnStart: false, flatten: true
            });
        }).catch(() => {});
    }
});

chrome.tabs.onRemoved.addListener((tabId) => {
    attachedTabs.delete(tabId);
});


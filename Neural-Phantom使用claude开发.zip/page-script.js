// page-script.js - Neural Phantom 4.1 绝对完整版 (已打入严格模式修复补丁)

(function() {
    // 🍵 茶室核心变量 (闭包保护，外部无法访问)
    let _dynamicHandler = null;
    let _mockRules = [];
    let _localFileRules = [];      // 本地文件替换规则
    let _breakpointEnabled = false;
    let _breakpointFilter = '';
    let _breakpointResolvers = {};
    const _replaceMap = {};

    // 生成唯一 ID，用于断点请求的标识
    const generateId = () => Date.now().toString(36) + Math.random().toString(36).substr(2, 5);

    // ============================================================
    // 💀 禁忌技术：原生伪装 (Native Code Spoofing)
    // 确保劫持后的函数在被检测时返回 [native code]，防止被网页反调试检测
    // ============================================================
    function makeNative(mockFunc, originalFunc) {
        const proxy = new Proxy(mockFunc, {
            apply(target, thisArg, args) { return Reflect.apply(target, thisArg, args); },
            construct(target, args) { return Reflect.construct(target, args); },
            get(target, prop) {
                if (prop === 'toString') return originalFunc.toString.bind(originalFunc);
                return Reflect.get(target, prop);
            }
        });
        const nativeString = originalFunc.toString();
        Object.defineProperty(proxy, 'toString', {
            value: function() { return nativeString; },
            writable: true, configurable: true
        });
        return proxy;
    }

    // ============================================================
    // 🕵️‍♂️ 加密审计模块 (Crypto Audit)
    // 实时拦截前端网页的 AES 加密明文与密钥
    // ============================================================
    // ============================================================
    // 🔐 加密审计模块 v2 — 全套 Hook：CryptoJS + WebCrypto + 签名字段嗅探
    // ============================================================

    function reportCrypto(algo, plaintext, keyInfo, extra, traceDepth) {
        traceDepth = traceDepth || 2;
        let traceStr = 'unknown';
        try {
            const stack = new Error().stack;
            if (stack) traceStr = stack.split('\n').slice(traceDepth, traceDepth + 3).join(' | ');
        } catch (e) {}
        window.postMessage({ type: 'CRYPTO_REPORT', algo: algo, in: String(plaintext).substring(0, 500), key: String(keyInfo).substring(0, 200), trace: traceStr, extra: extra || '' }, '*');
    }

    // ── A. CryptoJS 全套 Hook ──
    const hookCryptoJS = () => {
        if (!window.CryptoJS) return;
        const CJ = window.CryptoJS;
        if (CJ.AES && CJ.AES.encrypt && !CJ.AES.encrypt._isHooked) {
            const _orig = CJ.AES.encrypt;
            CJ.AES.encrypt = makeNative(function(msg, key, cfg) {
                reportCrypto('CryptoJS.AES.encrypt', msg, key);
                return _orig.apply(this, arguments);
            }, _orig);
            CJ.AES.encrypt._isHooked = true;
        }
        ['HmacSHA1','HmacSHA256','HmacSHA512','HmacMD5'].forEach(function(fn) {
            if (CJ[fn] && !CJ[fn]._isHooked) {
                const _orig = CJ[fn];
                CJ[fn] = makeNative(function(message, key) {
                    reportCrypto('CryptoJS.' + fn, message, key);
                    return _orig.apply(this, arguments);
                }, _orig);
                CJ[fn]._isHooked = true;
            }
        });
        ['MD5','SHA1','SHA256','SHA512'].forEach(function(fn) {
            if (CJ[fn] && !CJ[fn]._isHooked) {
                const _orig = CJ[fn];
                CJ[fn] = makeNative(function(message) {
                    reportCrypto('CryptoJS.' + fn, message, '(hash, no key)');
                    return _orig.apply(this, arguments);
                }, _orig);
                CJ[fn]._isHooked = true;
            }
        });
    };

    // ── B. WebCrypto API Hook（原生 crypto.subtle）──
    const hookWebCrypto = () => {
        if (!window.crypto || !window.crypto.subtle || window.crypto.subtle._isHooked) return;
        const _subtle = window.crypto.subtle;
        const _origSign = _subtle.sign.bind(_subtle);
        _subtle.sign = function(algorithm, key, data) {
            return _origSign(algorithm, key, data).then(function(result) {
                try {
                    const algoName = typeof algorithm === 'string' ? algorithm : algorithm.name;
                    const preview = Array.from(new Uint8Array(data).slice(0, 32)).map(function(b){return b.toString(16).padStart(2,'0');}).join('');
                    reportCrypto('WebCrypto.sign [' + algoName + ']', 'data[' + data.byteLength + ']: ' + preview + '...', 'CryptoKey type=' + key.type, '', 3);
                } catch (e) {}
                return result;
            });
        };
        const _origEncrypt = _subtle.encrypt.bind(_subtle);
        _subtle.encrypt = function(algorithm, key, data) {
            return _origEncrypt(algorithm, key, data).then(function(result) {
                try {
                    const algoName = typeof algorithm === 'string' ? algorithm : algorithm.name;
                    const iv = algorithm.iv ? Array.from(new Uint8Array(algorithm.iv)).map(function(b){return b.toString(16).padStart(2,'0');}).join('') : 'N/A';
                    reportCrypto('WebCrypto.encrypt [' + algoName + ']', 'data[' + data.byteLength + ' bytes]', 'CryptoKey algo=' + (key.algorithm && key.algorithm.name) + ', iv=' + iv, '', 3);
                } catch (e) {}
                return result;
            });
        };
        const _origDigest = _subtle.digest.bind(_subtle);
        _subtle.digest = function(algorithm, data) {
            return _origDigest(algorithm, data).then(function(result) {
                try {
                    const algoName = typeof algorithm === 'string' ? algorithm : algorithm.name;
                    const resultHex = Array.from(new Uint8Array(result)).map(function(b){return b.toString(16).padStart(2,'0');}).join('');
                    reportCrypto('WebCrypto.digest [' + algoName + ']', 'input[' + data.byteLength + ' bytes]', 'result: ' + resultHex.substring(0,32) + '...', '', 3);
                } catch (e) {}
                return result;
            });
        };
        window.crypto.subtle._isHooked = true;
    };

    // ── C. 签名字段嗅探 ──
    const SIG_PATTERNS = [
        /[?&](sign|signature|sig|nonce|timestamp|_t|_sign|hmac)=([^&\s]{4,})/gi,
        /"(sign|signature|nonce|timestamp|_sign|access_token)":\s*"([^"]{4,})"/gi
    ];
    function sniffSignatureFields(text) {
        if (!text || typeof text !== 'string') return;
        SIG_PATTERNS.forEach(function(re) {
            re.lastIndex = 0;
            var m;
            while ((m = re.exec(text)) !== null) {
                window.postMessage({ type: 'SIGN_FIELD_FOUND', field: m[1], value: m[2].substring(0, 60), context: text.substring(Math.max(0, m.index-30), m.index+80) }, '*');
            }
        });
    }

    // ============================================================
    // 🔬 参数来源追踪模块 (ParamTracer)
    // ============================================================
    const ParamTracer = {
        getStack: function() {
            try {
                return new Error().stack.split('\n')
                    .slice(3, 8)
                    .map(l => l.trim())
                    .filter(l => l && !l.includes('page-script') && !l.includes('inject.js') && !l.includes('extensions'))
                    .join(' → ') || 'unknown';
            } catch(e) { return 'unknown'; }
        },
        extractUrlParams: function(url) {
            const params = {};
            try {
                new URL(url, location.href).searchParams.forEach((v, k) => { params[k] = v; });
            } catch(e) {}
            return params;
        },
        extractBodyParams: function(body) {
            if (!body || typeof body !== 'string' || body.length > 200000) return {};
            const params = {};
            try {
                const flatten = (obj, prefix) => {
                    if (!obj || typeof obj !== 'object') return;
                    for (const [k, v] of Object.entries(obj)) {
                        const key = prefix ? prefix + '.' + k : k;
                        if (typeof v === 'object' && v !== null && !Array.isArray(v)) flatten(v, key);
                        else params[key] = String(v).substring(0, 200);
                    }
                };
                flatten(JSON.parse(body), '');
                return params;
            } catch(e) {}
            try { new URLSearchParams(body).forEach((v, k) => { params[k] = v; }); } catch(e) {}
            return params;
        },
        report: function(params, url, method, source, headers) {
            if (!params || !Object.keys(params).length) return;
            // 过滤掉不感兴趣的通用参数
            const skip = new Set(['_t','_','page','size','limit','offset','pageSize','pageNum','callback']);
            const filtered = {};
            for (const [k, v] of Object.entries(params)) {
                if (!skip.has(k) && v && String(v).length > 1) filtered[k] = v;
            }
            if (!Object.keys(filtered).length) return;
            window.postMessage({
                type: 'PARAM_TRACE',
                params: filtered,
                url, method, source,
                stack: this.getStack(),
                headers: headers || {},
                time: Date.now()
            }, '*');
        }
    };

    // Hook XHR.setRequestHeader
    const originalSetRequestHeader = XMLHttpRequest.prototype.setRequestHeader;
    XMLHttpRequest.prototype.setRequestHeader = function(name, value) {
        if (!this._capturedHeaders) this._capturedHeaders = {};
        this._capturedHeaders[name] = value;
        return originalSetRequestHeader.apply(this, arguments);
    };

    setInterval(function() { hookCryptoJS(); hookWebCrypto(); }, 2000);
    hookCryptoJS();
    hookWebCrypto();

    // ============================================================
    // 1. 内部消息通信 (监听来自 inject.js 的指令)
    // ============================================================
    window.addEventListener('message', (event) => {
        const data = event.data;
        if (!data || !data.type) return;

        // 更新静态 Mock 规则
        if (data.type === 'UPDATE_MOCK_RULES') {
            _mockRules = data.rules || [];
        }

        // 更新本地文件替换规则
        if (data.type === 'UPDATE_LOCAL_FILE_RULES') {
            _localFileRules = data.rules || [];
        }
        
        // WS 改写规则（也在这里接收，同步给 _wsModifyRules）
        if (data.type === 'UPDATE_WS_RULES') {
            // _wsModifyRules handled in WS section below
        }

        // 导出所有 Storage 数据
        if (data.type === 'DUMP_STORAGE') {
            const local = {}, session = {};
            try { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); local[k] = localStorage.getItem(k); } } catch(e) {}
            try { for (let i = 0; i < sessionStorage.length; i++) { const k = sessionStorage.key(i); session[k] = sessionStorage.getItem(k); } } catch(e) {}
            window.postMessage({ type: 'STORAGE_DUMP_RESULT', local, session, url: window.location.href }, '*');
        }

        // 中止被断点挂起的请求
        if (data.type === 'ABORT_REQUEST') {
            const resolver = _breakpointResolvers[data.requestId];
            if (resolver) {
                delete _breakpointResolvers[data.requestId];
                // 用一个 aborted response 代替
                resolver({ aborted: true, requestId: data.requestId });
            }
        }
        
        // 更新动态 Hook 脚本
        if (data.type === 'UPDATE_DYNAMIC_SCRIPT') {
            if (!data.script || data.script.trim() === '') {
                _dynamicHandler = null;
            } else {
                try {
                    // 动态构建处理函数
                    _dynamicHandler = new Function('url', 'method', 'response', data.script);
                } catch (e) {
                    console.error('[Phantom Analyzer] Script Error:', e);
                }
            }
        }
        
        // 更新断点状态和狙击关键词
        if (data.type === 'TOGGLE_BREAKPOINT') {
            _breakpointEnabled = data.enabled;
            _breakpointFilter = data.filter || ''; 
        }

        // 恢复被暂停的请求
        if (data.type === 'RESUME_REQUEST') {
            const resolver = _breakpointResolvers[data.requestId];
            if (resolver) {
                resolver(data.modifiedData); 
                delete _breakpointResolvers[data.requestId];
            }
        }

        // 添加 M3U8 重定向映射
        if (data.type === 'ADD_REDIRECT_RULE') {
            _replaceMap[data.original] = data.clean;
        }
        
        // 执行请求重放
        if (data.type === 'REPLAY_REQUEST') {
            replayRequest(data.url, data.method, data.body);
        }
    });

    // 请求重放逻辑：使用 fetch 重新发起目标请求
    function replayRequest(url, method, body) {
        console.log(`[Phantom Replay] 正在重放请求: ${method} ${url}`);
        const options = { 
            method: method, 
            headers: { 'Content-Type': 'application/json' } 
        }; 
        if (body) options.body = body;
        window.fetch(url, options)
            .then(r => r.text())
            .then(t => console.log('[Phantom Replay] 响应结果:', t))
            .catch(e => console.error('[Phantom Replay] 重放失败:', e));
    }

    // ============================================================
    // 2. 🎯 断点挂起核心：判断是否需要暂停请求
    // ============================================================
    async function waitForBreakpoint(url, method, body, type) {
        // 1. 断点总开关未开启 -> 放行
        if (!_breakpointEnabled) return null;
        
        // 2. 关键词未命中 -> 放行
        if (_breakpointFilter && !url.includes(_breakpointFilter)) return null;

        const requestId = generateId();
        // 通知 inject.js 弹出调试窗口
        window.postMessage({ 
            type: 'REQUEST_PAUSED_INTERNAL', 
            details: { requestId, url, method, body, type } 
        }, '*');

        // 返回 Promise 挂起当前线程，直到 UI 点击“放行”
        return new Promise(resolve => { 
            _breakpointResolvers[requestId] = resolve; 
        });
    }

    // ============================================================
    // 2b. Storage 全审计 — localStorage / sessionStorage 读写监控
    // ============================================================
    function hookStorage(storageObj, storageName) {
        const _origSetItem = storageObj.setItem.bind(storageObj);
        const _origRemoveItem = storageObj.removeItem.bind(storageObj);
        const _origClear = storageObj.clear.bind(storageObj);

        storageObj.setItem = function(key, value) {
            const oldVal = storageObj.getItem(key);
            _origSetItem(key, value);
            window.postMessage({ type: 'STORAGE_EVENT', storage: storageName, op: oldVal === null ? 'ADD' : 'SET', key, value: String(value).substring(0, 500), oldValue: oldVal ? String(oldVal).substring(0, 200) : null }, '*');
        };
        storageObj.removeItem = function(key) {
            const oldVal = storageObj.getItem(key);
            _origRemoveItem(key);
            window.postMessage({ type: 'STORAGE_EVENT', storage: storageName, op: 'REMOVE', key, oldValue: oldVal ? String(oldVal).substring(0, 200) : null }, '*');
        };
        storageObj.clear = function() {
            _origClear();
            window.postMessage({ type: 'STORAGE_EVENT', storage: storageName, op: 'CLEAR', key: '*' }, '*');
        };
    }

    // Hook localStorage & sessionStorage
    try { hookStorage(window.localStorage, 'localStorage'); } catch(e) {}
    try { hookStorage(window.sessionStorage, 'sessionStorage'); } catch(e) {}

    // IndexedDB 写操作监控
    const _origIDBOpen = window.indexedDB.open.bind(window.indexedDB);
    window.indexedDB.open = function(name, version) {
        const req = _origIDBOpen(name, version);
        req.addEventListener('success', function() {
            const db = req.result;
            const _origTransaction = db.transaction.bind(db);
            db.transaction = function(storeNames, mode) {
                const tx = _origTransaction(storeNames, mode);
                if (mode === 'readwrite') {
                    const names = Array.isArray(storeNames) ? storeNames : [storeNames];
                    names.forEach(storeName => {
                        try {
                            const store = tx.objectStore(storeName);
                            const _origPut = store.put.bind(store);
                            const _origDelete = store.delete.bind(store);
                            store.put = function(value, key) {
                                window.postMessage({ type: 'STORAGE_EVENT', storage: 'IndexedDB', op: 'PUT', key: `${name}/${storeName}/${key || '?'}`, value: JSON.stringify(value).substring(0, 300) }, '*');
                                return _origPut(value, key);
                            };
                            store.delete = function(key) {
                                window.postMessage({ type: 'STORAGE_EVENT', storage: 'IndexedDB', op: 'DELETE', key: `${name}/${storeName}/${key}` }, '*');
                                return _origDelete(key);
                            };
                        } catch(e) {}
                    });
                }
                return tx;
            };
        });
        return req;
    };

    // 响应 DUMP_STORAGE 消息 — 一次性导出所有 localStorage/sessionStorage
    // (在消息监听器里处理，见下方)

    // ============================================================
    // 3. 劫持 Fetch API
    // ============================================================
    const originalFetch = window.fetch;
    const hookedFetch = async function(...args) {
        let url = typeof args[0] === 'string' ? args[0] : (args[0].url || '');
        let options = args[1] || {};
        let method = options.method || 'GET';
        let body = options.body;

        // A. 静态 Mock 检查（优先级最高）
        const staticRule = _mockRules.find(r => url.includes(r.urlKeyword) && r.enabled);
        if (staticRule) {
            console.log(`[Phantom Mock] 命中静态规则: ${url}`);
            return new Response(staticRule.responseBody, { status: 200 });
        }

        // A2. 本地文件替换
        const localRule = _localFileRules.find(r => url.includes(r.urlKeyword) && r.enabled);
        if (localRule) {
            console.log(`[Phantom MapLocal] 替换为本地文件: ${url} → ${localRule.fileName}`);
            return new Response(localRule.content, { status: 200, headers: { 'Content-Type': 'text/javascript' } });
        }

        // A3. 签名字段嗅探
        sniffSignatureFields(url);
        if (body && typeof body === 'string') sniffSignatureFields(body);

        // A4. 参数来源追踪
        ParamTracer.report(ParamTracer.extractUrlParams(url), url, method, 'fetch_url');
        if (body && typeof body === 'string') {
            ParamTracer.report(ParamTracer.extractBodyParams(body), url, method, 'fetch_body');
        }
        // 捕获请求头中的关键字段
        const fetchHeaders = {};
        try {
            const h = options.headers || {};
            const entries = h instanceof Headers ? [...h.entries()] : Object.entries(h);
            entries.forEach(([k, v]) => {
                const kl = k.toLowerCase();
                if (/auth|token|sign|key|secret|x-/i.test(kl)) fetchHeaders[k] = v;
            });
            if (Object.keys(fetchHeaders).length) {
                ParamTracer.report(fetchHeaders, url, method, 'fetch_header');
            }
        } catch(e) {}

        // B. 断点检查：请求发出前进入暂停状态
        const modifiedData = await waitForBreakpoint(url, method, body, 'fetch');
        if (modifiedData) {
            // 丢弃请求
            if (modifiedData.aborted) {
                return new Response('{"error":"request aborted by Phantom"}', { status: 0, statusText: 'Aborted' });
            }
            // 应用用户在 UI 上的修改
            if (modifiedData.url) args[0] = modifiedData.url;
            if (modifiedData.body && args[1]) args[1].body = modifiedData.body;
            if (modifiedData.headers && args[1]) {
                args[1].headers = { ...(args[1].headers || {}), ...modifiedData.headers };
            }
        }

        let response;
        try { 
            response = await originalFetch.apply(this, args); 
        } catch (err) { 
            throw err; 
        }

        // C. 动态脚本处理：响应返回后进行 Hook
        if (_dynamicHandler) {
            try {
                const contentType = response.headers.get('content-type') || '';
                // 仅处理 JSON 或文本类型，防止处理二进制流导致卡死
                if (/application\/json|text\//.test(contentType)) {
                    const clone = response.clone();
                    let bodyText = await clone.text().catch(() => '');
                    
                    // 检查响应体大小，超过 2MB 则跳过，保证性能
                    if (bodyText.length < 2 * 1024 * 1024) {
                        const modifiedBody = _dynamicHandler(url, method, bodyText);
                        if (modifiedBody !== null && modifiedBody !== undefined) {
                            return new Response(modifiedBody, {
                                status: response.status, 
                                statusText: response.statusText, 
                                headers: response.headers
                            });
                        }
                    }
                }
            } catch (e) {}
        }
        return response;
    };
    // 应用原生伪装
    window.fetch = makeNative(hookedFetch, originalFetch);

    // ============================================================
    // 4. 劫持 XMLHttpRequest (XHR)
    // ============================================================
    const originalOpen = XMLHttpRequest.prototype.open;
    const originalSend = XMLHttpRequest.prototype.send;

    const hookedOpen = function(method, url) {
        this._requestUrl = url;
        this._method = method;
        
        // [修复补丁3]：使用 Array 转换 arguments，防止在严格模式下报错失效
        let args = Array.prototype.slice.call(arguments);
        if (_replaceMap[url]) {
            args[1] = _replaceMap[url];
        }
        return originalOpen.apply(this, args);
    };
    
    const hookedSend = function(body) {
        // A. 静态 Mock 检查
        const staticRule = _mockRules.find(r => (this._requestUrl||'').includes(r.urlKeyword) && r.enabled);
        if (staticRule) {
            Object.defineProperty(this, 'responseText', { value: staticRule.responseBody });
            Object.defineProperty(this, 'response', { value: staticRule.responseBody });
            Object.defineProperty(this, 'status', { value: 200 });
            Object.defineProperty(this, 'readyState', { value: 4 });
            setTimeout(() => {
                if (this.onreadystatechange) this.onreadystatechange();
                if (this.onload) this.onload();
            }, 10);
            return;
        }
        // A2. 本地文件替换 (XHR)
        const localRule = _localFileRules.find(r => (this._requestUrl||'').includes(r.urlKeyword) && r.enabled);
        if (localRule) {
            Object.defineProperty(this, 'responseText', { value: localRule.content });
            Object.defineProperty(this, 'response', { value: localRule.content });
            Object.defineProperty(this, 'status', { value: 200 });
            Object.defineProperty(this, 'readyState', { value: 4 });
            setTimeout(() => {
                if (this.onreadystatechange) this.onreadystatechange();
                if (this.onload) this.onload();
            }, 10);
            return;
        }

        // A3. 参数来源追踪
        const _xhrUrl = this._requestUrl || '';
        ParamTracer.report(ParamTracer.extractUrlParams(_xhrUrl), _xhrUrl, this._method || 'GET', 'xhr_url');
        if (body && typeof body === 'string') {
            ParamTracer.report(ParamTracer.extractBodyParams(body), _xhrUrl, this._method || 'GET', 'xhr_body');
        }
        if (this._capturedHeaders && Object.keys(this._capturedHeaders).length) {
            const interestingHeaders = {};
            for (const [k, v] of Object.entries(this._capturedHeaders)) {
                if (/auth|token|sign|key|secret|x-/i.test(k.toLowerCase())) interestingHeaders[k] = v;
            }
            if (Object.keys(interestingHeaders).length) {
                ParamTracer.report(interestingHeaders, _xhrUrl, this._method || 'GET', 'xhr_header');
            }
        }

        // B. 断点检查（XHR 异步等待逻辑）
        if (_breakpointEnabled) {
            waitForBreakpoint(this._requestUrl, this._method, body, 'xhr').then((modifiedData) => {
                if (modifiedData && modifiedData.body) body = modifiedData.body;
                // 如果开启了动态脚本，则设置 XHR 响应 Hook
                if (_dynamicHandler) setupXhrHook(this);
                originalSend.call(this, body);
            });
            return; // 暂停发送，直到 Promise 回调执行
        }

        // C. 普通发送：如果开启了动态脚本则注入 Hook
        if (_dynamicHandler) setupXhrHook(this);
        return originalSend.apply(this, arguments);
    };

    // 为 XHR 注入响应修改逻辑
    function setupXhrHook(xhr) {
        const originalOnReadyStateChange = xhr.onreadystatechange;
        const originalOnLoad = xhr.onload;
        
        const handleStateChange = () => {
            if (xhr.readyState === 4) { // 请求完成状态
                try {
                    // 仅当 responseType 为空或 text 时处理内容
                    if (!xhr.responseType || xhr.responseType === 'text') {
                        const originalText = xhr.responseText;
                        // 2MB 熔断保护
                        if (originalText && originalText.length < 2 * 1024 * 1024) {
                            const modifiedText = _dynamicHandler(xhr._requestUrl, xhr._method, originalText);
                            if (modifiedText !== null && modifiedText !== undefined) {
                                // 利用 Object.defineProperty 强行覆盖只读属性
                                Object.defineProperty(xhr, 'responseText', { value: modifiedText, writable: true });
                                Object.defineProperty(xhr, 'response', { value: modifiedText, writable: true });
                            }
                        }
                    }
                } catch (e) {}
            }
            if (originalOnReadyStateChange) originalOnReadyStateChange.apply(xhr, arguments);
        };

        xhr.onreadystatechange = handleStateChange;
        if (xhr.onload) {
            xhr.onload = () => { 
                handleStateChange(); 
                originalOnLoad.apply(xhr, arguments); 
            };
        }
    }

    // 应用 XHR 原生伪装
    XMLHttpRequest.prototype.open = makeNative(hookedOpen, originalOpen);
    XMLHttpRequest.prototype.send = makeNative(hookedSend, originalSend);

    // ============================================================
    // 🔌 WebSocket 拦截/改写 Hook
    // ============================================================
    const _NativeWebSocket = window.WebSocket;

    class HookedWebSocket extends _NativeWebSocket {
        constructor(url, protocols) {
            super(url, protocols);
            this._wsUrl = url;
            this._wsId = `ws_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
            this._paused = false;
            this._pendingFrames = []; // 断点时暂存待发帧

            // 上报 WS 连接建立
            window.postMessage({ type: 'WS_HOOK_CREATED', wsId: this._wsId, url }, '*');

            // 拦截接收到的消息（onmessage）
            const _origAddEventListener = this.addEventListener.bind(this);
            const self = this;

            this.addEventListener('message', function(event) {
                let data = event.data;
                // 通知页面面板，等待可能的改写指令
                window.postMessage({ type: 'WS_HOOK_RECV', wsId: self._wsId, url, data: typeof data === 'string' ? data.substring(0, 2000) : '[binary]' }, '*');
                // 改写拦截：如果当前帧有对应改写规则，替换数据
                const rule = _wsModifyRules.find(r => r.enabled && url.includes(r.urlKeyword));
                if (rule && typeof data === 'string') {
                    try {
                        const parsed = JSON.parse(data);
                        const newData = JSON.parse(rule.rewriteBody);
                        Object.assign(parsed, newData);
                        // 构造一个新的 MessageEvent 替换原始的
                        Object.defineProperty(event, 'data', { value: JSON.stringify(parsed), writable: false });
                    } catch (e) {}
                }
            }, false);
        }

        send(data) {
            const self = this;
            // 上报发出帧
            window.postMessage({ type: 'WS_HOOK_SENT', wsId: this._wsId, url: this._wsUrl, data: typeof data === 'string' ? data.substring(0, 2000) : '[binary]' }, '*');

            // 断点暂停模式
            if (this._paused) {
                this._pendingFrames.push(data);
                window.postMessage({ type: 'WS_FRAME_PAUSED', wsId: this._wsId, url: this._wsUrl, data: typeof data === 'string' ? data : '[binary]' }, '*');
                return;
            }

            // 改写规则
            let finalData = data;
            const rule = _wsModifyRules.find(r => r.enabled && this._wsUrl.includes(r.urlKeyword) && r.direction !== 'RECV');
            if (rule && typeof data === 'string') {
                try {
                    const parsed = JSON.parse(data);
                    const patch = JSON.parse(rule.rewriteBody);
                    finalData = JSON.stringify({ ...parsed, ...patch });
                    window.postMessage({ type: 'WS_HOOK_MODIFIED', wsId: this._wsId, original: data.substring(0, 200), modified: finalData.substring(0, 200) }, '*');
                } catch (e) {}
            }

            super.send(finalData);
        }

        // 解除断点，放行暂存帧
        _resumeFrames(modifiedData) {
            this._paused = false;
            const frames = this._pendingFrames.splice(0);
            frames.forEach(frame => {
                super.send(modifiedData !== undefined ? modifiedData : frame);
            });
        }
    }

    // WS 改写规则存储（由 inject.js 通过 UPDATE_WS_RULES 消息下发）
    let _wsModifyRules = [];

    window.addEventListener('message', function(event) {
        if (!event.data || event.data.__phantom_origin) return;
        const msg = event.data;
        if (msg.type === 'UPDATE_WS_RULES') {
            _wsModifyRules = msg.rules || [];
        }
        // 断点放行/丢弃 WS 帧
        if (msg.type === 'WS_FRAME_RESUME' || msg.type === 'WS_FRAME_ABORT') {
            // 找到对应的 HookedWebSocket 实例（通过 wsId 标记）
            // 实例在 window.__phantom_ws_instances 中管理
            const inst = (window.__phantom_ws_instances || {})[msg.wsId];
            if (inst) {
                if (msg.type === 'WS_FRAME_RESUME') inst._resumeFrames(msg.modifiedData);
                else inst._pendingFrames = [];
            }
        }
    }, false);

    // 实例注册表
    if (!window.__phantom_ws_instances) window.__phantom_ws_instances = {};
    const _OrigHookedWS = HookedWebSocket;
    window.WebSocket = new Proxy(_NativeWebSocket, {
        construct(target, args) {
            const inst = new _OrigHookedWS(...args);
            window.__phantom_ws_instances[inst._wsId] = inst;
            inst.addEventListener('close', () => { delete window.__phantom_ws_instances[inst._wsId]; }, { once: true });
            return inst;
        }
    });

})();



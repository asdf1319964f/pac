// chain.js — 独立弹窗：从 background.js 拉取链路数据并渲染

(function() {
    const list = document.getElementById('chain-list');
    const countEl = document.getElementById('chain-count');
    const liveCountEl = document.getElementById('chain-live-count');
    let _prevChainLen = -1;
    let _prevLiveLen = -1;

    function escHtml(s) {
        return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    }

    // ── 轮询 background 获取数据 ──
    function poll() {
        chrome.runtime.sendMessage({ action: 'CHAIN_GET_STATE' }, function(state) {
            if (!state) return;
            var chains = state.chains || [];
            var win = state.window || [];
            // 判断是否需要重新渲染（避免不必要的 DOM 操作）
            var chainChanged = chains.length !== _prevChainLen;
            var liveChanged = win.length !== _prevLiveLen;
            if (!chainChanged && !liveChanged) return;
            _prevChainLen = chains.length;
            _prevLiveLen = win.length;
            // 更新计数
            countEl.textContent = chains.length + ' 条';
            if (win.length > 0) {
                liveCountEl.style.display = 'inline-block';
                liveCountEl.textContent = '采集中: ' + win.length;
            } else {
                liveCountEl.style.display = 'none';
            }
            render(chains, win);
        });
    }

    function render(chains, win) {
        var html = '';
        // 实时数据流
        if (win.length > 0) html += renderLive(win);
        // 空状态
        if (!chains.length && !win.length) {
            html += '<div style="color:#9ca3af;font-size:12px;text-align:center;padding:40px 20px;">' +
                '暂无链路<br><span style="font-size:11px;">浏览含视频的网页，自动逆向播放地址解析流程</span>' +
                '<br><span style="font-size:10px;color:#b0b0b0;margin-top:8px;display:block;">点击「🔄 刷新网页」让请求重新发出</span></div>';
        }
        // 已完成链路
        chains.forEach(function(chain) { html += renderCard(chain); });
        list.innerHTML = html;
        bindCardEvents();
    }

    // ── 实时数据流 ──
    function renderLive(win) {
        var stepIcons = { PARAM_SOURCE:'📊', CRYPTO_CALL:'🔐', SIGN_FIELD:'✍️', PARAM_CRYPTO:'🧪', REQUEST_SENT:'📡', RESPONSE_RECV:'✅', URL_EXTRACT:'🎯', DECRYPT:'🔓', MEDIA_FOUND:'📺' };
        var stepLabels = { PARAM_SOURCE:'参数溯源', CRYPTO_CALL:'JS加密', SIGN_FIELD:'签名字段', PARAM_CRYPTO:'参数加密', REQUEST_SENT:'API请求', RESPONSE_RECV:'API响应', URL_EXTRACT:'URL提取', DECRYPT:'解密还原', MEDIA_FOUND:'播放地址' };
        var h = '<div style="border-bottom:2px solid #5b6ef5;background:rgba(91,110,245,0.03);">';
        h += '<div style="padding:8px 12px;display:flex;align-items:center;gap:8px;border-bottom:1px solid rgba(91,110,245,0.15);">';
        h += '<span style="width:7px;height:7px;background:#5b6ef5;border-radius:50%;animation:pulse-dot 1.5s ease-in-out infinite;flex-shrink:0;"></span>';
        h += '<span style="font-size:11px;font-weight:700;color:#5b6ef5;">实时数据流</span>';
        h += '<span style="font-size:10px;color:#9ca3af;">' + win.length + ' 个事件</span>';
        h += '</div>';
        var recent = win.slice(-25).reverse();
        recent.forEach(function(evt) {
            var icon = stepIcons[evt.step] || '⚪';
            var label = stepLabels[evt.step] || evt.step;
            var time = new Date(evt.time).toLocaleTimeString();
            var info = evt.url ? (evt.url||'').substring(0,70) : evt.algo ? evt.algo + (evt.plaintext ? ' → '+evt.plaintext.substring(0,30) : '') : evt.field ? evt.field+'='+(evt.value||'').substring(0,30) : evt.key ? evt.key+'='+(evt.value||'').substring(0,30) : '';
            h += '<div style="padding:4px 12px;border-bottom:1px solid rgba(180,185,215,0.12);display:flex;align-items:center;gap:6px;font-size:10px;">';
            h += '<span style="flex-shrink:0;">' + icon + '</span>';
            h += '<span style="min-width:52px;font-weight:600;color:#5b6ef5;flex-shrink:0;">' + label + '</span>';
            h += '<span style="font-family:monospace;color:#636e72;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' + escHtml(info) + '</span>';
            h += '<span style="color:#b0b0b0;font-size:9px;flex-shrink:0;">' + time + '</span>';
            h += '</div>';
        });
        if (win.length > 25) h += '<div style="padding:3px 12px;font-size:9px;color:#b0b0b0;text-align:center;">... 还有 ' + (win.length-25) + ' 条更早的事件</div>';
        h += '</div>';
        return h;
    }

    // ── 链路卡片 ──
    function renderCard(chain) {
        var elapsed = chain.endTime - chain.startTime;
        var shortUrl = chain.mediaUrl.length > 80 ? chain.mediaUrl.substring(0,80)+'...' : chain.mediaUrl;
        var stepIcons = { PARAM_SOURCE:'📊', CRYPTO_CALL:'🔐', SIGN_FIELD:'✍️', PARAM_CRYPTO:'🧪', REQUEST_SENT:'📡', RESPONSE_RECV:'✅', URL_EXTRACT:'🎯', DECRYPT:'🔓', MEDIA_FOUND:'📺' };
        var stepLabels = { PARAM_SOURCE:'参数溯源', CRYPTO_CALL:'JS加密', SIGN_FIELD:'签名字段', PARAM_CRYPTO:'参数加密', REQUEST_SENT:'API请求', RESPONSE_RECV:'API响应', URL_EXTRACT:'URL提取', DECRYPT:'解密还原', MEDIA_FOUND:'播放地址' };
        var stepClasses = { PARAM_SOURCE:'step-param', CRYPTO_CALL:'step-crypto', SIGN_FIELD:'step-sign', PARAM_CRYPTO:'step-crypto', REQUEST_SENT:'step-request', RESPONSE_RECV:'step-response', URL_EXTRACT:'step-media', DECRYPT:'step-decrypt', MEDIA_FOUND:'step-media' };
        // 步骤摘要
        var counts = {};
        chain.events.forEach(function(e) { counts[e.step] = (counts[e.step]||0)+1; });
        var summary = '';
        Object.keys(counts).forEach(function(s) {
            summary += '<span style="background:rgba(91,110,245,0.1);padding:1px 6px;border-radius:8px;font-size:9px;color:#5b6ef5;white-space:nowrap;">'+(stepIcons[s]||'')+' '+(stepLabels[s]||s)+(counts[s]>1?' x'+counts[s]:'')+' </span>';
        });
        // 关键 API
        var ext = chain.events.find(function(e){return e.step==='URL_EXTRACT';});
        var apiLine = ext ? '<div style="font-size:10px;color:#0984e3;margin-top:3px;font-family:monospace;word-break:break-all;">API: '+escHtml((ext.sourceApi||'').substring(0,80))+' → 字段: <b>'+escHtml(ext.field||'')+'</b></div>' : '';

        var h = '<div class="chain-card" data-chain-id="'+chain.id+'">';
        h += '<div class="chain-card-header">';
        h += '<span class="chain-type-badge '+chain.mediaType+'">'+chain.mediaType.toUpperCase()+'</span>';
        h += '<div class="chain-card-url" title="'+escHtml(chain.mediaUrl)+'">'+escHtml(shortUrl)+'</div>';
        h += '<button class="chain-copy-btn btn-small" style="background:#5b6ef5;padding:2px 8px;font-size:9px;flex-shrink:0;" data-url="'+escHtml(chain.mediaUrl)+'">复制</button>';
        h += '</div>';
        h += apiLine;
        h += '<div class="chain-card-meta"><span>'+chain.events.length+' 步</span><span>耗时 '+elapsed+'ms</span><span>'+new Date(chain.startTime).toLocaleTimeString()+'</span></div>';
        h += '<div style="display:flex;gap:4px;flex-wrap:wrap;margin-top:4px;">'+summary+'</div>';
        h += '<div class="chain-timeline">'+renderTimeline(chain, stepIcons, stepLabels, stepClasses)+'</div>';
        h += '</div>';
        return h;
    }

    // ── 时间线 ──
    function renderTimeline(chain, icons, labels, classes) {
        var h = '';
        chain.events.forEach(function(evt) {
            var icon = icons[evt.step]||'⚪', label = labels[evt.step]||evt.step, cls = classes[evt.step]||'';
            var time = new Date(evt.time).toLocaleTimeString();
            var d = '';
            if (evt.step==='PARAM_SOURCE') { d='参数 <b>'+escHtml(evt.key||'')+'</b> = '+escHtml((evt.value||'').substring(0,60))+' → 来源: <span style="color:#e17055;font-weight:bold;">'+escHtml(evt.verdict||'未知')+'</span>'; if(evt.fromUrl) d+='<br/><small style="color:#999;">来自: '+escHtml(evt.fromUrl.substring(0,80))+'</small>'; }
            else if (evt.step==='CRYPTO_CALL') { d='算法: <span style="color:#6c5ce7;font-weight:bold;">'+escHtml(evt.algo||'')+'</span><br/>输入: <span style="color:#d63031;">'+escHtml((evt.plaintext||'').substring(0,80))+'</span><br/>密钥: <span style="color:#0984e3;">'+escHtml((evt.key||'').substring(0,60))+'</span>'; if(evt.trace) d+='<br/><small style="color:#999;">栈: '+escHtml(evt.trace.substring(0,120))+'</small>'; }
            else if (evt.step==='SIGN_FIELD') { d='字段: <span style="color:#a29bfe;font-weight:bold;">'+escHtml(evt.field||'')+'</span> = <span style="color:#d63031;">'+escHtml((evt.value||'').substring(0,60))+'</span>'; }
            else if (evt.step==='PARAM_CRYPTO') { d='参数: <b>'+escHtml(evt.key||'')+'</b> 类型: <span style="color:#e17055;font-weight:bold;">'+(evt.detected||[]).join(', ')+'</span>'; if(evt.decoded&&evt.decoded.length) d+='<br/>解码: <span style="color:#00b894;">'+escHtml(evt.decoded[0].substring(0,60))+'</span>'; }
            else if (evt.step==='REQUEST_SENT') { d='<span style="color:#e17055;font-weight:bold;">'+escHtml(evt.method||'GET')+'</span> <span style="color:#0984e3;word-break:break-all;">'+escHtml((evt.url||'').substring(0,100))+'</span>'; if(evt.postData) d+='<br/><small style="color:#636e72;">Body: '+escHtml(evt.postData.substring(0,100))+'</small>'; }
            else if (evt.step==='RESPONSE_RECV') { var sc=parseInt(evt.status)||0; var sC=sc>=400?'#d63031':sc>=300?'#f39c12':'#00b894'; d='<span style="color:'+sC+';font-weight:bold;">HTTP '+evt.status+'</span> '+escHtml(evt.type||''); if(evt.duration) d+=' <span style="color:#636e72;">'+evt.duration+'ms</span>'; d+='<br/><span style="color:#999;word-break:break-all;">'+escHtml((evt.url||'').substring(0,80))+'</span>'; }
            else if (evt.step==='URL_EXTRACT') { d='从API响应中提取到播放地址<br/>字段: <span style="color:#fdcb6e;font-weight:bold;">'+escHtml(evt.field||'')+'</span><br/>URL: <span style="color:#00b894;word-break:break-all;">'+escHtml((evt.url||'').substring(0,120))+'</span>'; if(evt.sourceApi) d+='<br/><small style="color:#999;">API: '+escHtml(evt.sourceApi.substring(0,80))+'</small>'; }
            else if (evt.step==='DECRYPT') { d='算法: <span style="color:#d63031;font-weight:bold;">'+escHtml(evt.algo||'')+'</span><br/>密文: <span style="color:#636e72;">'+escHtml((evt.ciphertext||'').substring(0,60))+'</span><br/>明文: <span style="color:#00b894;">'+escHtml((evt.plaintext||'').substring(0,100))+'</span>'; }
            else if (evt.step==='MEDIA_FOUND') { var src=evt.source==='api_response'?'从API响应中解析':evt.source==='direct_request'?'直接请求媒体文件':'网络捕获'; d='<span style="color:#fdcb6e;font-weight:bold;">'+src+'</span><br/><span style="color:#00b894;word-break:break-all;font-weight:bold;">'+escHtml((evt.url||'').substring(0,120))+'</span>'; if(evt.apiUrl) d+='<br/><small style="color:#999;">API: '+escHtml(evt.apiUrl.substring(0,80))+'</small>'; }
            h += '<div class="chain-step '+cls+'"><span class="step-label">'+icon+' '+label+'</span><span class="step-time">'+time+'</span><div class="step-detail">'+d+'</div></div>';
        });
        return h;
    }

    // ── 事件绑定 ──
    function bindCardEvents() {
        list.querySelectorAll('.chain-card').forEach(function(card) {
            card.addEventListener('click', function(e) {
                if (e.target.classList.contains('chain-copy-btn')) return;
                card.classList.toggle('expanded');
            });
        });
        list.querySelectorAll('.chain-copy-btn').forEach(function(btn) {
            btn.addEventListener('click', function(e) {
                e.stopPropagation();
                navigator.clipboard.writeText(btn.dataset.url).then(function() {
                    btn.textContent = '✅'; setTimeout(function(){ btn.textContent = '复制'; }, 1500);
                });
            });
        });
    }

    // ── 刷新按钮：清窗口 + 刷新目标网页 ──
    document.getElementById('refresh-btn').addEventListener('click', function() {
        var btn = this;
        chrome.runtime.sendMessage({ action: 'CHAIN_GET_STATE' }, function(state) {
            var tabId = state && state.targetTabId;
            // 清空采集窗口
            chrome.runtime.sendMessage({ action: 'CHAIN_RESET_WINDOW' }, function() {
                _prevLiveLen = -1;
                // 刷新目标网页
                if (tabId) {
                    chrome.tabs.reload(tabId, {}, function() {
                        btn.textContent = '✅ 已刷新';
                        setTimeout(function(){ btn.textContent = '🔄 刷新网页'; }, 1200);
                    });
                } else {
                    // 没有锁定 tab，尝试刷新当前活跃 tab
                    chrome.tabs.query({ active:true, currentWindow:false }, function(tabs) {
                        var httpTab = tabs.find(function(t){ return t.url && t.url.startsWith('http'); });
                        if (httpTab) chrome.tabs.reload(httpTab.id);
                        btn.textContent = '✅ 已刷新';
                        setTimeout(function(){ btn.textContent = '🔄 刷新网页'; }, 1200);
                    });
                }
            });
        });
    });

    // ── 清空按钮 ──
    document.getElementById('clear-btn').addEventListener('click', function() {
        chrome.runtime.sendMessage({ action: 'CHAIN_CLEAR_ALL' }, function() {
            _prevChainLen = -1;
            _prevLiveLen = -1;
            list.innerHTML = '';
            countEl.textContent = '0 条';
            liveCountEl.style.display = 'none';
        });
    });

    // ── 启动轮询 ──
    setInterval(poll, 800);
    poll();
})();

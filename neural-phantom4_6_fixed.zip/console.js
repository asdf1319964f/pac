// console.js — Neural Phantom 4.5 独立控制台窗口
// 从 background.js 拉取:预挂钩状态 / 已 attach tab / 控制台统计 / 链路事件流

(function() {
    const POLL_INTERVAL_MS = 1000;

    // ── DOM refs ──
    const $ = (id) => document.getElementById(id);
    const enterUrl    = $('enter-url');
    const enterMode   = $('enter-mode');
    const enterGo     = $('enter-go');
    const enterHint   = $('enter-hint');
    const prehookState = $('prehook-state');
    const sAttached   = $('s-attached');
    const sRequests   = $('s-requests');
    const sCrypto     = $('s-crypto');
    const sDecrypt    = $('s-decrypt');
    const sSign       = $('s-sign');
    const sParam      = $('s-paramcrypto');
    const sMedia      = $('s-media');
    const sEarly      = $('s-early');
    const tabsCount   = $('tabs-count');
    const tabsList    = $('tabs-list');
    const eventsCount = $('events-count');
    const eventsList  = $('events-list');
    const eventsFilter = $('events-filter');
    const sessionInfo = $('session-info');

    let currentFilter = 'ALL';
    let lastEventLen  = -1;
    let lastAttachedKey = '';

    // ── 工具 ──
    function esc(s) {
        return String(s == null ? '' : s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    }
    function fmtTime(ts) {
        if (!ts) return '-';
        try { return new Date(ts).toLocaleTimeString(); } catch(e) { return '-'; }
    }
    function shortUrl(u, n) {
        if (!u) return '';
        u = u.replace(/^https?:\/\//,'');
        return u.length > (n||60) ? u.substring(0, n||60) + '…' : u;
    }

    // ── 保活:维持一条 port 避免 Service Worker 休眠 ──
    try {
        const keepalive = chrome.runtime.connect({ name: 'phantom-keepalive' });
        keepalive.onDisconnect.addListener(() => {
            // 重连一次
            try { chrome.runtime.connect({ name: 'phantom-keepalive' }); } catch(e) {}
        });
    } catch(e) {}

    // ══════════════════════════════════════════
    // URL 进入
    // ══════════════════════════════════════════
    function doEnter() {
        let url = (enterUrl.value || '').trim();
        if (!url) { setHint('❌ 请输入 URL', '#f04458'); return; }
        if (!/^https?:\/\//i.test(url)) url = 'https://' + url;
        const mode = enterMode.value || 'new';

        enterGo.disabled = true;
        enterGo.textContent = '⏳ 进入中…';
        setHint('⏳ attaching debugger → 清空会话 → 导航中…', '#f59e0b');

        // mode=reuse 需要目标 tabId:取当前 active tab(非本窗口)
        const send = (tabId) => {
            chrome.runtime.sendMessage({ action: 'CONSOLE_ENTER_URL', url, mode, tabId }, (res) => {
                enterGo.disabled = false;
                enterGo.textContent = '🚀 进入';
                if (!res) { setHint('❌ Service Worker 无响应,请重试', '#f04458'); return; }
                if (res.error) { setHint('❌ ' + res.error, '#f04458'); return; }
                setHint(`✅ 会话起点已重置 (tab ${res.tabId}) · 全链路抓取进行中`, '#10b981');
                // 立刻刷新面板
                pollAll();
            });
        };

        if (mode === 'reuse') {
            chrome.tabs.query({}, (tabs) => {
                // 优先选 http tab,排除自己的 popup
                const httpTab = (tabs || []).find(t => t.url && t.url.startsWith('http') && !t.url.includes('console.html'));
                if (!httpTab) { setHint('❌ 没有可复用的 http tab', '#f04458'); enterGo.disabled = false; enterGo.textContent = '🚀 进入'; return; }
                send(httpTab.id);
            });
        } else {
            send(null);
        }
    }

    function setHint(msg, color) {
        enterHint.textContent = msg;
        enterHint.style.color = color || '#9ca3af';
    }

    enterGo.addEventListener('click', (e) => { e.stopPropagation(); doEnter(); });
    enterUrl.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); doEnter(); } });

    // ══════════════════════════════════════════
    // 轮询:预挂钩状态
    // ══════════════════════════════════════════
    function pollPreHook() {
        chrome.runtime.sendMessage({ action: 'GET_PREHOOK_STATUS' }, (r) => {
            if (!r) return;
            prehookState.textContent = r.enabled ? `🛡️ ON · attach ${r.attachedTabs}` : '🛡️ OFF';
            prehookState.style.background = r.enabled ? '#eff1fe' : '#fee2e2';
            prehookState.style.color = r.enabled ? '#5b6ef5' : '#dc2626';
        });
    }

    // ══════════════════════════════════════════
    // 轮询:控制台统计
    // ══════════════════════════════════════════
    function pollStats() {
        chrome.runtime.sendMessage({ action: 'GET_CONSOLE_STATS' }, (s) => {
            if (!s) return;
            sAttached.textContent = s.attachedTabs || 0;
            sRequests.textContent = s.totalRequests || 0;
            sCrypto.textContent   = s.cryptoCalls || 0;
            sDecrypt.textContent  = s.decryptOps || 0;
            sSign.textContent     = s.signFields || 0;
            sParam.textContent    = s.paramCrypto || 0;
            sMedia.textContent    = s.mediaFound || 0;
            sEarly.textContent    = s.earlyRequestsObserved || 0;
            if (s.sessionStart) {
                sessionInfo.textContent = `${fmtTime(s.sessionStart)}${s.sessionStartUrl ? ' · ' + shortUrl(s.sessionStartUrl, 50) : ''}`;
            } else {
                sessionInfo.textContent = '-';
            }
        });
    }

    // ══════════════════════════════════════════
    // 轮询:已 attach 的 tabs
    // ══════════════════════════════════════════
    function pollAttachedTabs() {
        chrome.runtime.sendMessage({ action: 'GET_ATTACHED_TABS' }, (res) => {
            if (!res || !Array.isArray(res.tabs)) return;
            const tabs = res.tabs;
            tabsCount.textContent = tabs.length;
            // key 对比,减少不必要 DOM 操作
            const key = tabs.map(t => `${t.tabId}:${t.count}:${t.pending}:${t.errors}:${(t.url||'').substring(0,50)}`).join('|');
            if (key === lastAttachedKey) return;
            lastAttachedKey = key;

            if (!tabs.length) {
                tabsList.innerHTML = '<div class="empty">等待中… 打开任一 HTTP 页面会自动 attach</div>';
                return;
            }

            tabsList.innerHTML = tabs.map(t => {
                const short = t.url ? shortUrl(t.url, 70) : '(about:blank)';
                const errBadge = t.errors ? `<span style="color:#d63031;">⚠️${t.errors}</span>` : '';
                const pendBadge = t.pending ? `<span style="color:#f39c12;">⏳${t.pending}</span>` : '';
                return `<div class="tab-item" data-tid="${t.tabId}">
                    <span class="tid">#${t.tabId}</span>
                    <span class="turl" title="${esc(t.url || '')}">${esc(short)}</span>
                    <span class="tcnt">${t.count || 0} 请求 ${pendBadge} ${errBadge}</span>
                    <span class="tact">
                        <button data-act="reuse" data-tid="${t.tabId}">重用</button>
                        <button data-act="focus" data-tid="${t.tabId}">聚焦</button>
                    </span>
                </div>`;
            }).join('');

            tabsList.querySelectorAll('button[data-act]').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const act = btn.dataset.act;
                    const tid = +btn.dataset.tid;
                    if (act === 'reuse') {
                        enterMode.value = 'reuse';
                        // 直接把目标 tabId 塞进 enter 流程(绕过 query)
                        const url = (enterUrl.value || '').trim();
                        if (!url) { setHint('❌ 请先填 URL', '#f04458'); return; }
                        const fullUrl = /^https?:\/\//i.test(url) ? url : 'https://' + url;
                        enterGo.disabled = true;
                        enterGo.textContent = '⏳';
                        setHint(`⏳ 在 tab ${tid} 中导航…`, '#f59e0b');
                        chrome.runtime.sendMessage({ action: 'CONSOLE_ENTER_URL', url: fullUrl, mode: 'reuse', tabId: tid }, (res) => {
                            enterGo.disabled = false;
                            enterGo.textContent = '🚀 进入';
                            if (!res) { setHint('❌ 无响应', '#f04458'); return; }
                            if (res.error) { setHint('❌ ' + res.error, '#f04458'); return; }
                            setHint(`✅ tab ${res.tabId} 会话已重启`, '#10b981');
                            pollAll();
                        });
                    } else if (act === 'focus') {
                        chrome.tabs.update(tid, { active: true });
                        chrome.tabs.get(tid, (t) => { if (t && t.windowId) chrome.windows.update(t.windowId, { focused: true }); });
                    }
                });
            });
        });
    }

    // ══════════════════════════════════════════
    // 轮询:链路事件流
    // ══════════════════════════════════════════
    const stepIcons  = { PARAM_SOURCE:'📊', CRYPTO_CALL:'🔐', SIGN_FIELD:'✍️', PARAM_CRYPTO:'🧪', REQUEST_SENT:'📡', RESPONSE_RECV:'✅', URL_EXTRACT:'🎯', DECRYPT:'🔓', MEDIA_FOUND:'📺' };
    const stepLabels = { PARAM_SOURCE:'参数溯源', CRYPTO_CALL:'加密调用', SIGN_FIELD:'签名字段', PARAM_CRYPTO:'参数加密', REQUEST_SENT:'请求发出', RESPONSE_RECV:'响应接收', URL_EXTRACT:'URL提取', DECRYPT:'解密还原', MEDIA_FOUND:'媒体捕获' };

    function pollEvents() {
        chrome.runtime.sendMessage({ action: 'CHAIN_GET_STATE' }, (state) => {
            if (!state) return;
            // 优先展示全会话事件
            const events = (state.sessionEvents && state.sessionEvents.length) ? state.sessionEvents : (state.window || []);
            const filtered = currentFilter === 'ALL' ? events : events.filter(e => e.step === currentFilter);

            eventsCount.textContent = filtered.length;

            if (filtered.length === lastEventLen) return;
            lastEventLen = filtered.length;

            if (!filtered.length) {
                eventsList.innerHTML = '<div class="empty">等待事件…</div>';
                return;
            }

            // 倒序展示最近 200 条
            const shown = filtered.slice(-200).reverse();
            eventsList.innerHTML = shown.map(evt => {
                const icon = stepIcons[evt.step] || '⚪';
                const label = stepLabels[evt.step] || evt.step;
                const time = fmtTime(evt.time);
                let detail = '';
                if (evt.url) detail = shortUrl(evt.url, 80);
                else if (evt.algo) detail = evt.algo + (evt.plaintext ? ' → ' + String(evt.plaintext).substring(0,30) : '');
                else if (evt.field) detail = `${evt.field}=${String(evt.value||'').substring(0,40)}`;
                else if (evt.key)   detail = `${evt.key}=${String(evt.value||'').substring(0,40)}`;
                return `<div class="event-line">
                    <span class="eicon">${icon}</span>
                    <span class="elabel">${label}</span>
                    <span class="edetail" title="${esc(detail)}">${esc(detail)}</span>
                    <span class="etime">${time}</span>
                </div>`;
            }).join('');
        });
    }

    eventsFilter.addEventListener('change', () => {
        currentFilter = eventsFilter.value || 'ALL';
        lastEventLen = -1; // 强制重渲染
        pollEvents();
    });

    // ══════════════════════════════════════════
    // 底部按钮
    // ══════════════════════════════════════════
    $('open-chain').addEventListener('click', (e) => {
        e.stopPropagation();
        chrome.runtime.sendMessage({ action: 'CHAIN_OPEN_WINDOW' });
    });

    $('export-session').addEventListener('click', (e) => {
        e.stopPropagation();
        chrome.runtime.sendMessage({ action: 'CHAIN_GET_STATE' }, (state) => {
            if (!state) return;
            const data = {
                sessionStart: state.sessionStart,
                sessionStartUrl: state.sessionStartUrl,
                chains: state.chains || [],
                events: state.sessionEvents || state.window || [],
                exportedAt: new Date().toISOString()
            };
            const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `phantom-session-${Date.now()}.json`;
            document.body.appendChild(a);
            a.click();
            a.remove();
            URL.revokeObjectURL(url);
        });
    });

    $('reset-session').addEventListener('click', (e) => {
        e.stopPropagation();
        if (!confirm('重置视频会话起点为此刻?(清空事件窗口)')) return;
        chrome.runtime.sendMessage({ action: 'CHAIN_RESET_SESSION' }, () => {
            lastEventLen = -1;
            pollAll();
        });
    });

    $('clear-all').addEventListener('click', (e) => {
        e.stopPropagation();
        if (!confirm('清空所有已完成链路 + 事件窗口 + 会话事件?')) return;
        chrome.runtime.sendMessage({ action: 'CHAIN_CLEAR_ALL' }, () => {
            lastEventLen = -1;
            pollAll();
        });
    });

    // ══════════════════════════════════════════
    // 轮询:函数调用热点(按栈帧聚合)
    // ══════════════════════════════════════════
    let lastHotspotKey = '';
    function pollHotspots() {
        chrome.runtime.sendMessage({ action: 'GET_FRAME_HOTSPOTS', limit: 15 }, (res) => {
            if (!res) return;
            const list = $('hotspots-list');
            const cnt  = $('hotspots-count');
            const hs = res.hotspots || [];
            cnt.textContent = hs.length;
            const key = hs.map(h => `${h.file}:${h.line}:${h.count}`).join('|');
            if (key === lastHotspotKey) return;
            lastHotspotKey = key;
            if (!hs.length) {
                list.innerHTML = '<div class="empty">等待事件... 浏览页面后自动归并</div>';
                return;
            }
            list.innerHTML = hs.map(h => {
                const base = (h.file || '').split('?')[0].split('/').pop() || h.file;
                const stepStr = Object.keys(h.steps || {}).map(s => stepIcons[s] || '•').join('');
                return `<div class="hot-item">
                    <span class="hfn" title="${esc(h.fn||'<anon>')}">${esc(h.fn || '<anon>')}</span>
                    <span class="hloc" title="${esc(h.file)}:${h.line}:${h.col||1}" data-file="${esc(h.file)}" data-line="${h.line}">${esc(base)}:${h.line}</span>
                    <span class="hsteps" title="${esc(Object.entries(h.steps).map(([k,v])=>`${k}×${v}`).join(' '))}">${stepStr}</span>
                    <span class="hcnt">×${h.count}</span>
                </div>`;
            }).join('');
            // 点击位置在新标签打开(console window 无法直接打开主页面的 source viewer)
            list.querySelectorAll('.hloc').forEach(el => {
                el.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const file = el.dataset.file;
                    if (file) window.open(file, '_blank');
                });
            });
        });
    }

    // ══════════════════════════════════════════
    // 轮询:最近函数调用(来自 funcTraceStore)
    // ══════════════════════════════════════════
    let lastFuncTraceLen = -1;
    function pollFuncTraces() {
        chrome.runtime.sendMessage({ action: 'GET_FUNC_TRACES', limit: 30 }, (res) => {
            if (!res) return;
            const list = $('functrace-list-c');
            const cnt  = $('functrace-count-c');
            const traces = res.traces || [];
            cnt.textContent = traces.length;
            if (traces.length === lastFuncTraceLen) return;
            lastFuncTraceLen = traces.length;
            if (!traces.length) {
                list.innerHTML = '<div class="empty">在主面板 🔭 函数追踪 Tab 挂钩函数后显示</div>';
                return;
            }
            list.innerHTML = traces.map(t => {
                const color = t.error ? '#ef4444' : t.isAsync ? '#a29bfe' : '#5b6ef5';
                const tag   = t.error ? 'ERR'    : t.isAsync ? 'ASY'    : 'SYN';
                const argsPreview = (t.args || []).map(a => String(a).substring(0, 40)).join(', ');
                const dur = t.durationMs != null ? `${t.durationMs}ms` : '';
                return `<div class="ft-item" title="args: ${esc(argsPreview)}${t.returnVal!=null?'\\nreturn: '+esc(String(t.returnVal).substring(0,120)):''}">
                    <span class="ftag" style="background:${color};">${tag}</span>
                    <span class="flabel">${esc(t.label || '?')}</span>
                    <span class="fargs">args[${(t.args||[]).length}]${argsPreview?' · '+esc(argsPreview.substring(0,60)):''}</span>
                    <span class="fdur">${esc(dur)}</span>
                    <span class="ftime">${esc(t.time || '')}</span>
                </div>`;
            }).join('');
        });
    }

    // ══════════════════════════════════════════
    // 轮询:媒体请求列表(校验溯源下拉框)
    // ══════════════════════════════════════════
    const VERDICT_META = {
        BROWSER_AUTO:      { icon:'🌐', color:'#6b7280', label:'浏览器自动' },
        FROM_SET_COOKIE:   { icon:'🍪', color:'#10b981', label:'Set-Cookie 下发' },
        FROM_RESPONSE_BODY:{ icon:'📥', color:'#0984e3', label:'响应体透传' },
        JS_CRYPTO:         { icon:'🔐', color:'#8b5cf6', label:'JS 加密产物' },
        CLIENT_TRACKER:    { icon:'📊', color:'#f59e0b', label:'统计 SDK 生成' },
        UNKNOWN:           { icon:'❓', color:'#9ca3af', label:'未知来源' },
        UNKNOWN_JS:        { icon:'⚙️', color:'#e17055', label:'JS 设置' }
    };
    let mediaList = [];
    let selectedMediaId = '';
    let autoAnalyzedForId = '';

    function pollAuthMediaList() {
        chrome.runtime.sendMessage({ action: 'GET_RECENT_MEDIA_REQUESTS', limit: 10 }, (res) => {
            if (!res || !Array.isArray(res.media)) return;
            mediaList = res.media;
            $('auth-media-count').textContent = mediaList.length;
            const sel = $('auth-media-select');
            const prev = sel.value;
            const keyNow = mediaList.map(m => m.id).join('|');
            if (sel.dataset.key === keyNow) return;
            sel.dataset.key = keyNow;
            sel.innerHTML = '<option value="">自动选最新</option>' + mediaList.map(m => {
                const short = shortUrl(m.url, 60);
                return `<option value="${esc(m.id)}" title="${esc(m.url)}">${esc(m.method || 'GET')} · ${esc(short)}</option>`;
            }).join('');
            sel.value = prev || '';

            // 自动分析:最新一条且未分析过,则触发
            if (!selectedMediaId && mediaList.length && mediaList[0].id !== autoAnalyzedForId) {
                autoAnalyzedForId = mediaList[0].id;
                runAuthAnalysis(mediaList[0]);
            }
        });
    }

    function runAuthAnalysis(target) {
        const result = $('auth-result');
        if (!target) {
            result.innerHTML = '<div class="empty">尚无媒体请求</div>';
            return;
        }
        result.innerHTML = `<div style="font-size:10px;color:#f59e0b;padding:6px;">⏳ 分析 ${esc(shortUrl(target.url, 80))}...</div>`;
        chrome.runtime.sendMessage({ action: 'ANALYZE_REQUEST_AUTH', requestId: target.id, url: target.url }, (res) => {
            if (!res) { result.innerHTML = '<div style="color:#ef4444;font-size:11px;padding:6px;">❌ 后台无响应</div>'; return; }
            if (res.error) { result.innerHTML = `<div style="color:#ef4444;font-size:11px;padding:6px;">❌ ${esc(res.error)}</div>`; return; }
            result.innerHTML = renderAuthAnalysis(res);
        });
    }

    function renderAuthAnalysis(res) {
        const { url, method, time, headers = [], cookies = [], tally = {} } = res;
        const tallyBadges = Object.entries(tally).filter(([,v])=>v>0).map(([k,v]) => {
            const meta = VERDICT_META[k] || VERDICT_META.UNKNOWN;
            return `<span style="background:${meta.color}20;color:${meta.color};border:1px solid ${meta.color}40;font-size:10px;padding:2px 7px;border-radius:10px;font-weight:600;margin-right:4px;" title="${esc(meta.label)}">${meta.icon} ${v}</span>`;
        }).join('');
        let h = `<div style="padding:6px 0 10px;border-bottom:1px dashed #e4e7f0;margin-bottom:8px;">
            <div style="font-size:11px;font-weight:700;color:#1a1d2e;margin-bottom:4px;">${esc(method||'GET')} <span style="color:#0984e3;font-family:monospace;">${esc(shortUrl(url,80))}</span></div>
            <div>${tallyBadges}</div>
        </div>`;
        if (cookies.length) {
            h += `<div style="margin-bottom:8px;"><div style="font-size:11px;color:#6b7280;font-weight:700;margin-bottom:4px;">🍪 Cookie (${cookies.length} 项)</div>`;
            h += cookies.map(renderAuthRow).join('');
            h += '</div>';
        }
        const nonAuto = headers.filter(x => x.verdict !== 'BROWSER_AUTO');
        const autoHdrs = headers.filter(x => x.verdict === 'BROWSER_AUTO');
        if (nonAuto.length) {
            h += `<div style="margin-bottom:8px;"><div style="font-size:11px;color:#6b7280;font-weight:700;margin-bottom:4px;">⚡ 关键自定义头 (${nonAuto.length})</div>`;
            h += nonAuto.map(renderAuthRow).join('');
            h += '</div>';
        }
        if (autoHdrs.length) {
            h += `<details style="margin-top:6px;"><summary style="font-size:10px;color:#9ca3af;cursor:pointer;">🌐 浏览器自动头 (${autoHdrs.length}) · 展开</summary><div style="margin-top:4px;">`;
            h += autoHdrs.map(renderAuthRow).join('');
            h += '</div></details>';
        }
        return h;
    }

    function renderAuthRow(item) {
        const meta = VERDICT_META[item.verdict] || VERDICT_META.UNKNOWN;
        const d = item.details || {};
        let sub = '';
        if (item.verdict === 'FROM_SET_COOKIE') {
            sub = `<div style="font-size:10px;color:#10b981;margin-top:3px;word-break:break-all;">↳ 由 <span style="font-family:monospace;">${esc(shortUrl(d.setFromUrl||'',70))}</span> 在 ${esc(d.time||'')} 下发</div>`;
        } else if (item.verdict === 'FROM_RESPONSE_BODY') {
            const s0 = d.sources && d.sources[0];
            if (s0) sub = `<div style="font-size:10px;color:#0984e3;margin-top:3px;word-break:break-all;">↳ 命中 <span style="font-family:monospace;">${esc(shortUrl(s0.url||'',70))}</span> [${esc(s0.source||'')}]${s0.preview?' · '+esc(String(s0.preview).substring(0,40)):''}</div>`;
        } else if (item.verdict === 'JS_CRYPTO') {
            const f0 = (d.frames||[])[0];
            const locStr = f0 ? `${(f0.file||'').split('/').pop()}:${f0.line}:${f0.col}` : '';
            sub = `<div style="font-size:10px;color:#8b5cf6;margin-top:3px;">↳ <b>${esc(d.algo||'')}</b> · ${esc(d.hint||'')}${f0?` · ${esc(locStr)}`:''}</div>`;
        } else if (item.verdict === 'CLIENT_TRACKER') {
            sub = `<div style="font-size:10px;color:#f59e0b;margin-top:3px;">↳ ${esc(d.tracker||'')} · ${esc(d.hint||'')}</div>`;
        } else if (item.verdict === 'UNKNOWN' || item.verdict === 'UNKNOWN_JS') {
            sub = `<div style="font-size:10px;color:#9ca3af;margin-top:3px;">↳ ${esc(d.hint||'')}</div>`;
        }
        return `<div style="padding:5px 8px;background:${meta.color}08;border-left:3px solid ${meta.color};border-radius:4px;margin-bottom:4px;">
            <div style="display:flex;gap:5px;align-items:center;font-size:11px;flex-wrap:wrap;">
                <span style="flex-shrink:0;">${meta.icon}</span>
                <code style="background:#f1f5f9;padding:1px 6px;border-radius:3px;color:#1a1d2e;">${esc(item.name)}</code>
                <span style="font-family:monospace;color:#6b7280;font-size:10px;flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="${esc(item.value)}">${esc(item.value)}</span>
                <span style="color:${meta.color};font-size:10px;font-weight:600;flex-shrink:0;">${esc(meta.label)}</span>
            </div>
            ${sub}
        </div>`;
    }

    $('auth-media-select').addEventListener('change', (e) => {
        selectedMediaId = e.target.value;
        if (selectedMediaId) {
            const target = mediaList.find(m => m.id === selectedMediaId);
            if (target) runAuthAnalysis(target);
        } else {
            autoAnalyzedForId = ''; // 重置,让自动分析重新挑最新
            if (mediaList.length) runAuthAnalysis(mediaList[0]);
        }
    });
    $('auth-analyze-btn').addEventListener('click', (e) => {
        e.stopPropagation();
        const id = $('auth-media-select').value;
        const target = id ? mediaList.find(m => m.id === id) : mediaList[0];
        if (!target) { $('auth-result').innerHTML = '<div class="empty">尚无媒体请求</div>'; return; }
        runAuthAnalysis(target);
    });

    // ══════════════════════════════════════════
    // 统一轮询
    // ══════════════════════════════════════════
    function pollAll() {
        pollPreHook();
        pollStats();
        pollAttachedTabs();
        pollEvents();
        pollHotspots();
        pollFuncTraces();
        pollAuthMediaList();
    }

    // 启动
    pollAll();
    setInterval(pollAll, POLL_INTERVAL_MS);
})();

// inject.js - Neural Phantom 4.1 绝对完整版 (已打入脚本标签样式修复补丁)

// [1] 隐匿技术:阻止页面检测到调试环境
try { Object.defineProperty(navigator, 'webdriver', { get: () => undefined }); } catch(e) {}

// [2] page-script.js 现已通过 manifest content_scripts 的 MAIN world 直接注入,
//     无需再手动插入 <script> 标签(省去几十毫秒延迟,赶在页面任何 JS 之前挂钩)

// ==========================================
// 全局状态变量
// ==========================================
let panelRoot = null;
let panelHost = null;
let isPanelOpen = false;
let logsMap = new Map();
let currentTypeFilter = 'ALL';
let currentSearchText = '';
let mockRules = [];
let dynamicScript = '';
let localFileRules = [];       // 本地文件替换规则
let cssInjections = [];        // CSS 注入规则
let isBreakpointEnabled = false;
let breakpointFilter = '';
let showStarredOnly = false;
let starredSet = new Set();
let diffTargetA = null;        // Diff 对比 A
let diffTargetB = null;        // Diff 对比 B

// ── 密钥库（Key Vault）──
let keyVault = [];          // { id, type, value, source, time, tag, pinned }
let keyVaultPinned = new Set();

// WS 拦截状态变量
let wsModifyRules = [];
let wsBreakpointEnabled = false;
let wsBreakpointKeyword = '';

// AI 配置变量
let openAIKey = '';
let aiModel = 'gpt-3.5-turbo';
let codeModel = 'claude-haiku-4.5-20251001';
let apiHost = 'https://api.openai.com';

// ── POST 缓存库（持久化，过期也能查看）──
let postCacheStore = [];
const MAX_POST_CACHE = 300;

// ── 全流量缓存库（GET+POST 全部持久化，支持关键字搜索+高亮）──
let trafficCacheStore = [];
const MAX_TRAFFIC_CACHE = 500;
let trafficMethodFilter = 'ALL';
let trafficSearchKeyword = '';
chrome.storage.local.get(['trafficCacheStore'], (res) => {
    if (res.trafficCacheStore) trafficCacheStore = res.trafficCacheStore;
});

// ── Cookie 时间线存储 ──
let cookieTimeline = [];
const MAX_COOKIE_EVENTS = 500;

// ── 媒体嗅探缓存 ──
let mediaSniffCache = [];

// POST 缓存库多维过滤状态
let pcFilter = { methods: new Set(['ALL']), status: 'ALL', body: 'ALL', minMs: 0 };
chrome.storage.local.get(['postCacheStore'], (res) => {
    if (res.postCacheStore) postCacheStore = res.postCacheStore;
});

// ── 函数调用追踪存储 ──
let funcTraceStore = [];       // { label, args[], returnVal, stack[], durationMs, time, isAsync, error }
let funcHookedList = [];       // 已挂钩的函数名列表
const MAX_FUNC_TRACE = 500;

// ── 解密猎手存储 ──
let decryptStore = [];         // { algo, ciphertext, key, plaintext, stack[], time }
const MAX_DECRYPT = 300;

// ── 参数加密检测存储 ──
let paramCryptoStore = [];     // { key, value, detected[], decoded[], url, method, time }
const MAX_PARAM_CRYPTO = 500;
let paramCryptoTypeFilter = 'ALL';

// ── 🎬 视频链路逆向 状态 ──
let videoChainMode = 'short';               // 'short' | 'session'
let videoChainTimer = null;                 // 刷新轮询
let videoChainEventsFilter = 'ALL';         // 时间线事件类型过滤
let videoChainScriptsFilter = '';           // 脚本文件名模糊过滤
let videoChainScriptsOnlyActive = false;    // 仅显示有加密/网络活动的脚本
// scriptRegistry key=url,value={url, mime, size, loadTime, cryptoCount, requestCount, decryptCount, mediaRefs:Set, signalCount}
let scriptRegistry = new Map();
let scriptEventsByUrl = new Map();          // url → 该文件触发的事件数组(用于展开详情)


// ==========================================
// 消息通信监听
// ==========================================
chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === 'REDIRECT_M3U8') {
        window.postMessage({ type: 'ADD_REDIRECT_RULE', original: msg.original, clean: msg.clean }, '*');
    }
    if (msg.action === 'TOGGLE_PICKER') { togglePickerMode(); }
    if (msg.action === 'TOGGLE_PANEL') { toggleDashboard(); }
    if (msg.action === 'SYNC_LOG' && isPanelOpen && panelRoot) {
        processLog(msg.data);
    }
    if (msg.action === 'SYNC_LOG' && msg.data && msg.data.status && msg.data.status !== 'Pending') {
        saveToPostCache(msg.data);
    }
    // 全流量缓存：所有请求（含 Pending）都存入
    if (msg.action === 'SYNC_LOG' && msg.data) {
        saveToTrafficCache(msg.data);
    }
    // 🎬 视频链路:脚本注册与网络计数
    if (msg.action === 'SYNC_LOG' && msg.data) {
        updateScriptRegistry(msg.data);
    }
    if (msg.action === 'KEY_FOUND') {
        msg.keys.forEach(k => {
            k.keys.forEach(val => {
                addToKeyVault({ type: k.type, value: val, source: msg.url, category: 'RESPONSE' });
            });
        });
        if (isPanelOpen && panelRoot) {
            const auditPane = panelRoot.getElementById('tracer-results');
            if (auditPane) {
                msg.keys.forEach(k => {
                    k.keys.forEach(val => {
                        const div = document.createElement('div');
                        div.className = 'key-alert';
                        div.innerHTML = buildKeyAlertHTML({ type: k.type, value: val, source: msg.url, category: 'RESPONSE' });
                        auditPane.prepend(div);
                        bindKeyAlertEvents(div);
                    });
                });
            }
        }
    }
    if (msg.action === 'SENSITIVE_FIELD_FOUND') {
        msg.fields.forEach(f => {
            addToKeyVault({ type: 'SensitiveField:' + f.field, value: f.preview, source: msg.url, category: 'FIELD' });
        });
        if (isPanelOpen && panelRoot) {
            const auditPane = panelRoot.getElementById('tracer-results');
            if (auditPane) {
                const div = document.createElement('div');
                div.className = 'key-alert';
                div.style.cssText = 'border-color:#fdcb6e; background:rgba(253,203,110,0.09); padding:10px; margin-bottom:8px; border-radius:6px; font-size:11px;';
                const fields = msg.fields.map(f => `<code style="background:#fef3c7;padding:1px 4px;border-radius:3px;">${f.field}</code>: <span style="font-family:monospace;color:#b45309;">${f.preview}</span>`).join('<br/>');
                div.innerHTML = `<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;">
                    <span>🔑 <b>敏感字段泄露</b></span>
                    <span style="background:#f59e0b;color:#fff;font-size:9px;padding:1px 6px;border-radius:10px;font-weight:700;">FIELD</span>
                </div>
                <small style="word-break:break-all;color:#6b7280;">${msg.url}</small><br/><div style="margin-top:4px;">${fields}</div>`;
                auditPane.prepend(div);
            }
        }
    }
    // 参数来源分析结果实时推送
    if (msg.action === 'PARAM_ANALYZED' && isPanelOpen && panelRoot) {
        renderParamAnalysis(msg.trace, msg.analysis);
        // 链路追踪：参数来源事件
        (msg.analysis || []).forEach(function(a) {
            chrome.runtime.sendMessage({ action: 'CHAIN_PUSH_EVENT', evt: { step: 'PARAM_SOURCE', key: a.key, value: (a.value || '').substring(0, 60), verdict: a.verdict, fromUrl: (a.fromResponse && a.fromResponse[0]) ? a.fromResponse[0].url : '', frames: (msg.trace && msg.trace.frames) || [] } });
        });
    }

    // 响应体就绪通知 — 如果模态框正在等待此请求，自动刷新
    if (msg.action === 'BODY_READY' && isPanelOpen && panelRoot) {
        const modal = panelRoot.getElementById('modal-viewer');
        if (modal && modal.style.display !== 'none') {
            const codeEl = panelRoot.getElementById('code-content');
            if (codeEl && codeEl.dataset.waitingId === msg.requestId) {
                const item = logsMap.get(msg.requestId);
                if (item) showLogContent(item, true);
            }
        }
    }
    // Schema 变更告警
    if (msg.action === 'SCHEMA_CHANGED' && isPanelOpen && panelRoot) {
        const changesEl = panelRoot.getElementById('schema-changes');
        const changeList = panelRoot.getElementById('schema-change-list');
        if (changesEl && changeList) {
            changesEl.style.display = 'block';
            msg.changes.forEach(c => {
                const d = document.createElement('div');
                d.style.cssText = 'font-size:11px; padding:4px 0; font-family:monospace;';
                const colors = { ADDED: '#00b894', REMOVED: '#d63031', TYPE_CHANGED: '#f39c12' };
                d.innerHTML = `<span style="color:${colors[c.type]}; font-weight:bold;">[${c.type}]</span> <span style="color:#2d3436;">${c.path}</span> <span style="color:#636e72;">${c.oldType||''} → ${c.newType||''}</span>`;
                changeList.prepend(d);
            });
            const urlLbl = document.createElement('div');
            urlLbl.style.cssText = 'font-size:10px; color:#0984e3; padding:2px 0 6px; font-family:monospace; word-break:break-all;';
            urlLbl.textContent = `📍 ${msg.url}`;
            changeList.prepend(urlLbl);
        }
    }
    // 条件告警命中
    if (msg.action === 'ALERT_HIT' && panelRoot) {
        const hitList = panelRoot.getElementById('alert-hit-list');
        if (hitList) {
            const d = document.createElement('div');
            d.style.cssText = 'font-size:11px; padding:6px; border-left:3px solid #d63031; background:#fff5f5; margin-bottom:4px; border-radius:0 4px 4px 0;';
            d.innerHTML = `<b style="color:#d63031;">${msg.rule.name}</b> <span style="color:#636e72;">${msg.log.method} ${msg.log.url.substring(0,60)}${msg.log.url.length>60?'...':''}</span> <span style="color:#999; float:right;">${new Date().toLocaleTimeString()}</span>`;
            hitList.prepend(d);
            if (hitList.children.length > 20) hitList.lastElementChild.remove();
        }
    }
    // HAR 请求回放执行
    if (msg.action === 'HAR_REPLAY_REQUEST') {
        const opts = { method: msg.method, headers: msg.headers || {} };
        if (msg.body) opts.body = msg.body;
        fetch(msg.url, opts).catch(() => {});
    }

    // 断点中止 — 转发给 page-script
    if (msg.action === 'ABORT_REQUEST_FROM_UI') {
        window.postMessage({ type: 'ABORT_REQUEST', requestId: msg.requestId, __phantom_origin: true }, '*');
    }
    // WebSocket 实时帧推送
    if (msg.action === 'WS_FRAME' && isPanelOpen && panelRoot) {
        const wsPane = panelRoot.getElementById('ws-frame-list');
        if (wsPane) appendWsFrame(wsPane, msg.dir, msg.frame, msg.requestId);
    }
    if (msg.action === 'WS_EVENT' && isPanelOpen && panelRoot) {
        const wsPane = panelRoot.getElementById('ws-frame-list');
        if (wsPane) {
            const d = document.createElement('div');
            d.style.cssText = 'color:#636e72; font-size:10px; padding:4px 10px; border-bottom:1px dashed #eee;';
            d.textContent = `── WebSocket ${msg.event.toUpperCase()} : ${msg.url || ''} ──`;
            wsPane.prepend(d);
        }
    }
});

// 监听来自 page-script.js 的底层消息
window.addEventListener('message', (event) => {
    const data = event.data;
    if (!data || data.__phantom_origin) return;

    // 🎬 视频链路:对所有带 frames 的事件做脚本归属统计
    if (data && (data.type === 'CRYPTO_REPORT' || data.type === 'FUNC_TRACE' || data.type === 'DECRYPT_FOUND' || data.type === 'PARAM_TRACE' || data.type === 'PARAM_CRYPTO_FOUND' || data.type === 'SIGN_FIELD_FOUND')) {
        attributeEventToScript(data);
    }

    if (data.type === 'REQUEST_PAUSED_INTERNAL') {
        showBreakpointModal(data.details);
    }

    // Storage 实时监控日志
    if (data.type === 'STORAGE_EVENT' && isPanelOpen && panelRoot) {
        const logTab = panelRoot.getElementById('storage-log-tab');
        if (logTab && panelRoot.getElementById('storage-watch-toggle')?.checked) {
            const opColors = { ADD:'#00b894', SET:'#0984e3', REMOVE:'#d63031', CLEAR:'#e17055' };
            const div = document.createElement('div');
            div.style.cssText = `padding:3px 8px; border-bottom:1px solid #f1f3f5; display:flex; gap:8px; align-items:baseline;`;
            div.innerHTML = `<span style="color:${opColors[data.op]||'#636e72'}; font-weight:bold; min-width:45px;">${data.op}</span>
                <span style="color:#6c5ce7; font-family:monospace; min-width:80px;">[${data.storage}]</span>
                <span style="color:#2d3436; font-family:monospace; word-break:break-all; flex:1;">${escHtml(data.key)}</span>
                <span style="color:#636e72; font-family:monospace; max-width:120px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="${escHtml(String(data.value||''))}">${escHtml(String(data.value||'').substring(0,40))}</span>
                <span style="color:#999; font-size:9px;">${new Date().toLocaleTimeString()}</span>`;
            logTab.prepend(div);
            if (logTab.children.length > 200) logTab.lastElementChild?.remove();
        }
    }

    // Storage 快照结果
    if (data.type === 'STORAGE_DUMP_RESULT' && isPanelOpen && panelRoot) {
        renderStorageKV('storage-local-tab', data.local || {});
        renderStorageKV('storage-session-tab', data.session || {});
        // 导出 JSON 文件
        const blob = new Blob([JSON.stringify({ localStorage: data.local, sessionStorage: data.session, url: data.url, timestamp: new Date().toISOString() }, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url; a.download = `phantom-storage-${Date.now()}.json`;
        document.body.appendChild(a); a.click(); a.remove();
        URL.revokeObjectURL(url);
    }

    // WS Hook 帧日志
    if ((data.type === 'WS_HOOK_SENT' || data.type === 'WS_HOOK_RECV' || data.type === 'WS_HOOK_MODIFIED') && isPanelOpen && panelRoot) {
        const log = panelRoot.getElementById('ws-intercept-log');
        if (!log) return;
        // 断点检查
        const kw = wsBreakpointKeyword;
        const shouldPause = wsBreakpointEnabled && (!kw || String(data.data).includes(kw));
        const div = document.createElement('div');
        div.style.cssText = `padding:4px 8px; border-bottom:1px solid #f1f3f5; font-size:10px; ${shouldPause ? 'background:#fff3cd;' : ''}`;
        const dir = data.type === 'WS_HOOK_SENT' ? '↑ SENT' : data.type === 'WS_HOOK_RECV' ? '↓ RECV' : '✏️ MOD';
        const col = data.type === 'WS_HOOK_SENT' ? '#e17055' : data.type === 'WS_HOOK_RECV' ? '#00b894' : '#a29bfe';
        div.innerHTML = `<span style="color:${col}; font-weight:bold; margin-right:8px;">${dir}</span>
            <span style="color:#636e72; margin-right:8px; font-size:9px;">${data.wsId?.slice(-6)||''}</span>
            <span style="color:#2d3436; word-break:break-all;">${escHtml(String(data.data || data.modified || '').substring(0, 200))}</span>
            ${shouldPause ? `<button class="ws-bp-resume btn-small" data-wsid="${data.wsId}" data-data="${escHtml(String(data.data||''))}" style="margin-left:8px; background:#00b894; padding:2px 6px; font-size:9px;">▶ 放行</button>
            <button class="ws-bp-abort btn-small" data-wsid="${data.wsId}" style="margin-left:4px; background:#e74c3c; padding:2px 6px; font-size:9px;">✕ 丢弃</button>` : ''}`;
        if (shouldPause) {
            div.querySelector('.ws-bp-resume').onclick = (e) => {
                e.stopPropagation();
                window.postMessage({ type: 'WS_FRAME_RESUME', wsId: data.wsId, __phantom_origin: true }, '*');
                div.style.background = '';
                e.target.remove(); div.querySelector('.ws-bp-abort')?.remove();
            };
            div.querySelector('.ws-bp-abort').onclick = (e) => {
                e.stopPropagation();
                window.postMessage({ type: 'WS_FRAME_ABORT', wsId: data.wsId, __phantom_origin: true }, '*');
                div.style.background = '#ffe4e4';
                e.target.remove(); div.querySelector('.ws-bp-resume')?.remove();
            };
        }
        log.prepend(div);
        if (log.children.length > 300) log.lastElementChild?.remove();
    }

    // 监听底层的加密挂钩报告
    // 监听来自 page-script.js 的底层消息
    if (data.type === 'CRYPTO_REPORT') {
        // 链路追踪：加密调用事件 → 转发给 background
        chrome.runtime.sendMessage({ action: 'CHAIN_PUSH_EVENT', evt: { step: 'CRYPTO_CALL', algo: data.algo, plaintext: String(data.in).substring(0, 200), key: String(data.key).substring(0, 100), trace: data.trace, frames: data.frames || [] } });
        // 自动提取密钥值到 Vault
        const cryptoVal = data.key && data.key.length > 3 && !data.key.startsWith('(') ? data.key : data.in;
        addToKeyVault({ type: data.algo, value: cryptoVal, source: data.trace || window.location.hostname, category: 'CRYPTO' });
        if (isPanelOpen && panelRoot) {
            const auditPane = panelRoot.getElementById('tracer-results');
            if (auditPane) {
                const div = document.createElement('div');
                div.className = 'key-alert';
                div.style.cssText = 'border-color:#6c5ce7; background:rgba(108,92,231,0.08); padding:10px; margin-bottom:8px; border-radius:6px; font-size:11px; color:#333;';
                div.innerHTML = `<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;">
                    <span>🔐 <b>[${data.algo}] 加密拦截</b></span>
                    <div style="display:flex;gap:4px;">
                        <span style="background:#6c5ce7;color:#fff;font-size:9px;padding:1px 6px;border-radius:10px;font-weight:700;">CRYPTO</span>
                        <button class="btn-small kv-save-btn" style="background:#10b981;padding:2px 7px;font-size:10px;" data-val="${escHtml(cryptoVal)}" data-type="${data.algo}">📥 入库</button>
                        <button class="btn-small ai-reverse-sign" style="background:#d63031;padding:2px 7px;font-size:10px;">🤖 AI逆向</button>
                    </div>
                </div>
                <div><b>明文:</b> <span style="color:#d63031;font-family:monospace;word-break:break-all;">${escHtml(String(data.in).substring(0,200))}</span></div>
                <div><b>密钥:</b> <span style="color:#0984e3;font-family:monospace;word-break:break-all;">${escHtml(String(data.key).substring(0,200))}</span>
                    <button class="btn-small copy-key-val" style="background:#4f6ef7;padding:2px 6px;font-size:9px;margin-left:6px;" data-val="${escHtml(String(data.key))}">复制</button>
                </div>
                <small style="color:#9ca3af;">位置: ${escHtml(data.trace||'')}</small>`;
                div.querySelector('.kv-save-btn').onclick = (e) => {
                    e.stopPropagation();
                    addToKeyVault({ type: data.algo, value: cryptoVal, source: window.location.hostname, category: 'CRYPTO', pinned: true });
                    renderKeyVault();
                    e.target.textContent = '✅ 已入库'; e.target.disabled = true;
                };
                div.querySelector('.copy-key-val').onclick = (e) => {
                    e.stopPropagation();
                    navigator.clipboard.writeText(data.key).then(() => { e.target.textContent = '✅'; setTimeout(()=>e.target.textContent='复制',1500); });
                };
                div.querySelector('.ai-reverse-sign').onclick = (e) => {
                    e.stopPropagation();
                    if (!openAIKey) { alert('请先在设置中配置 API Key'); return; }
                    const aiContent = `Algorithm: ${data.algo}\nPlaintext sample: ${data.in}\nKey/IV: ${data.key}\nStack: ${data.trace}`;
                    e.target.textContent = '⏳ 分析中...'; e.target.disabled = true;
                    sendAIMessage({ action: 'ANALYZE_WITH_AI', content: aiContent, apiKey: openAIKey, apiHost, promptType: 'SIGN_REVERSE', model: codeModel }, (res) => {
                        e.target.textContent = '✅ 完成'; e.target.disabled = false;
                        const result = document.createElement('div');
                        result.style.cssText = 'margin-top:8px;padding:8px;background:#1e1e1e;color:#9cdcfe;font-family:monospace;font-size:10px;border-radius:4px;white-space:pre-wrap;word-break:break-all;max-height:200px;overflow-y:auto;';
                        result.textContent = !res ? '❌ Service Worker 已休眠，请刷新页面重试' : res.error ? '❌ ' + res.error : res.result;
                        div.appendChild(result);
                    });
                };
                auditPane.prepend(div);
            }
        }
    }

    // 参数追踪事件：转发给 background 做交叉分析
    if (data.type === 'PARAM_TRACE') {
        chrome.runtime.sendMessage({ action: 'PARAM_TRACE_EVENT', trace: data });
    }

    // ── 函数调用追踪结果 ──
    if (data.type === 'FUNC_TRACE') {
        const entry = {
            id: Date.now().toString(36) + Math.random().toString(36).substr(2,4),
            label: data.label,
            args: data.args || [],
            returnVal: data.returnVal,
            error: data.error,
            isAsync: data.isAsync,
            stack: data.stack || [],
            durationMs: data.durationMs,
            time: new Date(data.time).toLocaleTimeString()
        };
        funcTraceStore.unshift(entry);
        if (funcTraceStore.length > MAX_FUNC_TRACE) funcTraceStore.pop();
        // 同时转发给 background,供控制台独立窗口读取
        try { chrome.runtime.sendMessage({ action: 'FUNC_TRACE_PUSH', entry: entry }); } catch(e) {}
        if (isPanelOpen && panelRoot) renderFuncTrace();
    }

    // ── 追踪函数挂钩结果 ──
    if (data.type === 'TRACE_FUNCTION_RESULT') {
        if (isPanelOpen && panelRoot) {
            const statusEl = panelRoot.getElementById('functrace-hook-status');
            if (statusEl) {
                if (data.ok) {
                    const label = data.target || '?';
                    if (!funcHookedList.includes(label)) funcHookedList.push(label);
                    statusEl.innerHTML = `<span style="color:#10b981;">✅ 已挂钩: ${escHtml(label)} (${data.count}个)</span>`;
                    renderFuncHookedList();
                } else {
                    statusEl.innerHTML = `<span style="color:#ef4444;">❌ ${escHtml(data.error||'挂钩失败')}</span>`;
                }
            }
        }
    }

    // ── 解密猎手：拦截到解密操作 ──
    if (data.type === 'DECRYPT_FOUND') {
        // 链路追踪：解密操作事件 → 转发给 background
        chrome.runtime.sendMessage({ action: 'CHAIN_PUSH_EVENT', evt: { step: 'DECRYPT', algo: data.algo, ciphertext: (data.ciphertext || '').substring(0, 80), plaintext: (data.plaintext || '').substring(0, 200), frames: data.frames || [] } });
        const entry = {
            id: Date.now().toString(36) + Math.random().toString(36).substr(2,4),
            algo: data.algo,
            ciphertext: data.ciphertext,
            key: data.key,
            cfg: data.cfg,
            plaintext: data.plaintext,
            stack: data.stack || [],
            time: new Date(data.time).toLocaleTimeString()
        };
        decryptStore.unshift(entry);
        if (decryptStore.length > MAX_DECRYPT) decryptStore.pop();
        if (isPanelOpen && panelRoot) renderDecryptList();
        // 同时入密钥库
        if (data.key && data.key.length > 3 && !data.key.startsWith('[')) {
            addToKeyVault({ type: data.algo, value: data.key, source: window.location.hostname, category: 'CRYPTO' });
        }
        if (data.plaintext && data.plaintext.length > 3) {
            addToKeyVault({ type: `[明文]${data.algo}`, value: data.plaintext, source: window.location.hostname, category: 'CRYPTO' });
        }
    }

    // ── 参数加密检测结果 ──
    if (data.type === 'PARAM_CRYPTO_FOUND') {
        // 链路追踪：参数加密检测事件 → 转发给 background
        chrome.runtime.sendMessage({ action: 'CHAIN_PUSH_EVENT', evt: { step: 'PARAM_CRYPTO', key: data.key, value: (data.value || '').substring(0, 80), detected: data.detected, decoded: (data.decoded || []).map(function(d) { return (d.result || '').substring(0, 50); }), frames: data.frames || [] } });
        // 去重（同 url+key+value）
        const dupKey = `${data.url}::${data.key}::${data.value}`;
        if (window[`_pcd_dedup_${dupKey}`]) return;
        window[`_pcd_dedup_${dupKey}`] = true;
        setTimeout(() => { delete window[`_pcd_dedup_${dupKey}`]; }, 10000);

        const entry = {
            id: Date.now().toString(36) + Math.random().toString(36).substr(2,4),
            key: data.key,
            value: data.value,
            detected: data.detected || [],
            decoded: data.decoded || [],
            url: data.url,
            method: data.method,
            time: new Date(data.time).toLocaleTimeString()
        };
        paramCryptoStore.unshift(entry);
        if (paramCryptoStore.length > MAX_PARAM_CRYPTO) paramCryptoStore.pop();
        if (isPanelOpen && panelRoot) renderParamCryptoList();
    }

    // ── Cookie 变化事件（来自 page-script.js）──
    if (data.type === 'COOKIE_CHANGED') {
        const evt = {
            name: data.name,
            value: data.value,
            oldValue: data.oldValue || '',
            op: data.op || 'SET',
            time: new Date().toLocaleTimeString(),
            source: data.source || ''
        };
        cookieTimeline.unshift(evt);
        if (cookieTimeline.length > MAX_COOKIE_EVENTS) cookieTimeline.pop();
        if (isPanelOpen && panelRoot) renderCookieTimeline();
    }

    // 签名字段嗅探报告
    if (data.type === 'SIGN_FIELD_FOUND' && isPanelOpen && panelRoot) {
        // 链路追踪：签名字段事件 → 转发给 background
        chrome.runtime.sendMessage({ action: 'CHAIN_PUSH_EVENT', evt: { step: 'SIGN_FIELD', field: data.field, value: data.value, context: data.context, frames: data.frames || [] } });
        const auditPane = panelRoot.getElementById('tracer-results');
        if (auditPane) {
            // 防止同一字段重复上报刷屏（同 field+value 5s 内去重）
            const dedupKey = `sign_${data.field}_${data.value}`;
            if (window[dedupKey]) return;
            window[dedupKey] = true;
            setTimeout(() => { delete window[dedupKey]; }, 5000);

            const div = document.createElement('div');
            div.style.cssText = 'border:1px solid #a29bfe; background:rgba(162,155,254,0.1); padding:10px; margin-bottom:8px; border-radius:4px; font-size:11px;';
            div.innerHTML = `✍️ <b>签名字段嗅探</b> <span style="color:#a29bfe; font-family:monospace;">${data.field}</span>
                <button class="btn-small copy-sign-val" style="float:right; background:#6c5ce7; padding:2px 7px; font-size:10px;">复制值</button>
                <br/><b>值:</b> <span style="color:#d63031; font-family:monospace; word-break:break-all;">${data.value}</span>
                <br/><small style="color:#999; font-family:monospace; word-break:break-all;">上下文: ${data.context}</small>`;
            div.querySelector('.copy-sign-val').onclick = (e) => {
                e.stopPropagation();
                navigator.clipboard.writeText(data.value).then(() => alert('✅ 已复制签名值'));
            };
            auditPane.prepend(div);
        }
    }
});

// ==========================================
// 配置持久化
// ==========================================

// AI 专用消息发送：打开 port 防止 Service Worker 在等待 API 响应时休眠
function sendAIMessage(msg, callback) {
    let port;
    try { port = chrome.runtime.connect({ name: 'phantom-keepalive' }); } catch(e) {}
    chrome.runtime.sendMessage(msg, (res) => {
        try { if (port) port.disconnect(); } catch(e) {}
        callback(res);
    });
}

chrome.storage.local.get(['mockRules', 'dynamicScript', 'openAIKey', 'aiModel', 'codeModel', 'apiHost', 'localFileRules', 'cssInjections', 'starredIds', 'postCacheStore'], (res) => {
    if (res.mockRules) mockRules = res.mockRules;
    if (res.dynamicScript) dynamicScript = res.dynamicScript;
    if (res.openAIKey) openAIKey = res.openAIKey;
    if (res.aiModel) aiModel = res.aiModel;
    if (res.codeModel) codeModel = res.codeModel;
    if (res.apiHost) apiHost = res.apiHost;
    if (res.localFileRules) localFileRules = res.localFileRules;
    if (res.cssInjections) cssInjections = res.cssInjections;
    if (res.starredIds) starredSet = new Set(res.starredIds);
    if (res.postCacheStore) postCacheStore = res.postCacheStore;
    setTimeout(syncRulesToPage, 500);
});

function syncRulesToPage() {
    window.postMessage({ type: 'UPDATE_MOCK_RULES', rules: mockRules }, '*');
    window.postMessage({ type: 'UPDATE_DYNAMIC_SCRIPT', script: dynamicScript }, '*');
    window.postMessage({ type: 'UPDATE_LOCAL_FILE_RULES', rules: localFileRules }, '*');
}

// ==========================================
// 界面渲染与控制
// ==========================================
function toggleDashboard() {
    if (isPanelOpen) {
        if (panelHost) panelHost.style.display = 'none';
        isPanelOpen = false;
    } else {
        if (!panelHost) createDashboardUI();
        panelHost.style.display = 'block';
        isPanelOpen = true;
        
        // 每次打开面板时拉取历史日志
        chrome.runtime.sendMessage({ action: 'GET_LOGS' }, (logs) => {
            if (logs && Array.isArray(logs)) {
                const list = panelRoot.getElementById('log-list');
                if (list) {
                    list.innerHTML = '';
                    [...logs].reverse().forEach(processLog);
                }
            }
        });

        // 全流量面板初始化
        renderTrafficView();
        
        renderMockRules();
        renderLocalFileRules();
        renderKeyVault();
        const editor = panelRoot.getElementById('script-editor');
        if (editor && dynamicScript) {
            editor.value = dynamicScript;
        }
    }
}

function createDashboardUI() {
    if (!document.body) { 
        setTimeout(createDashboardUI, 100); 
        return; 
    }

    panelHost = document.createElement('div');
    panelHost.id = 'chacha-dashboard-host';
    panelHost.style.cssText = `position: fixed; top: 20px; right: 20px; width: 480px; height: 680px; z-index: 2147483647; background: #fff; box-shadow: 0 0 20px rgba(0,0,0,0.2); border-radius: 8px; display: flex; flex-direction: column; resize: both; overflow: hidden; font-family: sans-serif;`;
    
    panelRoot = panelHost.attachShadow({mode: 'open'});
    const link = document.createElement('link'); 
    link.rel = 'stylesheet'; 
    link.href = chrome.runtime.getURL('dashboard.css'); 
    panelRoot.appendChild(link);

    // ── Prism.js 代码语法高亮 ──
    const prismCss = document.createElement('link');
    prismCss.rel = 'stylesheet';
    prismCss.href = 'https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/themes/prism-tomorrow.min.css';
    panelRoot.appendChild(prismCss);
    // 将 Prism 核心 + autoloader 挂到主页面（Shadow DOM 共享同一 window）
    if (!window.__phantom_prism_loaded__) {
        window.__phantom_prism_loaded__ = true;
        const ps = document.createElement('script');
        ps.src = 'https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/prism-core.min.js';
        ps.onload = () => {
            const pa = document.createElement('script');
            pa.src = 'https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/plugins/autoloader/prism-autoloader.min.js';
            pa.onload = () => {
                if (window.Prism && window.Prism.plugins && window.Prism.plugins.autoloader) {
                    window.Prism.plugins.autoloader.languages_path = 'https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/';
                }
            };
            document.head.appendChild(pa);
        };
        document.head.appendChild(ps);
    }

    const container = document.createElement('div');
    container.className = 'dashboard-container';
    
    container.innerHTML = `
        <div class="header" id="drag-handle" style="cursor: move; touch-action: none;">
            <div style="display:flex; align-items:center;">
                <span>🍵 Neural Phantom 4.1</span>
                <div style="display:flex; align-items:center; margin-left:15px; background:#444; border-radius:12px; padding:2px 8px; border:1px solid #666;">
                    <input id="bp-filter" placeholder="断点关键字" style="width:80px; background:transparent; border:none; color:#fff; font-size:11px; margin-right:5px; outline:none;">
                    <span id="bp-toggle" style="font-size:11px; cursor:pointer; font-weight:bold; color:#aaa;">OFF</span>
                </div>
                <span id="prehook-badge" title="预挂钩引擎(点击查看状态)" style="margin-left:8px; background:rgba(16,185,129,0.25); color:#fff; font-size:10px; padding:2px 8px; border-radius:10px; cursor:pointer; border:1px solid rgba(16,185,129,0.5);">🛡️ 0</span>
            </div>
            <span id="close-panel" class="close-btn">✕</span>
            <span id="open-console-window" class="close-btn" style="font-size:13px !important; margin-right:4px; cursor:pointer;" title="打开控制台独立窗口">🎯</span>
            <span id="open-chain-window" class="close-btn" style="font-size:13px !important; margin-right:4px; cursor:pointer;" title="打开链路追踪窗口">🔗</span>
        </div>
        <div id="paused-banner" class="paused-banner">⏸️ 狙击命中：请求已暂停</div>
        
        <div class="tabs" style="flex-wrap:wrap;">
            <div class="tab active" data-target="log-view">抓包</div>
            <div class="tab" data-target="ws-view">🔌 WS</div>
            <div class="tab" data-target="ws-intercept-view">🔌 WS拦截</div>
            <div class="tab" data-target="tracer-view">🔎 审计</div>
            <div class="tab" data-target="perf-view">⚡ 性能</div>
            <div class="tab" data-target="dashboard-view">📊 图表</div>
            <div class="tab" data-target="har-view">🎬 HAR</div>
            <div class="tab" data-target="request-view">📡 构造</div>
            <div class="tab" data-target="alert-view">🔔 告警</div>
            <div class="tab" data-target="schema-view">🧩 Schema</div>
            <div class="tab" data-target="storage-view">💾 Storage</div>
            <div class="tab" data-target="script-view">脚本</div>
            <div class="tab" data-target="hacker-view">伪造</div>
            <div class="tab" data-target="encode-view">编解码</div>
            <div class="tab" data-target="jwt-view">JWT</div>
            <div class="tab" data-target="secheader-view">安全头</div>
            <div class="tab" data-target="endpoint-view">端点</div>
            <div class="tab" data-target="vuln-view">漏洞</div>
            <div class="tab" data-target="param-view">参数</div>
            <div class="tab" data-target="settings-view">设置</div>
            <div class="tab" data-target="vault-view">🔑 密钥库</div>
            <div class="tab" data-target="tracer2-view">🔬 追踪</div>
            <div class="tab" data-target="postcache-view">📦 POST库</div>
            <div class="tab" data-target="traffic-view">📡 全流量</div>
            <div class="tab" data-target="functrace-view">🔭 函数追踪</div>
            <div class="tab" data-target="decrypt-view">🔓 解密猎手</div>
            <div class="tab" data-target="paramcrypto-view">🧪 参数加密</div>
            <div class="tab" data-target="media-view">📺 媒体</div>
            <div class="tab" data-target="cookie-timeline-view">🍪 Cookie线</div>
            <div class="tab" data-target="videochain-view">🎬 视频链路</div>
        </div>
        
        <div id="log-view" class="content active">
            <div class="filter-bar" id="tool-bar" style="border-bottom:none; padding-bottom:0;">
                <button id="picker-btn" class="filter-chip" style="background:#6c5ce7; color:white; font-weight:bold;">🖱️ 吸管</button>
                <button id="cookie-btn" class="filter-chip" style="background:#fab1a0; color:#2d3436; font-weight:bold;">🍪 Cookie</button>
                <button id="export-btn" class="filter-chip" style="background:#00b894; color:white; font-weight:bold;">💾 导出</button>
                <button id="star-filter-btn" class="filter-chip" style="background:#f9ca24; color:#2d3436; font-weight:bold;">⭐ 收藏</button>
                <button id="clear-log-btn" class="filter-chip" style="background:#636e72; color:white; font-weight:bold;">🗑️ 清空</button>
            </div>
            <div class="filter-bar" id="type-filters">
                <span class="filter-chip active" data-type="ALL">全部</span>
                <span class="filter-chip" data-type="MEDIA">视频</span>
                <span class="filter-chip" data-type="SCRIPT">脚本</span>
                <span class="filter-chip" data-type="XHR">数据</span>
            </div>
            <div style="padding: 0 10px 8px 10px; border-bottom: 1px solid #eee;">
                <input id="search-bar" type="text" placeholder="🔍 搜索 URL..." style="width:100%; padding:8px; border:1px solid #ddd; background:#f9f9f9; border-radius:4px; outline:none;">
            </div>
            <div id="log-list" style="flex:1; overflow-y:auto; padding-bottom:10px;"></div>
        </div>
        
        <!-- ══ 密钥库 Key Vault ══ -->
        <div id="vault-view" class="content" style="flex-direction:column;">
            <div style="padding:10px 12px; border-bottom:1px solid #e4e7f0; background:#fff; display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
                <span style="font-size:13px; font-weight:700;">🔑 密钥库</span>
                <span id="vault-count" style="font-size:11px; color:#6b7280; background:#f1f5f9; padding:2px 8px; border-radius:10px;">0 条</span>
                <div style="margin-left:auto; display:flex; gap:6px; flex-wrap:wrap;">
                    <select id="vault-filter-cat" style="font-size:11px; padding:4px 8px; border:1px solid #e4e7f0; border-radius:6px; outline:none; cursor:pointer;">
                        <option value="ALL">全部类型</option>
                        <option value="RESPONSE">响应体</option>
                        <option value="CRYPTO">加密拦截</option>
                        <option value="FIELD">敏感字段</option>
                    </select>
                    <button id="vault-export-btn" class="btn-small" style="background:#10b981; font-size:10px; padding:4px 10px;">💾 导出</button>
                    <button id="vault-clear-btn" class="btn-small" style="background:#ef4444; font-size:10px; padding:4px 10px;">🗑 清空</button>
                </div>
            </div>
            <div id="vault-list" style="flex:1; overflow-y:auto; padding:8px 10px;"></div>
        </div>

        <!-- ══ 参数来源追踪 ══ -->
        <div id="tracer2-view" class="content" style="flex-direction:column;">
            <div style="padding:10px 12px; border-bottom:1px solid #e4e7f0; background:rgba(255,255,255,0.8); display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
                <span style="font-size:13px; font-weight:700;">🔬 参数来源追踪</span>
                <span id="tracer2-count" style="font-size:11px; color:#6b7280; background:#f1f5f9; padding:2px 8px; border-radius:10px;">0 条</span>
                <div style="margin-left:auto; display:flex; gap:6px;">
                    <button id="tracer2-clear-btn" class="btn-small" style="background:#ef4444; font-size:10px; padding:4px 10px;">🗑 清空</button>
                </div>
            </div>
            <!-- 手动查询 -->
            <div style="padding:10px 12px; border-bottom:1px solid #e4e7f0; background:rgba(255,255,255,0.65);">
                <div style="font-size:11px; color:#6b7280; margin-bottom:6px;">输入参数名或参数值，手动追踪其来源</div>
                <div style="display:flex; gap:6px;">
                    <input id="tracer2-key" placeholder="参数名（如 sign）" style="flex:1; padding:7px 10px; border:1px solid #dde0ee; border-radius:6px; font-size:11px; outline:none; background:#fff;">
                    <input id="tracer2-val" placeholder="参数值（如 abc123）" style="flex:2; padding:7px 10px; border:1px solid #dde0ee; border-radius:6px; font-size:11px; outline:none; background:#fff;">
                    <button id="tracer2-search-btn" class="btn-small" style="background:#5b6ef5; padding:5px 14px; font-size:11px;">追踪</button>
                </div>
                <div id="tracer2-manual-result" style="margin-top:8px;"></div>
            </div>
            <!-- 实时追踪列表 -->
            <div id="tracer2-list" style="flex:1; overflow-y:auto; padding:8px 10px;"></div>
        </div>

        <div id="tracer-view" class="content">
            <div class="card">
                <h3 style="margin-top:0;">🔎 数据溯源与加密审计</h3>
                <p style="font-size:11px; color:#666; margin-bottom:10px;">在此查看自动拦截的 AES 密钥。你也可以输入字符串在所有历史流量中寻找它的源头。</p>
                <div style="display:flex; gap:5px;">
                    <input id="tracer-input" placeholder="输入要查找的目标值..." style="flex:1; padding:8px; border:1px solid #ddd; border-radius:4px; outline:none;">
                    <button id="tracer-btn" class="btn" style="width:auto; margin:0; background:#e17055; color:white;">溯源检索</button>
                </div>
            </div>
            <div id="tracer-results" style="padding:0 15px 15px 15px; overflow-y:auto; max-height:450px;"></div>
        </div>

        <!-- ══ Storage 全审计 ══ -->
        <div id="storage-view" class="content" style="flex-direction:column;">
            <div style="padding:10px 12px; border-bottom:1px solid #eee; display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
                <span style="font-size:12px; font-weight:bold;">💾 Storage 监控</span>
                <button id="storage-dump-btn" class="btn" style="width:auto; margin:0; background:#0984e3; padding:5px 12px; font-size:11px;">📤 导出快照</button>
                <button id="storage-clear-log-btn" class="btn" style="width:auto; margin:0; background:#636e72; padding:5px 12px; font-size:11px;">🗑 清空日志</button>
                <label style="font-size:11px; color:#636e72; margin-left:auto; display:flex; align-items:center; gap:4px;">
                    <input type="checkbox" id="storage-watch-toggle" checked> 实时监控
                </label>
            </div>
            <!-- 当前值速览 -->
            <div style="border-bottom:1px solid #eee;">
                <div style="display:flex; background:#f8f9fa; border-bottom:1px solid #eee;">
                    <button class="storage-tab-btn active" data-stab="local" style="flex:1; padding:7px; border:none; border-bottom:2px solid #0984e3; background:#f8f9fa; cursor:pointer; font-size:11px; font-weight:bold;">localStorage</button>
                    <button class="storage-tab-btn" data-stab="session" style="flex:1; padding:7px; border:none; background:#f8f9fa; cursor:pointer; font-size:11px;">sessionStorage</button>
                    <button class="storage-tab-btn" data-stab="log" style="flex:1; padding:7px; border:none; background:#f8f9fa; cursor:pointer; font-size:11px;">读写日志</button>
                </div>
                <div id="storage-local-tab" class="storage-tab-content" style="max-height:180px; overflow-y:auto; padding:8px;">
                    <div class="storage-empty-hint" style="color:#999; font-size:11px; padding:8px;">点击「导出快照」加载数据</div>
                </div>
                <div id="storage-session-tab" class="storage-tab-content" style="display:none; max-height:180px; overflow-y:auto; padding:8px;">
                    <div class="storage-empty-hint" style="color:#999; font-size:11px; padding:8px;">点击「导出快照」加载数据</div>
                </div>
                <div id="storage-log-tab" class="storage-tab-content" style="display:none; max-height:180px; overflow-y:auto; font-family:monospace; font-size:10px;"></div>
            </div>
        </div>

        <!-- ══ WebSocket 拦截/改写 ══ -->
        <div id="ws-intercept-view" class="content" style="flex-direction:column;">
            <div style="padding:10px 12px; border-bottom:1px solid #eee;">
                <div style="font-size:12px; font-weight:bold; margin-bottom:8px;">🔌 WebSocket 实时拦截 & 改写</div>
                <p style="font-size:11px; color:#636e72; margin:0 0 8px;">为特定 WS URL 设置改写规则，发出帧的 JSON 字段将被 patch。</p>
                <div style="display:flex; gap:6px; margin-bottom:6px;">
                    <input id="ws-rule-url" placeholder="WS URL 关键字（如 /chat）" style="flex:2; padding:7px; border:1px solid #ddd; border-radius:4px; outline:none; font-size:11px;">
                    <select id="ws-rule-dir" style="flex:1; padding:7px; border:1px solid #ddd; border-radius:4px; outline:none; font-size:11px;">
                        <option value="SEND">发出帧</option>
                        <option value="RECV">接收帧</option>
                        <option value="BOTH">双向</option>
                    </select>
                </div>
                <textarea id="ws-rule-body" placeholder='{"field": "patched_value"}' style="width:100%; height:60px; font-family:monospace; font-size:11px; border:1px solid #ddd; border-radius:4px; padding:6px; outline:none; box-sizing:border-box; resize:vertical;"></textarea>
                <div style="display:flex; gap:8px; margin-top:6px;">
                    <button id="ws-rule-add-btn" class="btn" style="width:auto; margin:0; background:#6c5ce7; padding:5px 14px; font-size:11px;">➕ 添加规则</button>
                </div>
            </div>
            <div style="padding:8px 12px; border-bottom:1px solid #eee; flex:none;">
                <div style="font-size:11px; color:#636e72; margin-bottom:6px; font-weight:bold;">当前规则</div>
                <div id="ws-rule-list"></div>
            </div>
            <!-- 实时帧日志（带断点标记） -->
            <div style="padding:8px 12px; flex:1; overflow-y:auto;">
                <div style="display:flex; justify-content:space-between; margin-bottom:6px; align-items:center;">
                    <span style="font-size:11px; color:#636e72; font-weight:bold;">拦截帧日志</span>
                    <div style="display:flex; gap:6px; align-items:center;">
                        <label style="font-size:10px; color:#636e72; display:flex; align-items:center; gap:3px;">
                            <input type="checkbox" id="ws-breakpoint-toggle"> 断点模式
                        </label>
                        <input id="ws-bp-keyword" placeholder="断点关键字" style="padding:4px 6px; border:1px solid #ddd; border-radius:3px; font-size:10px; outline:none; width:90px;">
                        <button id="ws-intercept-clear" class="btn-small" style="background:#636e72; padding:3px 8px;">清空</button>
                    </div>
                </div>
                <div id="ws-intercept-log" style="font-family:monospace; font-size:10px; max-height:250px; overflow-y:auto;"></div>
            </div>
        </div>

        <!-- ══ 脚本编辑器（升级版）══ -->
        <div id="script-view" class="content" style="display:none; flex-direction:column; padding:0;">
            <div style="padding:8px 12px; background:#1e2127; border-bottom:1px solid #333; display:flex; gap:6px; align-items:center; flex-wrap:wrap;">
                <span style="font-size:11px; color:#a9b7c6; font-weight:bold;">Hook 脚本</span>
                <span style="font-size:10px; color:#636e72;">参数: <code style="color:#ffd32a;">url, method, response</code>（返回修改后的 response 字符串）</span>
                <div style="margin-left:auto; display:flex; gap:6px;">
                    <button id="script-template-btn" class="btn-small" style="background:#6c5ce7;">📋 模板</button>
                    <button id="script-ai-gen-btn" class="btn-small" style="background:#e17055;">🤖 AI 生成</button>
                    <button id="script-validate-btn" class="btn-small" style="background:#00b894;">✅ 校验</button>
                </div>
            </div>
            <!-- Line numbers + editor -->
            <div style="flex:1; display:flex; overflow:hidden; min-height:0;">
                <div id="script-line-numbers" style="background:#1e2127; color:#495057; font-family:monospace; font-size:12px; line-height:1.6; padding:8px 4px 8px 8px; text-align:right; min-width:32px; user-select:none; overflow:hidden; border-right:1px solid #333;"></div>
                <textarea id="script-editor" spellcheck="false" style="flex:1; background:#1e2127; color:#a9b7c6; font-family:'Consolas','Monaco',monospace; font-size:12px; line-height:1.6; padding:8px; border:none; outline:none; resize:none; tab-size:2;"></textarea>
            </div>
            <!-- Error bar -->
            <div id="script-error-bar" style="display:none; background:#d63031; color:#fff; font-size:11px; padding:6px 12px; font-family:monospace;"></div>
            <!-- Context inspector (断点上下文) -->
            <div id="script-context-bar" style="background:#2d3436; color:#dfe6e9; font-size:10px; padding:5px 12px; border-top:1px solid #333; font-family:monospace; min-height:20px;">
                <span id="script-context-hint" style="color:#636e72;">当前无断点上下文</span>
            </div>
            <div style="padding:8px 12px; background:#282c34; display:flex; justify-content:flex-end; gap:8px; border-top:1px solid #333;">
                <button id="clear-script-btn" class="btn-small" style="background:#636e72;">清空</button>
                <button id="apply-script-btn" class="btn" style="width:auto; margin:0; background:#0984e3;">🚀 应用脚本</button>
            </div>
        </div>

        <div id="hacker-view" class="content">
            <div class="card">
                <h3 style="margin-top:0;">🎭 身份伪造 (Global Headers)</h3>
                <textarea id="header-config" placeholder='{"Referer": "https://www.bilibili.com"}' style="height:60px;"></textarea>
                <div style="display:flex; gap:10px;">
                    <button id="apply-headers-btn" class="btn" style="background:#d63031;">😈 覆盖 Header</button>
                    <button id="reset-headers-btn" class="btn" style="background:#636e72;">🚫 重置</button>
                </div>
            </div>
            <div class="card">
                <h3>🔨 静态 Mock</h3>
                <input id="mock-url" placeholder="URL 关键字" style="width:100%; padding:8px; margin-bottom:5px; border:1px solid #ddd; border-radius:4px; outline:none;">
                <textarea id="mock-body" placeholder="返回 JSON" style="height:80px; margin-bottom:5px;"></textarea>
                <button id="add-mock-btn" class="btn" style="background:#2d3436; margin-bottom:10px; margin-top:0;">➕ 添加规则</button>
                <div id="mock-list" style="max-height:150px; overflow-y:auto;"></div>
            </div>
            <div class="card">
                <h3>📁 本地文件替换 (Map Local)</h3>
                <p style="font-size:11px; color:#666; margin:0 0 8px;">将线上 JS/CSS 替换为本地文件，无需重新部署。</p>
                <input id="local-url" placeholder="URL 关键字 (如 main.js)" style="width:100%; padding:8px; margin-bottom:5px; border:1px solid #ddd; border-radius:4px; outline:none;">
                <div style="display:flex; gap:8px; margin-bottom:5px;">
                    <input type="file" id="local-file-input" style="flex:1; font-size:11px;">
                </div>
                <button id="add-local-btn" class="btn" style="background:#6c5ce7; margin-top:0; margin-bottom:10px;">➕ 添加替换</button>
                <div id="local-file-list" style="max-height:120px; overflow-y:auto;"></div>
            </div>
            <div class="card">
                <h3>🎨 CSS 注入</h3>
                <p style="font-size:11px; color:#666; margin:0 0 8px;">向当前页面注入自定义样式，实时生效。</p>
                <textarea id="css-inject-input" placeholder="/* 在此输入 CSS */&#10;body { background: #1a1a2e !important; }" style="height:80px; font-family:monospace; font-size:11px; margin-bottom:5px;"></textarea>
                <div style="display:flex; gap:8px;">
                    <button id="apply-css-btn" class="btn" style="background:#00b894; margin-top:0;">💉 注入 CSS</button>
                    <button id="clear-css-btn" class="btn" style="background:#636e72; margin-top:0;">清除所有</button>
                </div>
            </div>
        </div>

        <div id="settings-view" class="content">
            <div class="card">
                <h3 style="margin-top:0;">🛡️ 预挂钩引擎 (Pre-Hook)</h3>
                <p style="font-size:11px; color:#666; margin:0 0 10px;">让扩展在页面任何请求发出前挂上 debugger,连「扩展加载前」的请求也能完整抓取。</p>
                <label style="display:block; margin:8px 0; font-size:12px; cursor:pointer;">
                    <input type="checkbox" id="prehook-enable"> 启用预挂钩(建议开启)
                </label>
                <label style="display:block; margin:8px 0; font-size:12px; cursor:pointer;">
                    <input type="checkbox" id="prehook-pause"> 暂停 iframe / worker 直到调试器就绪(激进模式,可抓子框架最早请求)
                </label>
                <div style="margin-top:10px; padding:8px; background:#f8fafc; border:1px solid #e4e7f0; border-radius:6px; font-size:11px;">
                    <div id="prehook-status" style="color:#10b981;">状态加载中...</div>
                    <div style="color:#9ca3af; font-size:10px; margin-top:4px;">⚠️ 首次开启时 Chrome 顶部会弹出「此扩展正在调试此浏览器」黄条,这是 Chrome 安全机制,无法绕过。</div>
                </div>
            </div>
            <div class="card">
                <h3 style="margin-top:0;">🗂️ 规则集导入 / 导出</h3>
                <p style="font-size:11px; color:#666; margin:0 0 10px;">将所有配置（Mock规则、告警、脚本、替换规则等）打包为 JSON，换设备或分享给团队一键还原。</p>
                <div style="display:flex; gap:8px; margin-bottom:10px;">
                    <button id="config-export-btn" class="btn" style="flex:1; margin:0; background:#00b894;">💾 导出全部配置</button>
                    <button id="config-import-btn" class="btn" style="flex:1; margin:0; background:#6c5ce7;">📥 导入配置</button>
                </div>
                <input type="file" id="config-import-file" accept=".json" style="display:none;">
                <div id="config-status" style="font-size:11px; color:#636e72;"></div>
            </div>
            <div class="card">
                <h3 style="margin-top:0;">🤖 AI 服务配置</h3>
                <label style="display:block; margin:10px 0 5px; color:#666;">Base URL:</label>
                <input id="ai-host-input" type="text" placeholder="https://api.openai.com" style="width:100%; padding:8px; border:1px solid #ddd; border-radius:4px; font-family:monospace; outline:none;">
                
                <label style="display:block; margin:10px 0 5px; color:#666;">API Key:</label>
                <div style="display:flex; gap:10px;">
                    <input id="ai-key-input" type="password" placeholder="sk-..." style="flex:1; padding:8px; border:1px solid #ddd; border-radius:4px; outline:none;">
                    <button id="check-balance-btn" class="btn-small" style="background:#f39c12; color:white; padding:8px 12px; font-weight:bold;">💰 查余额</button>
                </div>
                <div id="balance-display" style="font-size:12px; color:#27ae60; margin-top:5px; font-weight:bold;"></div>
                
                <label style="display:block; margin:15px 0 5px; color:#666;">通用模型 (解释/TS):</label>
                <select id="ai-model-select" style="width:100%; padding:8px; border:1px solid #ddd; border-radius:4px; outline:none;">
                    <option value="gpt-3.5-turbo">gpt-3.5-turbo</option>
                </select>
                
                <label style="display:block; margin:15px 0 5px; color:#666;"><strong>🧠 反汇编专用模型 (Code Audit):</strong></label>
                <input id="ai-code-model-input" type="text" placeholder="claude-haiku-4.5-20251001" style="width:100%; padding:8px; border:1px solid #6c5ce7; border-radius:4px; font-family:monospace; color:#2d3436; outline:none;">
                <p style="font-size:10px; color:#999; margin:2px 0 0;">* 推荐使用 Claude 或 gpt-4o 进行逆向代码分析</p>

                <p id="model-status" style="font-size:10px; color:#999; margin:10px 0 0;">状态: 未连接</p>
                <button id="save-key-btn" class="btn" style="background:#10a37f; margin-top:20px;">保存配置并连接</button>
            </div>
        </div>

        <!-- ══ WebSocket 面板 ══ -->
        <div id="ws-view" class="content">
            <div style="padding:10px; display:flex; gap:8px; align-items:center; border-bottom:1px solid #eee;">
                <span style="font-size:12px; color:#666;">实时 WebSocket 帧监控</span>
                <button id="ws-clear-btn" class="filter-chip" style="margin-left:auto; background:#636e72; color:white; font-size:11px; padding:4px 10px;">清空</button>
            </div>
            <div id="ws-frame-list" style="flex:1; overflow-y:auto; padding:8px;"></div>
        </div>

        <!-- ══ 性能分析面板 ══ -->
        <div id="perf-view" class="content">
            <div style="padding:10px; display:flex; gap:8px; border-bottom:1px solid #eee;">
                <button id="perf-refresh-btn" class="btn" style="width:auto; margin:0; background:#0984e3;">📊 刷新统计</button>
                <button id="diff-mode-btn" class="btn" style="width:auto; margin:0; background:#6c5ce7;">🔀 开启 Diff 对比模式</button>
            </div>
            <div id="perf-content" style="flex:1; overflow-y:auto; padding:12px;">
                <div style="color:#999; font-size:12px; text-align:center; padding:20px;">点击「刷新统计」查看当前会话性能分析</div>
            </div>
            <!-- Diff 对比结果区域 -->
            <div id="diff-panel" style="display:none; flex:1; overflow-y:auto; padding:12px;">
                <div style="font-size:12px; color:#666; margin-bottom:10px;">
                    📌 <b>Diff 模式：</b>在抓包列表中右键点击请求选择「标为 A」或「标为 B」，再点击「执行 Diff」
                </div>
                <div style="display:flex; gap:8px; margin-bottom:10px;">
                    <div id="diff-a-label" style="flex:1; padding:8px; background:#dfe6e9; border-radius:4px; font-size:11px; color:#636e72;">A: 未选择</div>
                    <div id="diff-b-label" style="flex:1; padding:8px; background:#dfe6e9; border-radius:4px; font-size:11px; color:#636e72;">B: 未选择</div>
                    <button id="run-diff-btn" class="btn" style="width:auto; margin:0; background:#e17055;">执行 Diff</button>
                </div>
                <div id="diff-result" style="font-family:monospace; font-size:11px; overflow-x:auto;"></div>
            </div>
        </div>

        <!-- ══ 实时流量 Dashboard ══ -->
        <div id="dashboard-view" class="content">
            <div style="padding:10px; border-bottom:1px solid #eee; display:flex; gap:8px; align-items:center;">
                <span style="font-size:12px; font-weight:bold; color:#2d3436;">📊 实时流量监控</span>
                <button id="dash-refresh-btn" class="btn" style="width:auto; margin:0; background:#0984e3; padding:5px 12px; font-size:11px;">刷新</button>
                <span id="dash-total" style="margin-left:auto; font-size:11px; color:#636e72;"></span>
            </div>
            <!-- 状态码分布 -->
            <div style="padding:12px; border-bottom:1px solid #eee;">
                <div style="font-size:11px; font-weight:bold; color:#636e72; margin-bottom:8px;">HTTP 状态码分布</div>
                <div id="status-bars" style="display:flex; gap:6px; align-items:flex-end; height:50px;"></div>
                <div id="status-legend" style="display:flex; gap:12px; margin-top:6px; font-size:10px;"></div>
            </div>
            <!-- 每秒请求折线 -->
            <div style="padding:12px; border-bottom:1px solid #eee;">
                <div style="font-size:11px; font-weight:bold; color:#636e72; margin-bottom:6px;">每秒请求数 (最近 60s)</div>
                <canvas id="rps-canvas" width="420" height="60" style="width:100%; height:60px;"></canvas>
            </div>
            <!-- Top 域名 -->
            <div style="padding:12px; flex:1; overflow-y:auto;">
                <div style="font-size:11px; font-weight:bold; color:#636e72; margin-bottom:8px;">Top 域名</div>
                <div id="domain-bars"></div>
            </div>
        </div>

        <!-- ══ HAR 录制 & 回放 ══ -->
        <div id="har-view" class="content">
            <div style="padding:12px; border-bottom:1px solid #eee;">
                <div style="display:flex; gap:8px; margin-bottom:10px;">
                    <button id="har-record-btn" class="btn" style="width:auto; margin:0; background:#d63031;">⏺ 开始录制</button>
                    <button id="har-stop-btn" class="btn" style="width:auto; margin:0; background:#636e72;" disabled>⏹ 停止</button>
                    <button id="har-export-btn" class="btn" style="width:auto; margin:0; background:#00b894;" disabled>💾 导出 HAR</button>
                </div>
                <div id="har-status" style="font-size:11px; color:#636e72; padding:6px 0;">状态：未录制</div>
            </div>
            <div style="padding:12px; border-bottom:1px solid #eee;">
                <div style="font-size:12px; font-weight:bold; margin-bottom:8px;">📂 导入 HAR 回放</div>
                <input type="file" id="har-import-file" accept=".har,.json" style="font-size:11px; margin-bottom:8px; display:block;">
                <div style="display:flex; gap:8px;">
                    <button id="har-import-btn" class="btn" style="width:auto; margin:0; background:#6c5ce7;">📥 导入解析</button>
                    <button id="har-replay-btn" class="btn" style="width:auto; margin:0; background:#e17055;" disabled>▶ 回放全部</button>
                </div>
            </div>
            <div style="padding:12px; flex:1; overflow-y:auto;">
                <div style="font-size:11px; color:#636e72; margin-bottom:6px;">已导入条目 (<span id="har-entry-count">0</span>)</div>
                <div id="har-entry-list" style="max-height:300px; overflow-y:auto;"></div>
            </div>
        </div>

        <!-- ══ 请求构造器 (内置 Postman) ══ -->
        <div id="request-view" class="content" style="flex-direction:column;">
            <div style="padding:12px; border-bottom:1px solid #eee;">
                <div style="display:flex; gap:8px; margin-bottom:8px;">
                    <select id="req-method" style="padding:7px; border:1px solid #ddd; border-radius:4px; font-weight:bold; outline:none;">
                        <option>GET</option><option>POST</option><option>PUT</option><option>PATCH</option><option>DELETE</option><option>OPTIONS</option>
                    </select>
                    <input id="req-url" placeholder="https://api.example.com/v1/..." style="flex:1; padding:8px; border:1px solid #ddd; border-radius:4px; outline:none; font-family:monospace; font-size:12px;">
                    <button id="req-send-btn" class="btn" style="width:auto; margin:0; background:#00b894; padding:8px 16px; font-weight:bold;">发送 ▶</button>
                </div>
                <div style="display:flex; gap:8px; margin-bottom:6px;">
                    <button id="req-from-log-btn" class="btn-small" style="background:#6c5ce7;">从抓包导入</button>
                    <button id="req-gen-code-btn" class="btn-small" style="background:#e17055;">🌐 生成多语言代码</button>
                    <button id="req-ai-fuzz-btn" class="btn-small" style="background:#d63031; font-weight:bold;">🤖 AI Fuzz</button>
                </div>
            </div>
            <div style="display:flex; gap:0; border-bottom:1px solid #eee;">
                <button class="req-tab-btn active" data-rtab="headers" style="flex:1; padding:7px; border:none; border-bottom:2px solid #0984e3; background:#f8f9fa; cursor:pointer; font-size:11px;">Headers</button>
                <button class="req-tab-btn" data-rtab="body" style="flex:1; padding:7px; border:none; background:#f8f9fa; cursor:pointer; font-size:11px;">Body</button>
                <button class="req-tab-btn" data-rtab="params" style="flex:1; padding:7px; border:none; background:#f8f9fa; cursor:pointer; font-size:11px;">Params</button>
            </div>
            <div id="req-headers-tab" class="req-tab-content" style="padding:8px; flex:1;">
                <textarea id="req-headers" placeholder='{"Content-Type": "application/json", "Authorization": "Bearer ..."}' style="width:100%; height:80px; font-family:monospace; font-size:11px; border:1px solid #ddd; border-radius:4px; padding:6px; outline:none; box-sizing:border-box; resize:vertical;"></textarea>
            </div>
            <div id="req-body-tab" class="req-tab-content" style="padding:8px; display:none; flex:1;">
                <textarea id="req-body" placeholder='{"key": "value"}' style="width:100%; height:100px; font-family:monospace; font-size:11px; border:1px solid #ddd; border-radius:4px; padding:6px; outline:none; box-sizing:border-box; resize:vertical;"></textarea>
            </div>
            <div id="req-params-tab" class="req-tab-content" style="padding:8px; display:none; flex:1;">
                <textarea id="req-params" placeholder="key1=value1&#10;key2=value2" style="width:100%; height:80px; font-family:monospace; font-size:11px; border:1px solid #ddd; border-radius:4px; padding:6px; outline:none; box-sizing:border-box; resize:vertical;"></textarea>
            </div>
            <div style="border-top:1px solid #eee; padding:8px; flex:1; overflow-y:auto; background:#1e1e1e; min-height:80px;">
                <div style="font-size:10px; color:#888; margin-bottom:4px;">响应</div>
                <pre id="req-response" style="color:#d4d4d4; font-size:11px; margin:0; white-space:pre-wrap; word-break:break-all;"></pre>
            </div>
        </div>

        <!-- ══ 条件告警 ══ -->
        <div id="alert-view" class="content">
            <div style="padding:12px; border-bottom:1px solid #eee;">
                <div style="font-size:12px; font-weight:bold; margin-bottom:8px;">➕ 新建告警规则</div>
                <input id="alert-name" placeholder="规则名称（如：支付接口超时）" style="width:100%; padding:7px; border:1px solid #ddd; border-radius:4px; margin-bottom:6px; outline:none; box-sizing:border-box;">
                <div style="display:flex; gap:6px; margin-bottom:6px;">
                    <select id="alert-type" style="flex:1; padding:7px; border:1px solid #ddd; border-radius:4px; outline:none;">
                        <option value="STATUS">状态码等于</option>
                        <option value="DURATION">耗时超过 (ms)</option>
                        <option value="URL_CONTAINS">URL 包含</option>
                        <option value="BODY_CONTAINS">响应体包含</option>
                    </select>
                    <input id="alert-value" placeholder="值（如 500 / 2000 / error）" style="flex:2; padding:7px; border:1px solid #ddd; border-radius:4px; outline:none;">
                </div>
                <button id="alert-add-btn" class="btn" style="width:auto; margin:0; background:#e17055;">➕ 添加</button>
            </div>
            <div style="padding:12px; flex:1; overflow-y:auto;">
                <div style="font-size:11px; font-weight:bold; color:#636e72; margin-bottom:8px;">当前规则</div>
                <div id="alert-rule-list"></div>
            </div>
            <div style="padding:12px; border-top:1px solid #eee; max-height:180px; overflow-y:auto;">
                <div style="font-size:11px; font-weight:bold; color:#636e72; margin-bottom:6px;">🔴 最近命中</div>
                <div id="alert-hit-list"></div>
            </div>
        </div>

        <!-- ══ Schema 变更检测 ══ -->
        <div id="schema-view" class="content">
            <div style="padding:12px; border-bottom:1px solid #eee; display:flex; gap:8px; align-items:center;">
                <span style="font-size:12px; font-weight:bold; color:#2d3436;">🧩 接口 Schema 快照</span>
                <button id="schema-refresh-btn" class="btn" style="width:auto; margin:0 0 0 auto; background:#0984e3; padding:5px 12px; font-size:11px;">刷新</button>
            </div>
            <div style="padding:10px; font-size:11px; color:#636e72; border-bottom:1px solid #eee;">
                自动记录每个接口首次响应的数据结构，后续请求若结构发生变化（字段增删/类型改变）则立即告警。
            </div>
            <div id="schema-changes" style="padding:12px; border-bottom:1px solid #eee; display:none;">
                <div style="font-size:11px; font-weight:bold; color:#d63031; margin-bottom:6px;">⚠️ 检测到结构变化</div>
                <div id="schema-change-list"></div>
            </div>
            <div id="schema-snapshot-list" style="flex:1; overflow-y:auto; padding:8px;"></div>
        </div>

        <!-- ══ 编解码工具箱 ══ -->
        <div id="encode-view" class="content" style="flex-direction:column;">
            <div style="padding:10px 12px; border-bottom:1px solid #eee;">
                <span style="font-size:12px; font-weight:bold;">编解码工具箱</span>
            </div>
            <div style="padding:10px 12px;">
                <textarea id="encode-input" placeholder="在此输入要编码/解码的文本..." style="width:100%; height:80px; font-family:monospace; font-size:11px; border:1px solid #ddd; border-radius:4px; padding:6px; outline:none; box-sizing:border-box; resize:vertical;"></textarea>
                <div style="display:flex; gap:4px; flex-wrap:wrap; margin-top:8px;">
                    <button class="enc-btn btn-small" data-enc="base64-enc" style="background:#6c5ce7;">Base64 编码</button>
                    <button class="enc-btn btn-small" data-enc="base64-dec" style="background:#6c5ce7;">Base64 解码</button>
                    <button class="enc-btn btn-small" data-enc="url-enc" style="background:#0984e3;">URL 编码</button>
                    <button class="enc-btn btn-small" data-enc="url-dec" style="background:#0984e3;">URL 解码</button>
                    <button class="enc-btn btn-small" data-enc="hex-enc" style="background:#00b894;">Hex 编码</button>
                    <button class="enc-btn btn-small" data-enc="hex-dec" style="background:#00b894;">Hex 解码</button>
                    <button class="enc-btn btn-small" data-enc="unicode-enc" style="background:#e17055;">Unicode 编码</button>
                    <button class="enc-btn btn-small" data-enc="unicode-dec" style="background:#e17055;">Unicode 解码</button>
                    <button class="enc-btn btn-small" data-enc="html-enc" style="background:#d63031;">HTML 编码</button>
                    <button class="enc-btn btn-small" data-enc="html-dec" style="background:#d63031;">HTML 解码</button>
                    <button class="enc-btn btn-small" data-enc="md5" style="background:#636e72;">MD5</button>
                    <button class="enc-btn btn-small" data-enc="sha256" style="background:#636e72;">SHA-256</button>
                </div>
                <div style="margin-top:10px;">
                    <label style="font-size:11px; color:#636e72;">结果:</label>
                    <textarea id="encode-output" readonly style="width:100%; height:80px; font-family:monospace; font-size:11px; border:1px solid #ddd; border-radius:4px; padding:6px; outline:none; box-sizing:border-box; resize:vertical; background:#f8f9fa;"></textarea>
                    <div style="display:flex; gap:6px; margin-top:6px;">
                        <button id="encode-copy-btn" class="btn-small" style="background:#6c5ce7;">复制结果</button>
                        <button id="encode-swap-btn" class="btn-small" style="background:#636e72;">结果 -> 输入</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- ══ JWT 解码器 ══ -->
        <div id="jwt-view" class="content" style="flex-direction:column;">
            <div style="padding:10px 12px; border-bottom:1px solid #eee;">
                <span style="font-size:12px; font-weight:bold;">JWT 解码器</span>
            </div>
            <div style="padding:10px 12px;">
                <textarea id="jwt-input" placeholder="粘贴 JWT token (eyJhbGci...)" style="width:100%; height:60px; font-family:monospace; font-size:11px; border:1px solid #ddd; border-radius:4px; padding:6px; outline:none; box-sizing:border-box; resize:vertical;"></textarea>
                <button id="jwt-decode-btn" class="btn" style="width:auto; margin:8px 0; background:#e17055;">解码 JWT</button>
            </div>
            <div id="jwt-result" style="flex:1; overflow-y:auto; padding:10px 12px; font-family:monospace; font-size:11px;">
                <div style="color:#999;">输入 JWT 后点击解码</div>
            </div>
        </div>

        <!-- ══ 安全头检测 ══ -->
        <div id="secheader-view" class="content" style="flex-direction:column;">
            <div style="padding:10px 12px; border-bottom:1px solid #eee; display:flex; align-items:center; gap:8px;">
                <span style="font-size:12px; font-weight:bold;">安全头检测</span>
                <button id="secheader-scan-btn" class="btn" style="width:auto; margin:0; background:#d63031; padding:5px 12px; font-size:11px;">扫描</button>
                <span id="secheader-count" style="font-size:11px; color:#636e72; margin-left:auto;"></span>
            </div>
            <div id="secheader-results" style="flex:1; overflow-y:auto; padding:8px;">
                <div style="color:#999; font-size:11px; padding:8px;">点击「扫描」分析已捕获流量中的安全响应头</div>
            </div>
        </div>

        <!-- ══ 端点提取 ══ -->
        <div id="endpoint-view" class="content" style="flex-direction:column;">
            <div style="padding:10px 12px; border-bottom:1px solid #eee; display:flex; align-items:center; gap:8px;">
                <span style="font-size:12px; font-weight:bold;">JS 端点提取</span>
                <button id="endpoint-scan-btn" class="btn" style="width:auto; margin:0; background:#0984e3; padding:5px 12px; font-size:11px;">提取</button>
                <button id="endpoint-export-btn" class="btn-small" style="background:#00b894;">导出</button>
                <span id="endpoint-count" style="font-size:11px; color:#636e72; margin-left:auto;"></span>
            </div>
            <div id="endpoint-results" style="flex:1; overflow-y:auto; padding:8px; font-family:monospace; font-size:11px;">
                <div style="color:#999; padding:8px;">点击「提取」从 JS/XHR 响应中提取 API 端点</div>
            </div>
        </div>

        <!-- ══ 漏洞扫描 ══ -->
        <div id="vuln-view" class="content" style="flex-direction:column;">
            <div style="padding:10px 12px; border-bottom:1px solid #eee; display:flex; align-items:center; gap:8px;">
                <span style="font-size:12px; font-weight:bold;">被动漏洞扫描</span>
                <button id="vuln-scan-btn" class="btn" style="width:auto; margin:0; background:#d63031; padding:5px 12px; font-size:11px;">扫描</button>
                <span id="vuln-count" style="font-size:11px; color:#636e72; margin-left:auto;"></span>
            </div>
            <div id="vuln-results" style="flex:1; overflow-y:auto; padding:8px;">
                <div style="color:#999; font-size:11px; padding:8px;">点击「扫描」检测响应中的信息泄露与安全隐患</div>
            </div>
        </div>

        <!-- ══ 参数挖掘 ══ -->
        <div id="param-view" class="content" style="flex-direction:column;">
            <div style="padding:10px 12px; border-bottom:1px solid #eee; display:flex; align-items:center; gap:8px;">
                <span style="font-size:12px; font-weight:bold;">参数挖掘</span>
                <button id="param-mine-btn" class="btn" style="width:auto; margin:0; background:#6c5ce7; padding:5px 12px; font-size:11px;">挖掘</button>
                <button id="param-export-btn" class="btn-small" style="background:#00b894;">导出</button>
                <span id="param-count" style="font-size:11px; color:#636e72; margin-left:auto;"></span>
            </div>
            <div id="param-results" style="flex:1; overflow-y:auto; padding:8px;">
                <div style="color:#999; font-size:11px; padding:8px;">点击「挖掘」从所有流量中收集参数</div>
            </div>
        </div>

        <!-- ══ POST 缓存库 ══ -->
        <div id="postcache-view" class="content" style="flex-direction:column;">
            <!-- 顶部标题栏 -->
            <div style="padding:10px 12px 8px; border-bottom:1px solid #e4e7f0; background:rgba(255,255,255,0.92); flex-shrink:0;">
                <div style="display:flex; align-items:center; gap:8px; margin-bottom:8px; flex-wrap:wrap;">
                    <span style="font-size:13px; font-weight:700;">📦 请求缓存库</span>
                    <span id="postcache-count" style="font-size:11px; color:#6b7280; background:#f1f5f9; padding:2px 8px; border-radius:10px;">0 条</span>
                    <span id="postcache-filtered-count" style="font-size:11px; color:#5b6ef5; background:#eff1fe; padding:2px 8px; border-radius:10px; display:none;">筛选: 0 条</span>
                    <div style="margin-left:auto; display:flex; gap:5px;">
                        <button id="postcache-export-btn" class="btn-small" style="background:#10b981; font-size:10px; padding:3px 9px;">💾 导出筛选</button>
                        <button id="postcache-clear-btn" class="btn-small" style="background:#ef4444; font-size:10px; padding:3px 9px;">🗑 清空</button>
                    </div>
                </div>
                <!-- 第一行：关键字搜索 + 搜索范围 -->
                <div style="display:flex; gap:6px; margin-bottom:6px; align-items:center;">
                    <input id="postcache-search" placeholder="🔍 关键字..." style="flex:1; padding:6px 10px; border:1px solid #dde0ee; border-radius:6px; font-size:11px; outline:none; background:#fff;">
                    <select id="postcache-search-scope" style="font-size:11px; padding:5px 7px; border:1px solid #dde0ee; border-radius:6px; outline:none; background:#fff; cursor:pointer; flex-shrink:0;">
                        <option value="url">URL</option>
                        <option value="req_body">请求体</option>
                        <option value="resp_body">响应体</option>
                        <option value="all">全文</option>
                    </select>
                    <button id="postcache-filter-reset" class="btn-small" style="background:#636e72; font-size:10px; padding:3px 9px; flex-shrink:0;">重置</button>
                </div>
                <!-- 第二行：HTTP Method 多选 chips -->
                <div style="display:flex; gap:5px; flex-wrap:wrap; margin-bottom:6px;" id="postcache-method-chips">
                    <span style="font-size:10px; color:#9ca3af; line-height:22px; flex-shrink:0;">方法:</span>
                    <button class="pc-chip active" data-method="ALL" style="background:#5b6ef5; color:#fff; border:1px solid #5b6ef5; border-radius:12px; padding:2px 10px; font-size:10px; cursor:pointer; font-weight:600;">全部</button>
                    <button class="pc-chip" data-method="GET"    style="background:#fff; color:#00b894; border:1px solid #00b894; border-radius:12px; padding:2px 10px; font-size:10px; cursor:pointer; font-weight:600;">GET</button>
                    <button class="pc-chip" data-method="POST"   style="background:#fff; color:#e17055; border:1px solid #e17055; border-radius:12px; padding:2px 10px; font-size:10px; cursor:pointer; font-weight:600;">POST</button>
                    <button class="pc-chip" data-method="PUT"    style="background:#fff; color:#a29bfe; border:1px solid #a29bfe; border-radius:12px; padding:2px 10px; font-size:10px; cursor:pointer; font-weight:600;">PUT</button>
                    <button class="pc-chip" data-method="PATCH"  style="background:#fff; color:#f59e0b; border:1px solid #f59e0b; border-radius:12px; padding:2px 10px; font-size:10px; cursor:pointer; font-weight:600;">PATCH</button>
                    <button class="pc-chip" data-method="DELETE" style="background:#fff; color:#d63031; border:1px solid #d63031; border-radius:12px; padding:2px 10px; font-size:10px; cursor:pointer; font-weight:600;">DELETE</button>
                </div>
                <!-- 第三行：状态码 + 缓存状态 + 耗时 -->
                <div style="display:flex; gap:5px; flex-wrap:wrap; align-items:center;">
                    <span style="font-size:10px; color:#9ca3af; flex-shrink:0;">状态:</span>
                    <button class="pc-status-chip active" data-status="ALL" style="background:#5b6ef5; color:#fff; border:1px solid #5b6ef5; border-radius:12px; padding:2px 9px; font-size:10px; cursor:pointer; font-weight:600;">全部</button>
                    <button class="pc-status-chip" data-status="2xx" style="background:#fff; color:#00b894; border:1px solid #00b894; border-radius:12px; padding:2px 9px; font-size:10px; cursor:pointer;">2xx</button>
                    <button class="pc-status-chip" data-status="3xx" style="background:#fff; color:#0984e3; border:1px solid #0984e3; border-radius:12px; padding:2px 9px; font-size:10px; cursor:pointer;">3xx</button>
                    <button class="pc-status-chip" data-status="4xx" style="background:#fff; color:#f59e0b; border:1px solid #f59e0b; border-radius:12px; padding:2px 9px; font-size:10px; cursor:pointer;">4xx</button>
                    <button class="pc-status-chip" data-status="5xx" style="background:#fff; color:#d63031; border:1px solid #d63031; border-radius:12px; padding:2px 9px; font-size:10px; cursor:pointer;">5xx</button>
                    <div style="width:1px; background:#e4e7f0; height:16px; flex-shrink:0;"></div>
                    <button class="pc-body-chip active" data-body="ALL" style="background:#5b6ef5; color:#fff; border:1px solid #5b6ef5; border-radius:12px; padding:2px 9px; font-size:10px; cursor:pointer; font-weight:600;">全部</button>
                    <button class="pc-body-chip" data-body="HAS" style="background:#fff; color:#10b981; border:1px solid #10b981; border-radius:12px; padding:2px 9px; font-size:10px; cursor:pointer;">✓ 已缓存</button>
                    <button class="pc-body-chip" data-body="NO"  style="background:#fff; color:#9ca3af; border:1px solid #9ca3af; border-radius:12px; padding:2px 9px; font-size:10px; cursor:pointer;">⏳ 待缓存</button>
                    <div style="width:1px; background:#e4e7f0; height:16px; flex-shrink:0;"></div>
                    <input id="postcache-min-ms" type="number" placeholder="耗时≥ms" style="width:70px; padding:3px 6px; border:1px solid #dde0ee; border-radius:6px; font-size:10px; outline:none; background:#fff;">
                </div>
            </div>
            <div id="postcache-list" style="flex:1; overflow-y:auto; padding:0;"></div>
        </div>

        <!-- ══ 全流量查看器（GET+POST 全持久化 + 关键字高亮定位）══ -->
        <div id="traffic-view" class="content" style="flex-direction:column;">
            <div class="traffic-toolbar">
                <input id="traffic-search" class="traffic-search" placeholder="🔍 关键字搜索（URL / 参数 / 请求体）..." type="text">
                <span class="filter-chip active" data-tmethod="ALL" style="font-size:10px; padding:3px 9px;">ALL</span>
                <span class="filter-chip" data-tmethod="GET" style="font-size:10px; padding:3px 9px;">GET</span>
                <span class="filter-chip" data-tmethod="POST" style="font-size:10px; padding:3px 9px;">POST</span>
                <span class="filter-chip" data-tmethod="PUT" style="font-size:10px; padding:3px 9px;">PUT</span>
                <span class="filter-chip" data-tmethod="DELETE" style="font-size:10px; padding:3px 9px;">DEL</span>
                <button id="traffic-export-btn" class="btn-small" style="background:#10b981; font-size:10px; padding:3px 9px;">💾</button>
                <button id="traffic-clear-btn" class="btn-small" style="background:#ef4444; font-size:10px; padding:3px 9px;">🗑</button>
            </div>
            <div id="traffic-stats" class="traffic-stats">
                <span>共 <b id="traffic-total">0</b> 条</span>
                <span>GET <b id="traffic-get-count">0</b></span>
                <span>POST <b id="traffic-post-count">0</b></span>
                <span>筛选 <b id="traffic-filtered-count">0</b></span>
            </div>
            <div id="traffic-list" style="flex:1; overflow-y:auto;"></div>
        </div>

        <!-- ══ 全流量详情模态框 ══ -->
        <div id="traffic-detail-modal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <span id="traffic-detail-title">请求详情</span>
                    <span class="close-btn" id="traffic-detail-close">✕</span>
                </div>
                <div class="modal-body traffic-detail" id="traffic-detail-body" style="background:#181c2e; color:#c9d1d9;"></div>
                <div class="modal-footer">
                    <button id="traffic-detail-copy" class="btn-small" style="background:#0984e3;">📋 复制全部</button>
                    <button id="traffic-detail-curl" class="btn-small" style="background:#6c5ce7;">🔧 生成 cURL</button>
                </div>
            </div>
        </div>

        <!-- ══ 📺 媒体嗅探器仪表盘 ══ -->
        <div id="media-view" class="content" style="flex-direction:column;">
            <div class="traffic-toolbar">
                <span style="font-size:13px; font-weight:700;">📺 媒体嗅探器</span>
                <span id="media-count" style="font-size:11px; color:#6b7280; background:#f1f5f9; padding:2px 8px; border-radius:10px;">0</span>
                <input id="media-search" class="traffic-search" placeholder="🔍 过滤媒体 URL..." type="text" style="flex:1;">
                <button id="media-refresh-btn" class="btn-small" style="background:#0984e3; font-size:10px; padding:3px 9px;">🔄 刷新</button>
                <button id="media-extract-btn" class="btn-small" style="background:#e17055; font-size:10px; padding:3px 9px;">🧲 全部复制</button>
            </div>
            <div id="media-list" style="flex:1; overflow-y:auto;"></div>
        </div>

        <!-- ══ 🍪 Cookie 时间线 ══ -->
        <div id="cookie-timeline-view" class="content" style="flex-direction:column;">
            <div class="traffic-toolbar">
                <span style="font-size:13px; font-weight:700;">🍪 Cookie 变化时间线</span>
                <span id="cookie-event-count" style="font-size:11px; color:#6b7280; background:#f1f5f9; padding:2px 8px; border-radius:10px;">0</span>
                <input id="cookie-filter" class="traffic-search" placeholder="🔍 过滤 Cookie 名..." type="text" style="flex:1;">
                <button id="cookie-clear-btn" class="btn-small" style="background:#ef4444; font-size:10px; padding:3px 9px;">🗑</button>
                <button id="cookie-export-btn" class="btn-small" style="background:#10b981; font-size:10px; padding:3px 9px;">💾</button>
            </div>
            <div id="cookie-timeline-list" style="flex:1; overflow-y:auto;"></div>
        </div>

        <!-- ══ 🎬 视频链路逆向面板 ══ -->
        <div id="videochain-view" class="content" style="flex-direction:column;">
            <!-- 🎯 URL 进入行(保证 debugger attach 先于第一个请求) -->
            <div style="padding:8px 12px; border-bottom:1px solid #e4e7f0; background:linear-gradient(135deg,rgba(91,110,245,0.08) 0%,rgba(139,92,246,0.05) 100%); display:flex; gap:6px; align-items:center; flex-shrink:0;">
                <span style="font-size:11px; font-weight:600; color:#5b6ef5; flex-shrink:0;">🎯 从头抓</span>
                <input id="vc-enter-url" placeholder="输入目标 URL(https://...)回车进入" style="flex:1; padding:6px 10px; border:1px solid #c7d0fb; border-radius:6px; font-size:11px; outline:none; background:#fff; font-family:monospace;">
                <button id="vc-enter-go-btn" class="btn-small" style="background:#5b6ef5; padding:5px 14px; font-size:11px; font-weight:600;">🚀 进入</button>
                <button id="vc-enter-current-btn" class="btn-small" style="background:#10b981; padding:5px 10px; font-size:10px;" title="导入当前 tab URL">当前</button>
            </div>
            <div id="vc-enter-hint" style="padding:3px 12px; font-size:10px; color:#9ca3af; background:rgba(255,255,255,0.7); border-bottom:1px solid #e4e7f0;">💡 通过此入口进入页面,扩展已先 attach debugger,保证第一个 HTML 请求起全部可抓</div>
            <div style="padding:8px 12px; border-bottom:1px solid #e4e7f0; background:rgba(255,255,255,0.92); display:flex; gap:8px; align-items:center; flex-wrap:wrap; flex-shrink:0;">
                <span style="font-size:13px; font-weight:700;">🎬 视频链路逆向</span>
                <div style="display:flex; background:#f1f5f9; border-radius:14px; padding:2px;">
                    <button class="vc-mode active" data-mode="short" style="background:#5b6ef5; color:#fff; border:none; border-radius:12px; padding:4px 12px; font-size:10px; cursor:pointer; font-weight:600;">短链路</button>
                    <button class="vc-mode" data-mode="session" style="background:transparent; color:#6b7280; border:none; border-radius:12px; padding:4px 12px; font-size:10px; cursor:pointer;">整页会话</button>
                </div>
                <span id="vc-session-info" style="font-size:10px; color:#9ca3af;"></span>
                <div style="margin-left:auto; display:flex; gap:4px;">
                    <button id="vc-refresh-btn" class="btn-small" style="background:#0984e3; font-size:10px; padding:3px 9px;">🔄</button>
                    <button id="vc-reset-session-btn" class="btn-small" style="background:#f59e0b; font-size:10px; padding:3px 9px;" title="重置会话起点">🆕</button>
                    <button id="vc-export-btn" class="btn-small" style="background:#10b981; font-size:10px; padding:3px 9px;">💾</button>
                    <button id="vc-clear-btn" class="btn-small" style="background:#ef4444; font-size:10px; padding:3px 9px;">🗑</button>
                </div>
            </div>
            <div style="flex:1; overflow-y:auto;">
                <!-- 视频 URL 结果 -->
                <div class="vc-section" style="border-bottom:1px solid #e4e7f0; padding:10px 12px;">
                    <div style="display:flex; align-items:center; gap:6px; margin-bottom:6px;">
                        <span style="font-size:12px; font-weight:700; color:#1a1d2e;">📺 发现的视频</span>
                        <span id="vc-media-count" style="font-size:10px; background:#eff1fe; color:#5b6ef5; padding:2px 8px; border-radius:10px;">0</span>
                    </div>
                    <div id="vc-media-list"><div style="color:#9ca3af; font-size:11px; padding:10px; text-align:center;">暂无视频,播放视频后自动捕获</div></div>
                </div>
                <!-- JS 文件清单 -->
                <div class="vc-section" style="border-bottom:1px solid #e4e7f0; padding:10px 12px;">
                    <div style="display:flex; align-items:center; gap:6px; margin-bottom:6px; flex-wrap:wrap;">
                        <span style="font-size:12px; font-weight:700; color:#1a1d2e;">📜 JS 文件清单</span>
                        <span id="vc-scripts-count" style="font-size:10px; background:#eff1fe; color:#5b6ef5; padding:2px 8px; border-radius:10px;">0</span>
                        <span style="font-size:10px; color:#9ca3af;">🔥 加密 / 📡 网络 / 🎯 视频引用</span>
                        <input id="vc-scripts-filter" placeholder="🔍 过滤文件名" style="margin-left:auto; flex:1; min-width:80px; padding:4px 8px; border:1px solid #e4e7f0; border-radius:6px; font-size:10px; outline:none;">
                        <label style="font-size:10px; color:#6b7280; display:flex; align-items:center; gap:3px;"><input type="checkbox" id="vc-scripts-only-active"> 仅关键文件</label>
                    </div>
                    <div id="vc-scripts-list" style="max-height:280px; overflow-y:auto;"></div>
                </div>
                <!-- 事件时间线 -->
                <div class="vc-section" style="padding:10px 12px;">
                    <div style="display:flex; align-items:center; gap:6px; margin-bottom:6px; flex-wrap:wrap;">
                        <span style="font-size:12px; font-weight:700; color:#1a1d2e;">📋 解析事件时间线</span>
                        <span id="vc-events-count" style="font-size:10px; background:#eff1fe; color:#5b6ef5; padding:2px 8px; border-radius:10px;">0</span>
                        <select id="vc-events-filter" style="margin-left:auto; font-size:10px; padding:3px 7px; border:1px solid #e4e7f0; border-radius:6px; outline:none; cursor:pointer;">
                            <option value="ALL">全部事件</option>
                            <option value="CRYPTO_CALL">🔐 加密调用</option>
                            <option value="DECRYPT">🔓 解密操作</option>
                            <option value="SIGN_FIELD">✍️ 签名字段</option>
                            <option value="PARAM_SOURCE">📊 参数溯源</option>
                            <option value="PARAM_CRYPTO">🧪 参数加密</option>
                            <option value="REQUEST_SENT">📡 请求发出</option>
                            <option value="RESPONSE_RECV">✅ 响应接收</option>
                            <option value="URL_EXTRACT">🎯 URL提取</option>
                            <option value="MEDIA_FOUND">📺 媒体捕获</option>
                        </select>
                    </div>
                    <div id="vc-events-list"></div>
                </div>
            </div>
        </div>

        <!-- ══ 源码查看器模态框 ══ -->
        <div id="source-viewer-modal" class="modal">
            <div class="modal-content">
                <div class="modal-header" style="cursor:move;">
                    <div style="flex:1; display:flex; align-items:center; gap:8px; overflow:hidden;">
                        <span style="font-size:14px;">📄</span>
                        <b id="sv-title" style="font-size:12px; font-family:monospace; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;"></b>
                        <span id="sv-loc" style="color:#5b6ef5; font-family:monospace; font-size:11px; flex-shrink:0;"></span>
                    </div>
                    <span class="close-btn" id="sv-close">✕</span>
                </div>
                <div style="padding:6px 12px; background:#f1f5f9; display:flex; gap:6px; border-bottom:1px solid #e4e7f0;">
                    <input id="sv-search" placeholder="🔍 行内搜索(回车跳转)" style="flex:1; padding:5px 10px; border:1px solid #dde0ee; border-radius:6px; font-size:11px; outline:none; background:#fff;">
                    <button id="sv-goto-target" class="btn-small" style="background:#5b6ef5; font-size:10px; padding:3px 10px;">🎯 目标行</button>
                    <button id="sv-copy-line" class="btn-small" style="background:#0984e3; font-size:10px; padding:3px 10px;">📋 该行</button>
                    <button id="sv-copy-all" class="btn-small" style="background:#6c5ce7; font-size:10px; padding:3px 10px;">📋 全文</button>
                    <button id="sv-open-devtools" class="btn-small" style="background:#636e72; font-size:10px; padding:3px 10px;">🔗 新标签打开</button>
                </div>
                <div class="modal-body" style="background:#1e1e2e; overflow:auto;">
                    <pre id="sv-code" style="margin:0; padding:14px 0; font-family:'SF Mono',Consolas,monospace; font-size:12px; line-height:1.6; color:#c9d1d9; white-space:pre; overflow-x:auto;"></pre>
                </div>
            </div>
        </div>

        <!-- ══ 函数调用追踪 ══ -->
        <div id="functrace-view" class="content" style="flex-direction:column;">
            <div style="padding:10px 12px 8px; border-bottom:1px solid #e4e7f0; background:rgba(255,255,255,0.92); flex-shrink:0;">
                <div style="display:flex; align-items:center; gap:8px; margin-bottom:8px; flex-wrap:wrap;">
                    <span style="font-size:13px; font-weight:700;">🔭 函数调用追踪</span>
                    <span id="functrace-count" style="font-size:11px; color:#6b7280; background:#f1f5f9; padding:2px 8px; border-radius:10px;">0 次</span>
                    <button id="functrace-clear-btn" class="btn-small" style="background:#ef4444; font-size:10px; padding:3px 9px; margin-left:auto;">🗑 清空</button>
                </div>
                <!-- 追踪目标输入 -->
                <div style="display:flex; gap:6px; margin-bottom:6px;">
                    <input id="functrace-input" placeholder="函数路径，如 CryptoJS.AES.encrypt 或关键字 encode" style="flex:1; padding:6px 10px; border:1px solid #dde0ee; border-radius:6px; font-size:11px; outline:none; background:#fff;">
                    <select id="functrace-mode" style="font-size:11px; padding:5px 7px; border:1px solid #dde0ee; border-radius:6px; outline:none; background:#fff; cursor:pointer;">
                        <option value="path">精确路径</option>
                        <option value="global">关键字模糊</option>
                    </select>
                    <button id="functrace-add-btn" class="btn-small" style="background:#5b6ef5; padding:3px 12px; font-size:11px;">➕ 挂钩</button>
                </div>
                <!-- 已挂钩列表 -->
                <div id="functrace-hooked-list" style="display:flex; gap:4px; flex-wrap:wrap; min-height:22px;"></div>
                <div style="font-size:10px; color:#9ca3af; margin-top:4px;">💡 挂钩后浏览页面，每次函数被调用时自动记录调用链、入参、返回值</div>
                <div id="functrace-hook-status" style="font-size:10px; margin-top:4px; min-height:16px;"></div>
            </div>
            <!-- 实时追踪日志 -->
            <div id="functrace-list" style="flex:1; overflow-y:auto; font-family:monospace; font-size:11px;"></div>
        </div>

        <!-- ══ 解密猎手 ══ -->
        <div id="decrypt-view" class="content" style="flex-direction:column;">
            <div style="padding:10px 12px 8px; border-bottom:1px solid #e4e7f0; background:rgba(255,255,255,0.92); flex-shrink:0; display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
                <span style="font-size:13px; font-weight:700;">🔓 解密猎手</span>
                <span id="decrypt-count" style="font-size:11px; color:#6b7280; background:#f1f5f9; padding:2px 8px; border-radius:10px;">0 条</span>
                <div style="font-size:10px; color:#9ca3af; flex:1;">自动拦截 CryptoJS/WebCrypto/atob 解密操作，还原明文</div>
                <button id="decrypt-clear-btn" class="btn-small" style="background:#ef4444; font-size:10px; padding:3px 9px;">🗑 清空</button>
                <button id="decrypt-export-btn" class="btn-small" style="background:#10b981; font-size:10px; padding:3px 9px;">💾 导出</button>
            </div>
            <div id="decrypt-list" style="flex:1; overflow-y:auto; padding:0;"></div>
        </div>

        <!-- ══ 参数加密检测 ══ -->
        <div id="paramcrypto-view" class="content" style="flex-direction:column;">
            <div style="padding:10px 12px 8px; border-bottom:1px solid #e4e7f0; background:rgba(255,255,255,0.92); flex-shrink:0;">
                <div style="display:flex; align-items:center; gap:8px; margin-bottom:6px; flex-wrap:wrap;">
                    <span style="font-size:13px; font-weight:700;">🧪 参数加密检测</span>
                    <span id="paramcrypto-count" style="font-size:11px; color:#6b7280; background:#f1f5f9; padding:2px 8px; border-radius:10px;">0 条</span>
                    <input id="paramcrypto-search" placeholder="🔍 过滤参数名/URL..." style="flex:1; min-width:80px; padding:5px 8px; border:1px solid #dde0ee; border-radius:6px; font-size:11px; outline:none; background:#fff;">
                    <button id="paramcrypto-clear-btn" class="btn-small" style="background:#ef4444; font-size:10px; padding:3px 9px;">🗑 清空</button>
                    <button id="paramcrypto-export-btn" class="btn-small" style="background:#10b981; font-size:10px; padding:3px 9px;">💾 导出</button>
                </div>
                <!-- 类型过滤 -->
                <div style="display:flex; gap:4px; flex-wrap:wrap;" id="paramcrypto-type-chips">
                    <span style="font-size:10px; color:#9ca3af; line-height:22px;">类型:</span>
                    <button class="pcc-chip active" data-type="ALL" style="background:#5b6ef5;color:#fff;border:1px solid #5b6ef5;border-radius:12px;padding:2px 9px;font-size:10px;cursor:pointer;font-weight:600;">全部</button>
                    <button class="pcc-chip" data-type="JWT"         style="background:#fff;color:#8b5cf6;border:1px solid #8b5cf6;border-radius:12px;padding:2px 9px;font-size:10px;cursor:pointer;">JWT</button>
                    <button class="pcc-chip" data-type="Base64"      style="background:#fff;color:#0984e3;border:1px solid #0984e3;border-radius:12px;padding:2px 9px;font-size:10px;cursor:pointer;">Base64</button>
                    <button class="pcc-chip" data-type="Hex"         style="background:#fff;color:#e17055;border:1px solid #e17055;border-radius:12px;padding:2px 9px;font-size:10px;cursor:pointer;">Hex/Hash</button>
                    <button class="pcc-chip" data-type="URLEncoded"  style="background:#fff;color:#00b894;border:1px solid #00b894;border-radius:12px;padding:2px 9px;font-size:10px;cursor:pointer;">URLEncoded</button>
                    <button class="pcc-chip" data-type="AES"         style="background:#fff;color:#d63031;border:1px solid #d63031;border-radius:12px;padding:2px 9px;font-size:10px;cursor:pointer;">AES?</button>
                </div>
                <div style="font-size:10px; color:#9ca3af; margin-top:5px;">💡 自动扫描每个 GET/POST 请求参数，识别 Base64/Hex/JWT/AES 等加密值，并尝试还原明文</div>
            </div>
            <div id="paramcrypto-list" style="flex:1; overflow-y:auto; padding:0;"></div>
        </div>

        <div id="modal-viewer" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 style="margin:0;">📜 源码审计终端</h3>
                    <div style="display:flex;align-items:center;gap:8px;">
                        <label style="font-size:10px;color:#636e72;display:flex;align-items:center;gap:4px;cursor:pointer;">
                            <input type="checkbox" id="highlight-toggle" checked style="cursor:pointer;"> 语法高亮
                        </label>
                        <span class="close-btn" id="close-modal">×</span>
                    </div>
                </div>
                <div class="modal-body" style="display:flex; flex-direction:column; height:100%;">
                    <div id="ai-analysis-panel" style="display:none; border-bottom:2px solid #6c5ce7; background:#1e1e1e; color:#d4d4d4; padding:15px; max-height:250px; overflow-y:auto; flex-shrink:0;">
                        <div style="display:flex; justify-content:space-between; margin-bottom:10px;">
                            <strong style="color:#6c5ce7;">🤖 茶室 AI 分析报告</strong>
                            <div style="display:flex; gap:6px;">
                                <button id="copy-ai-result" class="btn-small" style="background:#6c5ce7;">📋 复制结果</button>
                                <button id="close-ai-panel" class="btn-small" style="background:#444;">收起面板</button>
                            </div>
                        </div>
                        <div id="ai-result-content" style="white-space: pre-wrap; font-family: Consolas, monospace; font-size: 12px; line-height:1.4;"></div>
                    </div>
                    <div id="code-content" style="flex:1; margin:0; overflow:auto; background:#1e1e2e;"></div>
                </div>
                <div class="modal-footer" style="background:#f1f2f6; display:flex; align-items:center; justify-content:space-between; padding:10px;">
                    <div style="display:flex; gap:8px; flex-wrap:wrap;">
                        <button class="btn-small" id="btn-format-code" style="background:#2d3436;">✨ 格式化</button>
                        <div style="width:1px; background:#ccc; margin:0 5px;"></div>
                        <button class="btn-small" id="btn-ai-explain" style="background:#8e44ad;">🧐 解释业务</button>
                        <button class="btn-small" id="btn-ai-disassemble" style="background:#d63031; font-weight:bold; box-shadow: 0 2px 5px rgba(214, 48, 49, 0.4);">🧠 深度反汇编</button>
                        <button class="btn-small" id="btn-ai-ts" style="background:#2980b9;">📘 生成 TS</button>
                        <button class="btn-small" id="btn-ai-mock" style="background:#00b894;">🎲 生成 Mock</button>
                        <button class="btn-small" id="btn-ai-doc" style="background:#e17055;">📄 生成接口文档</button>
                    </div>
                    <button class="btn-small" id="copy-code" style="background:#636e72;">📄 复制源码</button>
                </div>
            </div>
        </div>

        <div id="modal-breakpoint" class="modal" style="background: rgba(45, 52, 54, 0.9);">
            <div class="modal-content" style="height:580px; border:2px solid #ff4757; background:#282c34;">
                <div class="modal-header" style="background:#ff4757; color:white; display:flex; align-items:center; justify-content:space-between; padding:10px 15px;">
                    <h3 style="margin:0;">🛑 断点命中</h3>
                    <div style="display:flex; gap:6px; align-items:center;">
                        <span id="bp-method-badge" style="background:rgba(255,255,255,0.2); padding:2px 8px; border-radius:10px; font-size:11px; font-weight:bold;"></span>
                        <span id="bp-status-dot" style="width:8px; height:8px; border-radius:50%; background:#f39c12; display:inline-block; animation: blink 1s infinite;"></span>
                    </div>
                </div>
                <!-- Tab bar inside breakpoint modal -->
                <div style="display:flex; background:#1e2127; border-bottom:1px solid #444;">
                    <button class="bp-tab active" data-bptab="url" style="flex:1; padding:8px; border:none; border-bottom:2px solid #ff4757; background:transparent; color:#fff; cursor:pointer; font-size:11px;">🔗 URL</button>
                    <button class="bp-tab" data-bptab="headers" style="flex:1; padding:8px; border:none; background:transparent; color:#aaa; cursor:pointer; font-size:11px;">📋 Headers</button>
                    <button class="bp-tab" data-bptab="body" style="flex:1; padding:8px; border:none; background:transparent; color:#aaa; cursor:pointer; font-size:11px;">📦 Body</button>
                    <button class="bp-tab" data-bptab="ai" style="flex:1; padding:8px; border:none; background:transparent; color:#aaa; cursor:pointer; font-size:11px;">🤖 AI 建议</button>
                </div>
                <div class="modal-body" style="padding:12px; display:flex; flex-direction:column; flex:1; overflow:hidden;">
                    <!-- URL Tab -->
                    <div id="bp-url-tab" class="bp-tab-content" style="display:flex; flex-direction:column; flex:1;">
                        <label style="color:#aaa; font-size:10px; margin-bottom:4px;">完整 URL（可直接编辑）:</label>
                        <input id="bp-url" style="width:100%; padding:8px; background:#333; color:#ffd32a; border:1px solid #555; border-radius:4px; outline:none; font-family:monospace; font-size:11px; box-sizing:border-box;">
                        <div style="margin-top:8px;">
                            <label style="color:#aaa; font-size:10px;">URL 参数（逐行 key=value，修改后自动拼回）:</label>
                            <div id="bp-params-list" style="margin-top:4px; max-height:160px; overflow-y:auto; background:#1e2127; border:1px solid #444; border-radius:4px; padding:6px;"></div>
                        </div>
                    </div>
                    <!-- Headers Tab -->
                    <div id="bp-headers-tab" class="bp-tab-content" style="display:none; flex-direction:column; flex:1;">
                        <label style="color:#aaa; font-size:10px; margin-bottom:4px;">Request Headers（JSON 格式，可增删改）:</label>
                        <textarea id="bp-headers" style="flex:1; min-height:200px; background:#1e2127; color:#9cdcfe; font-family:monospace; font-size:11px; padding:10px; border:1px solid #555; border-radius:4px; resize:none; outline:none; box-sizing:border-box;"></textarea>
                        <div style="margin-top:6px; font-size:10px; color:#636e72;">💡 修改此处可伪造 Authorization / Cookie / Origin / Referer 等任意 Header</div>
                    </div>
                    <!-- Body Tab -->
                    <div id="bp-body-tab" class="bp-tab-content" style="display:none; flex-direction:column; flex:1;">
                        <label style="color:#aaa; font-size:10px; margin-bottom:4px;">Request Body:</label>
                        <textarea id="bp-body" style="flex:1; min-height:200px; background:#1e2127; color:#a9b7c6; font-family:monospace; font-size:11px; padding:10px; border:1px solid #555; border-radius:4px; resize:none; outline:none; box-sizing:border-box;"></textarea>
                        <div style="margin-top:6px; display:flex; gap:6px;">
                            <button id="bp-format-btn" style="background:#6c5ce7; color:#fff; border:none; padding:4px 10px; border-radius:3px; cursor:pointer; font-size:10px;">格式化 JSON</button>
                            <button id="bp-minify-btn" style="background:#636e72; color:#fff; border:none; padding:4px 10px; border-radius:3px; cursor:pointer; font-size:10px;">压缩</button>
                        </div>
                    </div>
                    <!-- AI Tab -->
                    <div id="bp-ai-tab" class="bp-tab-content" style="display:none; flex-direction:column; flex:1; gap:8px;">
                        <div style="display:flex; gap:6px; flex-wrap:wrap;">
                            <button class="bp-ai-scenario" data-scene="bypass" style="background:#e17055; color:#fff; border:none; padding:5px 10px; border-radius:4px; cursor:pointer; font-size:10px; font-weight:bold;">🚪 越权绕过</button>
                            <button class="bp-ai-scenario" data-scene="sqli" style="background:#d63031; color:#fff; border:none; padding:5px 10px; border-radius:4px; cursor:pointer; font-size:10px; font-weight:bold;">💉 SQL注入探测</button>
                            <button class="bp-ai-scenario" data-scene="idor" style="background:#a29bfe; color:#fff; border:none; padding:5px 10px; border-radius:4px; cursor:pointer; font-size:10px; font-weight:bold;">🔄 IDOR测试</button>
                            <button class="bp-ai-scenario" data-scene="privilege" style="background:#fd79a8; color:#fff; border:none; padding:5px 10px; border-radius:4px; cursor:pointer; font-size:10px; font-weight:bold;">👑 越权构造</button>
                        </div>
                        <div id="bp-ai-result" style="flex:1; overflow-y:auto; background:#1e2127; border:1px solid #444; border-radius:4px; padding:10px; font-size:11px; color:#a9b7c6; font-family:monospace; white-space:pre-wrap; min-height:150px;">点击上方按钮，AI 将分析当前请求并给出攻击/测试建议和修改方案</div>
                        <div style="display:flex; gap:6px;">
                            <button id="bp-ai-apply-url" style="flex:1; background:#00b894; color:#fff; border:none; padding:6px; border-radius:4px; cursor:pointer; font-size:10px;" disabled>✅ 应用到 URL</button>
                            <button id="bp-ai-apply-body" style="flex:1; background:#0984e3; color:#fff; border:none; padding:6px; border-radius:4px; cursor:pointer; font-size:10px;" disabled>✅ 应用到 Body</button>
                        </div>
                    </div>
                </div>
                <div class="modal-footer" style="background:#2d3436; border-top:1px solid #444; padding:10px; display:flex; gap:8px; justify-content:flex-end;">
                    <button id="bp-abort-btn" class="btn" style="width:auto; background:#636e72; margin:0; font-size:12px;">🚫 丢弃请求</button>
                    <button id="bp-resume-btn" class="btn" style="width:auto; background:#2ecc71; margin:0; font-size:12px; font-weight:bold;">▶️ 修改并放行</button>
                </div>
            </div>
        </div>
    `;
    
    panelRoot.appendChild(container);
    document.body.appendChild(panelHost);
    
    initEvents();
    bindTrafficEvents();
    bindVideoChainEvents();
    makeDraggable(panelHost, panelRoot.getElementById('drag-handle'));
    const modalViewer = panelRoot.getElementById('modal-viewer');
    makeDraggable(modalViewer.querySelector('.modal-content'), modalViewer.querySelector('.modal-header'));
    const bpModal = panelRoot.getElementById('modal-breakpoint');
    makeDraggable(bpModal.querySelector('.modal-content'), bpModal.querySelector('.modal-header'));
}

// ==========================================
// 交互事件绑定
// ==========================================
function initEvents() {
    const root = panelRoot;
    
    // 关闭面板
    root.getElementById('close-panel').onclick = (e) => {
        e.stopPropagation();
        toggleDashboard();
    };
    // 打开链路追踪独立窗口
    root.getElementById('open-chain-window').onclick = (e) => {
        e.stopPropagation();
        chrome.runtime.sendMessage({ action: 'CHAIN_OPEN_WINDOW' });
    };
    // 打开控制台独立窗口
    root.getElementById('open-console-window').onclick = (e) => {
        e.stopPropagation();
        chrome.runtime.sendMessage({ action: 'OPEN_CONSOLE_WINDOW' });
    };
    
    // Tab 切换逻辑 [修复补丁1：内联样式彻底清除机制]
    root.querySelectorAll('.tab').forEach(tab => {
        tab.onclick = (e) => {
            e.stopPropagation();
            root.querySelectorAll('.tab, .content').forEach(el => {
                el.classList.remove('active');
                el.style.display = ''; 
            });
            tab.classList.add('active');
            const targetId = tab.dataset.target;
            const target = root.getElementById(targetId);
            target.classList.add('active');
            
            // 需要 flex 布局的面板
            const flexViews = ['script-view','encode-view','jwt-view','secheader-view','endpoint-view','vuln-view','param-view','ws-intercept-view','storage-view','request-view','postcache-view','traffic-view','media-view','cookie-timeline-view','functrace-view','decrypt-view','paramcrypto-view','videochain-view'];
            if (flexViews.includes(targetId)) {
                target.style.display = 'flex';
            }

            // 🎬 视频链路 Tab:进入即触发首次渲染与轮询,离开则停止
            if (targetId === 'videochain-view') {
                renderVideoChain();
                startVideoChainPolling();
            } else {
                stopVideoChainPolling();
            }
        };
    });

    // 搜索与过滤
    root.getElementById('search-bar').oninput = (e) => { 
        currentSearchText = e.target.value.toLowerCase(); 
        applyFilter(); 
    };
    
    const chips = root.querySelectorAll('.filter-chip:not(#picker-btn):not(#cookie-btn):not(#export-btn)');
    chips.forEach(chip => {
        chip.onclick = (e) => {
            e.stopPropagation();
            chips.forEach(el => el.classList.remove('active')); 
            chip.classList.add('active');
            currentTypeFilter = chip.dataset.type; 
            applyFilter();
        };
    });

    // 工具按钮
    root.getElementById('picker-btn').onclick = (e) => { e.stopPropagation(); togglePickerMode(); };
    root.getElementById('cookie-btn').onclick = (e) => { e.stopPropagation(); getCookies(); };
    root.getElementById('export-btn').onclick = (e) => { e.stopPropagation(); exportData(); };

    // 断点控制
    const bpToggle = root.getElementById('bp-toggle');
    const bpFilterInput = root.getElementById('bp-filter');
    bpToggle.onclick = (e) => {
        e.stopPropagation();
        isBreakpointEnabled = !isBreakpointEnabled;
        breakpointFilter = bpFilterInput.value.trim(); 
        bpToggle.innerText = isBreakpointEnabled ? "ON" : "OFF";
        bpToggle.style.color = isBreakpointEnabled ? "#ff4757" : "#aaa";
        window.postMessage({ type: 'TOGGLE_BREAKPOINT', enabled: isBreakpointEnabled, filter: breakpointFilter }, '*');
    };
    bpFilterInput.oninput = (e) => {
        if (isBreakpointEnabled) {
            breakpointFilter = e.target.value.trim();
            window.postMessage({ type: 'TOGGLE_BREAKPOINT', enabled: true, filter: breakpointFilter }, '*');
        }
    };

    // ══════════════════════════════════════
    // 断点弹窗 — 完整交互逻辑
    // ══════════════════════════════════════
    let currentRequestId = null;
    let bpAiSuggestion = null; // { url, body } from AI
    const bpModal = root.getElementById('modal-breakpoint');

    // Tab 切换
    root.querySelectorAll('.bp-tab[data-bptab]').forEach(btn => {
        btn.onclick = (e) => {
            e.stopPropagation();
            root.querySelectorAll('.bp-tab[data-bptab]').forEach(b => {
                b.classList.remove('active');
                b.style.borderBottom = 'none';
                b.style.color = '#aaa';
            });
            root.querySelectorAll('.bp-tab-content').forEach(c => c.style.display = 'none');
            btn.classList.add('active');
            btn.style.borderBottom = '2px solid #ff4757';
            btn.style.color = '#fff';
            root.getElementById(`bp-${btn.dataset.bptab}-tab`).style.display = 'flex';
        };
    });

    // URL 参数实时解析
    root.getElementById('bp-url').addEventListener('input', (e) => {
        e.stopPropagation();
        renderBpParams(e.target.value);
    });

    function renderBpParams(url) {
        const container = root.getElementById('bp-params-list');
        container.innerHTML = '';
        try {
            const u = new URL(url);
            if ([...u.searchParams.entries()].length === 0) {
                container.innerHTML = '<span style="color:#555; font-size:10px;">（无 Query 参数）</span>';
                return;
            }
            [...u.searchParams.entries()].forEach(([k, v]) => {
                const row = document.createElement('div');
                row.style.cssText = 'display:flex; gap:6px; margin-bottom:4px; align-items:center;';
                row.innerHTML = `
                    <span style="color:#a29bfe; font-family:monospace; font-size:10px; min-width:100px; overflow:hidden; text-overflow:ellipsis;" title="${escHtml(k)}">${escHtml(k)}</span>
                    <span style="color:#636e72;">=</span>
                    <input class="bp-param-val" data-key="${escHtml(k)}" value="${escHtml(v)}" style="flex:1; background:#2d3436; color:#ffd32a; border:1px solid #555; border-radius:3px; padding:3px 6px; font-family:monospace; font-size:10px; outline:none;">`;
                row.querySelector('.bp-param-val').addEventListener('input', () => syncParamsToUrl());
                container.appendChild(row);
            });
        } catch (e) {
            container.innerHTML = '<span style="color:#555; font-size:10px;">（解析失败）</span>';
        }
    }

    function syncParamsToUrl() {
        try {
            const urlEl = root.getElementById('bp-url');
            const u = new URL(urlEl.value);
            root.querySelectorAll('.bp-param-val').forEach(input => {
                u.searchParams.set(input.dataset.key, input.value);
            });
            urlEl.value = u.toString();
        } catch (e) {}
    }

    // Body 格式化 / 压缩
    root.getElementById('bp-format-btn').onclick = (e) => {
        e.stopPropagation();
        const ta = root.getElementById('bp-body');
        try { ta.value = JSON.stringify(JSON.parse(ta.value), null, 2); } catch (e) { alert('不是有效 JSON'); }
    };
    root.getElementById('bp-minify-btn').onclick = (e) => {
        e.stopPropagation();
        const ta = root.getElementById('bp-body');
        try { ta.value = JSON.stringify(JSON.parse(ta.value)); } catch (e) {}
    };

    // AI 场景建议
    root.querySelectorAll('.bp-ai-scenario').forEach(btn => {
        btn.onclick = (e) => {
            e.stopPropagation();
            if (!openAIKey) { alert('请先在设置中配置 API Key'); return; }
            const scene = btn.dataset.scene;
            const resultEl = root.getElementById('bp-ai-result');
            resultEl.textContent = `⏳ AI 正在分析 [${scene}] 场景...`;
            const requestData = {
                url: root.getElementById('bp-url').value,
                headers: root.getElementById('bp-headers').value,
                body: root.getElementById('bp-body').value,
                scene
            };
            sendAIMessage({
                action: 'ANALYZE_WITH_AI',
                content: JSON.stringify(requestData),
                apiKey: openAIKey, apiHost,
                promptType: 'BP_AI_SUGGEST',
                model: aiModel
            }, (res) => {
                if (!res) { resultEl.textContent = '❌ Service Worker 已休眠，请刷新页面重试'; return; }
                if (res.error) { resultEl.textContent = '❌ ' + res.error; return; }
                const raw = res.result;
                resultEl.textContent = raw;
                // 尝试解析 AI 建议中的 JSON 修改方案
                try {
                    const jsonMatch = raw.match(/```json\n?([\s\S]*?)```/);
                    if (jsonMatch) {
                        bpAiSuggestion = JSON.parse(jsonMatch[1]);
                        root.getElementById('bp-ai-apply-url').disabled = !bpAiSuggestion.url;
                        root.getElementById('bp-ai-apply-body').disabled = !bpAiSuggestion.body;
                    }
                } catch (e) {}
            });
        };
    });

    root.getElementById('bp-ai-apply-url').onclick = (e) => {
        e.stopPropagation();
        if (bpAiSuggestion?.url) {
            root.getElementById('bp-url').value = bpAiSuggestion.url;
            renderBpParams(bpAiSuggestion.url);
        }
    };
    root.getElementById('bp-ai-apply-body').onclick = (e) => {
        e.stopPropagation();
        if (bpAiSuggestion?.body) {
            root.getElementById('bp-body').value = typeof bpAiSuggestion.body === 'string'
                ? bpAiSuggestion.body
                : JSON.stringify(bpAiSuggestion.body, null, 2);
        }
    };

    // 丢弃请求
    root.getElementById('bp-abort-btn').onclick = (e) => {
        e.stopPropagation();
        if (!confirm('确定丢弃此请求？目标服务器将不会收到该请求。')) return;
        window.postMessage({ type: 'ABORT_REQUEST', requestId: currentRequestId }, '*');
        bpModal.style.display = 'none';
        root.getElementById('paused-banner').style.display = 'none';
    };

    // 放行（带修改）
    root.getElementById('bp-resume-btn').onclick = (e) => {
        e.stopPropagation();
        const modifiedUrl = root.getElementById('bp-url').value;
        const modifiedBody = root.getElementById('bp-body').value;
        let modifiedHeaders = null;
        try {
            const hText = root.getElementById('bp-headers').value.trim();
            if (hText) modifiedHeaders = JSON.parse(hText);
        } catch (e) { alert('Headers JSON 格式有误，请检查后再放行'); return; }
        window.postMessage({
            type: 'RESUME_REQUEST',
            requestId: currentRequestId,
            modifiedData: { url: modifiedUrl, body: modifiedBody, headers: modifiedHeaders }
        }, '*');
        bpModal.style.display = 'none';
        root.getElementById('paused-banner').style.display = 'none';
    };

    window.showBreakpointModal = (details) => {
        if (!panelHost) createDashboardUI();
        if (panelHost.style.display === 'none') panelHost.style.display = 'block';
        bpAiSuggestion = null;
        currentRequestId = details.requestId;
        // 填充数据
        root.getElementById('bp-url').value = details.url || '';
        root.getElementById('bp-body').value = typeof details.body === 'string'
            ? details.body : JSON.stringify(details.body || {}, null, 2);
        root.getElementById('bp-headers').value = details.headers
            ? JSON.stringify(details.headers, null, 2) : '{}';
        root.getElementById('bp-method-badge').textContent = details.method || 'GET';
        root.getElementById('bp-ai-result').textContent = '点击上方按钮，AI 将分析当前请求并给出攻击/测试建议和修改方案';
        root.getElementById('bp-ai-apply-url').disabled = true;
        root.getElementById('bp-ai-apply-body').disabled = true;
        renderBpParams(details.url || '');
        // 默认展示 URL tab
        root.querySelectorAll('.bp-tab[data-bptab]').forEach(b => { b.style.borderBottom='none'; b.style.color='#aaa'; b.classList.remove('active'); });
        root.querySelectorAll('.bp-tab-content').forEach(c => c.style.display='none');
        const urlTab = root.querySelector('.bp-tab[data-bptab="url"]');
        urlTab.classList.add('active'); urlTab.style.borderBottom='2px solid #ff4757'; urlTab.style.color='#fff';
        root.getElementById('bp-url-tab').style.display = 'flex';
        root.getElementById('paused-banner').style.display = 'block';
        bpModal.style.display = 'block';
    };

    // 动态脚本注入控制
    root.getElementById('apply-script-btn').onclick = (e) => { 
        e.stopPropagation(); 
        dynamicScript = root.getElementById('script-editor').value; 
        chrome.storage.local.set({ dynamicScript }); 
        syncRulesToPage(); 
        alert('✅ 动态 Hook 脚本已下发并生效'); 
    };
    root.getElementById('clear-script-btn').onclick = (e) => { 
        e.stopPropagation(); 
        if (confirm('确定要清空脚本吗?')) { 
            root.getElementById('script-editor').value = ''; 
            dynamicScript = ''; 
            chrome.storage.local.set({ dynamicScript: '' }); 
            syncRulesToPage(); 
        } 
    };
    
    // 静态 Mock 控制
    root.getElementById('add-mock-btn').onclick = (e) => { 
        e.stopPropagation(); 
        const url = root.getElementById('mock-url').value;
        const body = root.getElementById('mock-body').value; 
        if (url && body) { 
            mockRules.push({ urlKeyword: url, responseBody: body, enabled: true }); 
            chrome.storage.local.set({ mockRules }); 
            syncRulesToPage(); 
            renderMockRules(); 
            root.getElementById('mock-url').value = '';
            root.getElementById('mock-body').value = '';
        } 
    };
    
    // Header 伪造控制
    root.getElementById('apply-headers-btn').onclick = () => { 
        try { 
            const json = JSON.parse(root.getElementById('header-config').value); 
            chrome.runtime.sendMessage({ action: 'UPDATE_HEADER_RULES', rules: json }); 
            alert('🎭 身份面具已戴上 (全局 Header 覆盖生效)'); 
        } catch(e) { 
            alert('❌ JSON 格式错误，请检查输入'); 
        } 
    };
    root.getElementById('reset-headers-btn').onclick = () => { 
        chrome.runtime.sendMessage({ action: 'UPDATE_HEADER_RULES', rules: {} }); 
        root.getElementById('header-config').value = ''; 
        alert('😐 身份面具已摘下 (Header 已重置)'); 
    };

    // 溯源搜索引擎
    const tracerBtn = root.getElementById('tracer-btn');
    if (tracerBtn) {
        tracerBtn.onclick = (e) => {
            e.stopPropagation();
            const keyword = root.getElementById('tracer-input').value.trim();
            if (!keyword) { 
                alert('请输入要溯源搜索的内容'); 
                return; 
            }
            const resultsContainer = root.getElementById('tracer-results');
            resultsContainer.innerHTML = '<div style="color:#666; font-size:12px; text-align:center; padding:20px;">🔍 正在穿透历史流量进行溯源...</div>';
            
            chrome.runtime.sendMessage({ action: 'SEARCH_TRACER', keyword: keyword }, (response) => {
                resultsContainer.innerHTML = '';
                const results = response && response.results ? response.results : [];
                if (results.length === 0) { 
                    resultsContainer.innerHTML = '<div style="color:#999; font-size:12px; text-align:center; padding:20px;">🤷‍♂️ 在缓存流量中未找到相关来源</div>'; 
                    return; 
                }
                results.forEach(res => {
                    const item = document.createElement('div');
                    item.style.cssText = "background:#f8f9fa; border:1px solid #eee; padding:10px; margin-bottom:8px; border-radius:4px; font-size:11px; cursor:pointer; transition:background 0.2s;";
                    item.onmouseover = () => item.style.background = '#e8f4f8';
                    item.onmouseout = () => item.style.background = '#f8f9fa';
                    
                    let icon = '📄'; 
                    if (res.type === 'RESPONSE_BODY') icon = '📥'; 
                    if (res.type === 'REQUEST_URL') icon = '🔗';
                    
                    item.innerHTML = `
                        <div style="display:flex; justify-content:space-between; margin-bottom:6px;">
                            <span style="font-weight:bold; color:#2d3436;">${icon} ${res.type}</span>
                            <span style="color:#999;">${res.time}</span>
                        </div>
                        <div style="color:#0984e3; word-break:break-all; margin-bottom:6px; font-family:monospace;">${res.url}</div>
                        <div style="color:#666; background:#fff; padding:6px; border-radius:2px; border:1px dashed #ccc; font-family:monospace; max-height:80px; overflow:hidden;">${res.preview}</div>
                    `;
                    
                    item.onclick = () => { 
                        if (logsMap.has(res.requestId)) { 
                            showLogContent(logsMap.get(res.requestId)); 
                        } else { 
                            alert("❌ 该请求的详情日志已被清理或未缓存"); 
                        } 
                    };
                    resultsContainer.appendChild(item);
                });
            });
        };
    }

    // AI 设置交互与保存
    const hostInput = root.getElementById('ai-host-input');
    const keyInput = root.getElementById('ai-key-input');
    const modelSelect = root.getElementById('ai-model-select');
    const codeModelInput = root.getElementById('ai-code-model-input'); 
    const modelStatus = root.getElementById('model-status');
    const balanceDisplay = root.getElementById('balance-display');
    
    hostInput.value = apiHost;
    keyInput.value = openAIKey;
    codeModelInput.value = codeModel; 
    
    if (aiModel && aiModel !== 'gpt-3.5-turbo') {
        const opt = document.createElement('option'); 
        opt.value = aiModel; 
        opt.innerText = aiModel; 
        modelSelect.appendChild(opt); 
        modelSelect.value = aiModel;
    }

    const refreshModelList = (host, key) => {
        modelStatus.innerText = "状态: 正在拉取模型列表..."; 
        modelStatus.style.color = "#d35400";
        chrome.runtime.sendMessage({ action: 'GET_AI_MODELS', apiHost: host, apiKey: key }, (res) => {
            if (res.error) { 
                modelStatus.innerText = "状态: 连接失败 (" + res.error + ")"; 
                modelStatus.style.color = "#c0392b"; 
            } else {
                modelSelect.innerHTML = ''; 
                res.models.forEach(m => { 
                    const opt = document.createElement('option'); 
                    opt.value = m; 
                    opt.innerText = m; 
                    modelSelect.appendChild(opt); 
                });
                if (res.models.includes(aiModel)) {
                    modelSelect.value = aiModel; 
                } else if (res.models.length > 0) {
                    modelSelect.value = res.models[0];
                }
                modelStatus.innerText = `状态: ✅ 连接成功，已获取 ${res.models.length} 个可用模型`; 
                modelStatus.style.color = "#27ae60";
            }
        });
    };

    if (openAIKey) refreshModelList(apiHost, openAIKey);
    
    root.getElementById('check-balance-btn').onclick = (e) => { 
        e.stopPropagation(); 
        chrome.runtime.sendMessage({ action: 'CHECK_AI_BALANCE', apiHost: hostInput.value.trim(), apiKey: keyInput.value.trim() }, (res) => { 
            if (res.error) {
                balanceDisplay.innerText = "Error: " + res.error; 
            } else {
                balanceDisplay.innerText = `💰 当前账单硬限额: $${res.data.hard_limit_usd || '未知'}`; 
            }
        }); 
    };
    
    root.getElementById('save-key-btn').onclick = (e) => { 
        e.stopPropagation(); 
        apiHost = hostInput.value.trim() || 'https://api.openai.com'; 
        openAIKey = keyInput.value.trim(); 
        aiModel = modelSelect.value; 
        codeModel = codeModelInput.value.trim() || 'claude-haiku-4.5-20251001'; 
        chrome.storage.local.set({ apiHost, openAIKey, aiModel, codeModel }); 
        alert('✅ AI 配置已成功保存！'); 
        refreshModelList(apiHost, openAIKey); 
    };

    // ==========================================
    // AI 分析终端核心逻辑
    // ==========================================
    const aiPanel = root.getElementById('ai-analysis-panel');
    const aiContent = root.getElementById('ai-result-content');
    const codeView = root.getElementById('code-content');
    const modalViewer = root.getElementById('modal-viewer');

    const handleAICall = (type, overrideModel = null) => {
        if (!openAIKey) {
            alert('⚠️ 请先在 [设置] 面板配置您的 API Key');
            root.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            root.querySelectorAll('.content').forEach(c => c.classList.remove('active'));
            root.querySelector('[data-target="settings-view"]').classList.add('active');
            root.getElementById('settings-view').classList.add('active');
            modalViewer.style.display = "none";
            return;
        }

        const rawCode = codeView.innerText;
        if (!rawCode || rawCode.length < 5) {
            alert('❌ 源码内容过短或为空，无法进行分析');
            return;
        }

        const targetModel = overrideModel || aiModel;

        aiPanel.style.display = 'block';
        aiContent.innerHTML = `<span style="color:#f39c12;">⚡ 正在建立神经元连接...<br/>🧠 正在挂载分析核心: [${targetModel}]<br/>⏳ 正在上传待审计代码 (${rawCode.length} 字节)...<br/><br/><span style="color:#888;">* 提示：如果分析过程卡死，请在设置中更换"反汇编专用模型"。</span></span>`;

        // 自动滚动到 AI 面板顶部
        aiPanel.scrollTop = 0;

        sendAIMessage({
            action: 'ANALYZE_WITH_AI',
            content: rawCode,
            apiKey: openAIKey,
            apiHost: apiHost,
            promptType: type,
            model: targetModel
        }, (res) => {
            if (!res) {
                aiContent.innerHTML = `<span style="color:#e74c3c;">❌ Service Worker 已休眠，无法连接 AI 服务。请刷新页面后重试。</span>`;
                return;
            }
            if (res.error) {
                aiContent.innerHTML = `<span style="color:#e74c3c;">❌ 神经网络分析失败: ${res.error}</span><br/><br/><span style="color:#bbb;">* 诊断建议：检查 API Key 余额，或确认当前模型名称拼写是否正确。</span>`;
            } else {
                let formatted = res.result
                    .replace(/</g, "&lt;").replace(/>/g, "&gt;")
                    .replace(/```([\s\S]*?)```/g, '<div style="background:#1e1e1e; color:#9cdcfe; padding:10px; border-radius:4px; margin:8px 0; font-family:monospace; white-space:pre-wrap; overflow-x:auto;">$1</div>')
                    .replace(/\*\*(.*?)\*\*/g, '<strong style="color:#a29bfe;">$1</strong>')
                    .replace(/^- /gm, '• ');
                const header = `<div style="font-size:10px; color:#666; margin-bottom:10px; border-bottom:1px dashed #444; padding-bottom:5px; text-transform:uppercase;">[Sys] Analysis Complete via ${targetModel}</div>`;
                aiContent.innerHTML = header + formatted;
}
});
};
root.getElementById('btn-ai-explain').onclick = (e) => { e.stopPropagation(); handleAICall('EXPLAIN'); };
root.getElementById('btn-ai-ts').onclick = (e) => { e.stopPropagation(); handleAICall('TS_TYPE'); };
root.getElementById('btn-ai-disassemble').onclick = (e) => {
e.stopPropagation();
if (confirm(`⚠️ 深度反汇编操作将把此代码发送至 [${codeModel}] 模型进行去混淆分析。\n\n由于过程消耗 Token 较大，且受限于大模型上下文窗口，巨型文件可能分析失败。\n\n是否继续挂载神经分析引擎？`)) {
handleAICall('DISASSEMBLE', codeModel);
}
};
root.getElementById('btn-format-code').onclick = (e) => {
e.stopPropagation();
try {
const raw = codeView.innerText;
if (raw.trim().startsWith('{') || raw.trim().startsWith('[')) {
const obj = JSON.parse(raw);
codeView.innerHTML = syntaxHighlight(obj);
} else {
// 简单的 JS 代码格式化回车
let formatted = raw.replace(/;/g, ';\n').replace(/{/g, '{\n').replace(/}/g, '\n}');
codeView.innerText = formatted;
}
} catch(e) {
alert('❌ 格式化失败：内容可能包含非标准 JSON 或存在语法错误。');
}
};
root.getElementById('close-ai-panel').onclick = (e) => {
e.stopPropagation();
aiPanel.style.display = 'none';
};
root.getElementById('copy-ai-result').onclick = (e) => {
e.stopPropagation();
const text = root.getElementById('ai-result-content').innerText;
navigator.clipboard.writeText(text).then(() => { e.target.textContent = '✅ 已复制'; setTimeout(() => { e.target.textContent = '📋 复制结果'; }, 1500); });
};
root.getElementById('close-modal').onclick = (e) => {
e.stopPropagation();
modalViewer.style.display = "none";
};
root.getElementById('copy-code').onclick = (e) => {
e.stopPropagation();
navigator.clipboard.writeText(root.getElementById('code-content').innerText).then(() => alert('✅ 源码已复制到剪贴板'));
};
// ── AI 新功能：生成 Mock 数据 ──
root.getElementById('btn-ai-mock').onclick = (e) => { e.stopPropagation(); handleAICall('MOCK_DATA'); };
// ── AI 新功能：生成接口文档 ──
root.getElementById('btn-ai-doc').onclick = (e) => { e.stopPropagation(); handleAICall('API_DOC'); };

// ── 清空日志 ──
root.getElementById('clear-log-btn').onclick = (e) => {
    e.stopPropagation();
    if (!confirm('确定要清空所有抓包记录吗？')) return;
    chrome.runtime.sendMessage({ action: 'CLEAR_LOGS' });
    logsMap.clear();
    const list = root.getElementById('log-list');
    if (list) list.innerHTML = '';
};
// ── 收藏筛选 ──
const starFilterBtn = root.getElementById('star-filter-btn');
starFilterBtn.onclick = (e) => {
    e.stopPropagation();
    showStarredOnly = !showStarredOnly;
    starFilterBtn.style.background = showStarredOnly ? '#f9ca24' : '#dfe6e9';
    starFilterBtn.style.color = showStarredOnly ? '#2d3436' : '#636e72';
    applyFilter();
};
// ── WebSocket 面板 ──
root.getElementById('ws-clear-btn').onclick = (e) => {
    e.stopPropagation();
    root.getElementById('ws-frame-list').innerHTML = '';
};
// ── 性能面板 ──
root.getElementById('perf-refresh-btn').onclick = (e) => {
    e.stopPropagation();
    chrome.runtime.sendMessage({ action: 'GET_PERF_STATS' }, (res) => {
        if (!res) return;
        const container = root.getElementById('perf-content');
        let html = '<table style="width:100%; border-collapse:collapse; font-size:11px;">';
        html += '<tr style="background:#f1f2f6;"><th style="padding:6px; text-align:left;">类型</th><th>请求数</th><th>平均耗时</th><th>最慢</th></tr>';
        for (const [type, stat] of Object.entries(res.byType || {})) {
            const avg = stat.count ? Math.round(stat.totalMs / stat.count) : 0;
            const color = avg > 1000 ? '#d63031' : avg > 500 ? '#e17055' : '#00b894';
            html += `<tr style="border-bottom:1px solid #eee;"><td style="padding:6px;">${type}</td><td style="text-align:center;">${stat.count}</td><td style="text-align:center; color:${color}; font-weight:bold;">${avg}ms</td><td style="text-align:center; color:#d63031;">${stat.max}ms</td></tr>`;
        }
        html += '</table>';
        if (res.slowest && res.slowest.length > 0) {
            html += '<div style="margin-top:15px; font-size:12px; font-weight:bold; color:#2d3436;">🐌 最慢的 10 个请求：</div>';
            res.slowest.forEach((item, i) => {
                html += `<div style="font-size:10px; padding:6px; border-bottom:1px solid #eee; cursor:pointer;" onclick=""><span style="color:#d63031; font-weight:bold;">#${i+1} ${item.duration}ms</span> <span style="color:#0984e3; font-family:monospace; word-break:break-all;">${item.url}</span></div>`;
            });
        }
        container.innerHTML = html;
    });
};
// ── Diff 对比模式 ──
const diffModeBtn = root.getElementById('diff-mode-btn');
const diffPanel = root.getElementById('diff-panel');
const perfContent = root.getElementById('perf-content');
diffModeBtn.onclick = (e) => {
    e.stopPropagation();
    const isActive = diffPanel.style.display !== 'none';
    diffPanel.style.display = isActive ? 'none' : 'flex';
    perfContent.style.display = isActive ? 'block' : 'none';
    diffModeBtn.style.background = isActive ? '#6c5ce7' : '#d63031';
    diffModeBtn.textContent = isActive ? '🔀 开启 Diff 对比模式' : '✕ 关闭 Diff 模式';
};
root.getElementById('run-diff-btn').onclick = (e) => {
    e.stopPropagation();
    if (!diffTargetA || !diffTargetB) { alert('请先在抓包列表中分别选择 A、B 两个请求（右键菜单）'); return; }
    runDiff(diffTargetA, diffTargetB);
};
// ── 本地文件替换 ──
root.getElementById('add-local-btn').onclick = (e) => {
    e.stopPropagation();
    const urlKw = root.getElementById('local-url').value.trim();
    const fileInput = root.getElementById('local-file-input');
    if (!urlKw || !fileInput.files[0]) { alert('请填写 URL 关键字并选择本地文件'); return; }
    const reader = new FileReader();
    reader.onload = (ev) => {
        const rule = { urlKeyword: urlKw, content: ev.target.result, fileName: fileInput.files[0].name, enabled: true };
        localFileRules.push(rule);
        chrome.storage.local.set({ localFileRules });
        window.postMessage({ type: 'UPDATE_LOCAL_FILE_RULES', rules: localFileRules }, '*');
        renderLocalFileRules();
        root.getElementById('local-url').value = '';
        fileInput.value = '';
    };
    reader.readAsText(fileInput.files[0]);
};
// ── CSS 注入 ──
let injectedStyleEl = null;
root.getElementById('apply-css-btn').onclick = (e) => {
    e.stopPropagation();
    const css = root.getElementById('css-inject-input').value.trim();
    if (!css) return;
    if (!injectedStyleEl) {
        injectedStyleEl = document.createElement('style');
        injectedStyleEl.id = '__phantom_css_inject__';
        document.head.appendChild(injectedStyleEl);
    }
    injectedStyleEl.textContent = css;
    cssInjections = [{ css, enabled: true }];
    chrome.storage.local.set({ cssInjections });
    alert('✅ CSS 已注入当前页面');
};
root.getElementById('clear-css-btn').onclick = (e) => {
    e.stopPropagation();
    if (injectedStyleEl) { injectedStyleEl.textContent = ''; }
    cssInjections = [];
    chrome.storage.local.set({ cssInjections });
    root.getElementById('css-inject-input').value = '';
    alert('🧹 CSS 注入已全部清除');
};

// ══════════════════════════════════════
// Dashboard 事件
// ══════════════════════════════════════
root.getElementById('dash-refresh-btn').onclick = (e) => {
    e.stopPropagation();
    chrome.runtime.sendMessage({ action: 'GET_TRAFFIC_TIMELINE' }, (res) => {
        if (!res) return;
        root.getElementById('dash-total').textContent = `总请求: ${res.total}`;
        // 状态码柱状图
        const bars = root.getElementById('status-bars');
        const legend = root.getElementById('status-legend');
        const statColors = { '2xx':'#00b894','3xx':'#0984e3','4xx':'#fdcb6e','5xx':'#d63031','pending':'#b2bec3' };
        const total = Object.values(res.statusStats).reduce((a,b)=>a+b,0) || 1;
        bars.innerHTML = ''; legend.innerHTML = '';
        Object.entries(res.statusStats).forEach(([k, v]) => {
            const pct = Math.round(v / total * 100);
            const bar = document.createElement('div');
            bar.style.cssText = `flex:${Math.max(v,0.5)}; background:${statColors[k]}; border-radius:3px 3px 0 0; min-height:4px; position:relative;`;
            bar.title = `${k}: ${v}`;
            bars.appendChild(bar);
            const lbl = document.createElement('span');
            lbl.innerHTML = `<span style="color:${statColors[k]}">■</span> ${k}:${v}`;
            legend.appendChild(lbl);
        });
        // 折线图 (Canvas)
        const canvas = root.getElementById('rps-canvas');
        const ctx = canvas.getContext('2d');
        const tl = res.timeline.slice(-60);
        ctx.clearRect(0,0,canvas.width,canvas.height);
        if (tl.length > 1) {
            const maxCount = Math.max(...tl.map(t=>t.count), 1);
            ctx.strokeStyle = '#0984e3'; ctx.lineWidth = 1.5; ctx.beginPath();
            tl.forEach((pt, i) => {
                const x = (i / (tl.length-1)) * canvas.width;
                const y = canvas.height - (pt.count / maxCount) * (canvas.height - 4) - 2;
                i === 0 ? ctx.moveTo(x,y) : ctx.lineTo(x,y);
            });
            ctx.stroke();
            // error line
            ctx.strokeStyle = '#d63031'; ctx.lineWidth = 1; ctx.beginPath();
            tl.forEach((pt, i) => {
                const x = (i / (tl.length-1)) * canvas.width;
                const y = canvas.height - (pt.errors / maxCount) * (canvas.height - 4) - 2;
                i === 0 ? ctx.moveTo(x,y) : ctx.lineTo(x,y);
            });
            ctx.stroke();
        }
        // Top 域名
        const domainBars = root.getElementById('domain-bars');
        domainBars.innerHTML = '';
        const sorted = Object.entries(res.domainStats).sort((a,b)=>b[1]-a[1]).slice(0,8);
        const maxD = sorted[0]?.[1] || 1;
        sorted.forEach(([domain, count]) => {
            const row = document.createElement('div');
            row.style.cssText = 'display:flex; align-items:center; gap:8px; margin-bottom:5px; font-size:11px;';
            row.innerHTML = `<span style="width:160px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; color:#2d3436;" title="${domain}">${domain}</span>
                <div style="flex:1; background:#dfe6e9; border-radius:3px; height:12px;">
                  <div style="width:${Math.round(count/maxD*100)}%; background:#6c5ce7; height:100%; border-radius:3px;"></div>
                </div>
                <span style="color:#636e72; width:30px; text-align:right;">${count}</span>`;
            domainBars.appendChild(row);
        });
    });
};

// ══════════════════════════════════════
// HAR 录制/导出/回放 事件
// ══════════════════════════════════════
let harImportedEntries = [];
const harRecordBtn = root.getElementById('har-record-btn');
const harStopBtn = root.getElementById('har-stop-btn');
const harExportBtn = root.getElementById('har-export-btn');
const harStatus = root.getElementById('har-status');

harRecordBtn.onclick = (e) => {
    e.stopPropagation();
    chrome.runtime.sendMessage({ action: 'HAR_START' }, (res) => {
        harRecordBtn.disabled = true; harStopBtn.disabled = false;
        harRecordBtn.style.background = '#b2bec3';
        harStatus.innerHTML = `<span style="color:#d63031;">⏺ 录制中...</span> 开始于 ${new Date(res.time).toLocaleTimeString()}`;
    });
};
harStopBtn.onclick = (e) => {
    e.stopPropagation();
    chrome.runtime.sendMessage({ action: 'HAR_STOP' }, (res) => {
        harRecordBtn.disabled = false; harStopBtn.disabled = true; harExportBtn.disabled = false;
        harRecordBtn.style.background = '#d63031';
        harStatus.innerHTML = `<span style="color:#00b894;">✅ 录制完成</span>，共捕获 <b>${res.count}</b> 个请求`;
    });
};
harExportBtn.onclick = (e) => {
    e.stopPropagation();
    chrome.runtime.sendMessage({ action: 'HAR_EXPORT' }, (res) => {
        if (!res?.har) return;
        const blob = new Blob([JSON.stringify(res.har, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url; a.download = `phantom-${Date.now()}.har`;
        document.body.appendChild(a); a.click(); a.remove();
        URL.revokeObjectURL(url);
    });
};
root.getElementById('har-import-btn').onclick = (e) => {
    e.stopPropagation();
    const fileInput = root.getElementById('har-import-file');
    if (!fileInput.files[0]) { alert('请先选择 .har 文件'); return; }
    const reader = new FileReader();
    reader.onload = (ev) => {
        chrome.runtime.sendMessage({ action: 'HAR_IMPORT', harText: ev.target.result }, (res) => {
            if (res.error) { alert('解析失败: ' + res.error); return; }
            harImportedEntries = res.entries;
            root.getElementById('har-entry-count').textContent = harImportedEntries.length;
            root.getElementById('har-replay-btn').disabled = false;
            const list = root.getElementById('har-entry-list');
            list.innerHTML = '';
            harImportedEntries.slice(0, 50).forEach(e => {
                const d = document.createElement('div');
                d.style.cssText = 'font-size:10px; padding:4px 6px; border-bottom:1px solid #eee; font-family:monospace; color:#636e72; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;';
                d.innerHTML = `<span style="color:${e.method==='POST'?'#e17055':'#00b894'}; font-weight:bold;">${e.method}</span> ${e.url}`;
                list.appendChild(d);
            });
        });
    };
    reader.readAsText(fileInput.files[0]);
};
root.getElementById('har-replay-btn').onclick = (e) => {
    e.stopPropagation();
    if (!harImportedEntries.length) return;
    if (!confirm(`即将回放 ${harImportedEntries.length} 个请求，确认继续？`)) return;
    chrome.runtime.sendMessage({ action: 'HAR_REPLAY', entries: harImportedEntries });
    alert(`🚀 已下发回放指令，${harImportedEntries.length} 个请求将陆续发出`);
};

// ══════════════════════════════════════
// 请求构造器 事件
// ══════════════════════════════════════
root.querySelectorAll('.req-tab-btn').forEach(btn => {
    btn.onclick = (e) => {
        e.stopPropagation();
        root.querySelectorAll('.req-tab-btn').forEach(b => { b.classList.remove('active'); b.style.borderBottom = 'none'; });
        root.querySelectorAll('.req-tab-content').forEach(c => c.style.display = 'none');
        btn.classList.add('active'); btn.style.borderBottom = '2px solid #0984e3';
        root.getElementById(`req-${btn.dataset.rtab}-tab`).style.display = 'block';
    };
});
root.getElementById('req-send-btn').onclick = async (e) => {
    e.stopPropagation();
    const method = root.getElementById('req-method').value;
    let url = root.getElementById('req-url').value.trim();
    const headersText = root.getElementById('req-headers').value.trim();
    const bodyText = root.getElementById('req-body').value.trim();
    const paramsText = root.getElementById('req-params').value.trim();
    const respEl = root.getElementById('req-response');
    if (!url) { alert('请输入 URL'); return; }
    // 拼接 params
    if (paramsText) {
        const sp = new URLSearchParams();
        paramsText.split('\n').forEach(line => { const [k, ...v] = line.split('='); if (k) sp.set(k.trim(), v.join('=').trim()); });
        url += (url.includes('?') ? '&' : '?') + sp.toString();
    }
    let headers = {};
    try { if (headersText) headers = JSON.parse(headersText); } catch (e) { alert('Headers JSON 格式错误'); return; }
    respEl.textContent = '⏳ 发送中...';
    respEl.style.color = '#f39c12';
    const opts = { method, headers };
    if (['POST','PUT','PATCH'].includes(method) && bodyText) opts.body = bodyText;
    const t0 = Date.now();
    try {
        const res = await fetch(url, opts);
        const text = await res.text();
        const ms = Date.now() - t0;
        let displayText = text;
        try { displayText = JSON.stringify(JSON.parse(text), null, 2); } catch (e) {}
        respEl.style.color = res.ok ? '#00b894' : '#e74c3c';
        respEl.textContent = `HTTP ${res.status} · ${ms}ms\n\n${displayText}`;
    } catch (err) {
        respEl.style.color = '#e74c3c';
        respEl.textContent = `❌ 请求失败: ${err.message}`;
    }
};
root.getElementById('req-from-log-btn').onclick = (e) => {
    e.stopPropagation();
    // 取最近一条有 postData 的日志填充
    const logs = [...logsMap.values()];
    const recent = logs.find(l => l.postData) || logs[0];
    if (!recent) { alert('暂无抓包记录可导入'); return; }
    root.getElementById('req-url').value = recent.url;
    root.getElementById('req-method').value = recent.method || 'GET';
    if (recent.postData) root.getElementById('req-body').value = recent.postData;
    if (recent.requestHeaders) root.getElementById('req-headers').value = JSON.stringify(recent.requestHeaders, null, 2);
    alert('✅ 已从最近抓包记录导入');
};
root.getElementById('req-gen-code-btn').onclick = (e) => {
    e.stopPropagation();
    if (!openAIKey) { alert('请先在设置中配置 API Key'); return; }
    const method = root.getElementById('req-method').value;
    const url = root.getElementById('req-url').value.trim();
    const body = root.getElementById('req-body').value.trim();
    const headers = root.getElementById('req-headers').value.trim();
    if (!url) { alert('请输入 URL'); return; }
    const content = JSON.stringify({ method, url, body, headers });
    root.getElementById('req-response').textContent = '⏳ AI 生成代码中...';
    sendAIMessage({ action: 'ANALYZE_WITH_AI', content, apiKey: openAIKey, apiHost, promptType: 'CODE_GEN', model: aiModel }, (res) => {
        if (!res) { root.getElementById('req-response').textContent = '❌ Service Worker 已休眠，请刷新页面重试'; return; }
        if (res.error) { root.getElementById('req-response').textContent = '❌ ' + res.error; return; }
        try {
            const codes = JSON.parse(res.result.replace(/```json\n?|\n?```/g, ''));
            showCodeGenModal(codes);
        } catch (e) {
            root.getElementById('req-response').textContent = res.result;
        }
    });
};
root.getElementById('req-ai-fuzz-btn').onclick = (e) => {
    e.stopPropagation();
    if (!openAIKey) { alert('请先在设置中配置 API Key'); return; }
    const method = root.getElementById('req-method').value;
    const url = root.getElementById('req-url').value.trim();
    const body = root.getElementById('req-body').value.trim();
    if (!url) { alert('请输入 URL'); return; }
    root.getElementById('req-response').textContent = '🤖 AI 正在生成 Fuzz 用例...';
    const content = JSON.stringify({ method, url, body, headers: root.getElementById('req-headers').value });
    sendAIMessage({ action: 'AI_FUZZ', content, apiKey: openAIKey, apiHost, model: aiModel }, (res) => {
        if (!res) { root.getElementById('req-response').textContent = '❌ Service Worker 已休眠，请刷新页面重试'; return; }
        if (res.error) { root.getElementById('req-response').textContent = '❌ ' + res.error; return; }
        try {
            const cases = JSON.parse(res.result.replace(/```json\n?|\n?```/g, ''));
            showFuzzCases(cases);
        } catch (e) {
            root.getElementById('req-response').textContent = res.result;
        }
    });
};

// ══════════════════════════════════════
// 🔑 密钥库 事件
// ══════════════════════════════════════
root.getElementById('vault-filter-cat').onchange = () => renderKeyVault();

root.getElementById('vault-export-btn').onclick = (e) => {
    e.stopPropagation();
    if (!keyVault.length) { alert('密钥库为空'); return; }
    const data = JSON.stringify(keyVault, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `phantom-keyvault-${Date.now()}.json`;
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
};

root.getElementById('vault-clear-btn').onclick = (e) => {
    e.stopPropagation();
    if (!confirm('确定清空密钥库？')) return;
    keyVault = [];
    renderKeyVault();
};

// ══════════════════════════════════════
// 🔬 参数追踪 事件
// ══════════════════════════════════════
root.getElementById('tracer2-clear-btn').onclick = (e) => {
    e.stopPropagation();
    root.getElementById('tracer2-list').innerHTML = '';
    root.getElementById('tracer2-count').textContent = '0 条';
};

root.getElementById('tracer2-search-btn').onclick = (e) => {
    e.stopPropagation();
    const key = root.getElementById('tracer2-key').value.trim();
    const val = root.getElementById('tracer2-val').value.trim();
    if (!key && !val) { alert('请输入参数名或参数值'); return; }
    const resultEl = root.getElementById('tracer2-manual-result');
    resultEl.innerHTML = '<div style="color:#6b7280;font-size:11px;">🔍 追踪中...</div>';
    chrome.runtime.sendMessage({ action: 'ANALYZE_PARAM_SOURCE', key: key || val, value: val || key }, (res) => {
        if (!res || !res.result) {
            resultEl.innerHTML = '<div style="color:#9ca3af;font-size:11px;">未找到相关记录，请先浏览页面让插件抓包</div>';
            return;
        }
        resultEl.innerHTML = buildParamResultHTML(res.result);
    });
};

// ══════════════════════════════════════
// 告警规则 事件
// ══════════════════════════════════════
let localAlertRules = [];
chrome.runtime.sendMessage({ action: 'GET_ALERT_RULES' }, (res) => { if (res) { localAlertRules = res.rules; renderAlertRules(); } });

root.getElementById('alert-add-btn').onclick = (e) => {
    e.stopPropagation();
    const name = root.getElementById('alert-name').value.trim();
    const type = root.getElementById('alert-type').value;
    const value = root.getElementById('alert-value').value.trim();
    if (!value) { alert('请填写触发值'); return; }
    localAlertRules.push({ name: name || type, type, value, enabled: true, id: Date.now() });
    chrome.runtime.sendMessage({ action: 'SAVE_ALERT_RULES', rules: localAlertRules });
    renderAlertRules();
    root.getElementById('alert-name').value = '';
    root.getElementById('alert-value').value = '';
};

// ══════════════════════════════════════
// Schema 检测 事件
// ══════════════════════════════════════
root.getElementById('schema-refresh-btn').onclick = (e) => {
    e.stopPropagation();
    chrome.runtime.sendMessage({ action: 'GET_SCHEMA_SNAPSHOTS' }, (res) => {
        if (!res) return;
        renderSchemaSnapshots(res.snapshots);
    });
};

// ══════════════════════════════════════
// Storage 审计 事件
// ══════════════════════════════════════
root.querySelectorAll('.storage-tab-btn').forEach(btn => {
    btn.onclick = (e) => {
        e.stopPropagation();
        root.querySelectorAll('.storage-tab-btn').forEach(b => { b.classList.remove('active'); b.style.borderBottom='none'; });
        root.querySelectorAll('.storage-tab-content').forEach(c => c.style.display='none');
        btn.classList.add('active'); btn.style.borderBottom='2px solid #0984e3';
        root.getElementById(`storage-${btn.dataset.stab}-tab`).style.display='block';
    };
});

root.getElementById('storage-dump-btn').onclick = (e) => {
    e.stopPropagation();
    window.postMessage({ type: 'DUMP_STORAGE', __phantom_origin: true }, '*');
};
root.getElementById('storage-clear-log-btn').onclick = (e) => {
    e.stopPropagation();
    root.getElementById('storage-log-tab').innerHTML = '';
};

function renderStorageKV(tabId, data) {
    const tab = root.getElementById(tabId);
    tab.innerHTML = '';
    const entries = Object.entries(data);
    if (!entries.length) { tab.innerHTML = '<div style="color:#999; font-size:11px; padding:8px;">（空）</div>'; return; }
    entries.forEach(([k, v]) => {
        const row = document.createElement('div');
        row.style.cssText = 'display:flex; gap:8px; align-items:flex-start; padding:5px 0; border-bottom:1px solid #f1f3f5; font-size:11px;';
        let displayV = v;
        try { displayV = JSON.stringify(JSON.parse(v), null, 2); } catch(e) {}
        row.innerHTML = `
            <span style="color:#6c5ce7; font-family:monospace; min-width:120px; word-break:break-all; flex-shrink:0;" title="${escHtml(k)}">${escHtml(k)}</span>
            <span style="color:#2d3436; font-family:monospace; word-break:break-all; flex:1; white-space:pre-wrap; max-height:60px; overflow:hidden;" title="${escHtml(v)}">${escHtml(String(displayV).substring(0,200))}</span>
            <button class="btn-small copy-storage-val" data-val="${escHtml(v)}" style="flex-shrink:0; background:#0984e3; padding:2px 7px;">复制</button>`;
        row.querySelector('.copy-storage-val').onclick = (e) => {
            e.stopPropagation();
            navigator.clipboard.writeText(e.target.dataset.val).then(()=>alert('✅ 已复制'));
        };
        tab.appendChild(row);
    });
}

// ══════════════════════════════════════
// WS 拦截规则 事件
// ══════════════════════════════════════

function renderWsRules() {
    const list = root.getElementById('ws-rule-list');
    list.innerHTML = '';
    if (!wsModifyRules.length) { list.innerHTML = '<div style="color:#999; font-size:11px; padding:4px;">暂无规则</div>'; return; }
    wsModifyRules.forEach((rule, idx) => {
        const div = document.createElement('div');
        div.style.cssText = 'display:flex; align-items:center; gap:6px; padding:5px 0; border-bottom:1px solid #f1f3f5; font-size:11px;';
        div.innerHTML = `
            <input type="checkbox" ${rule.enabled?'checked':''} style="margin:0;">
            <span style="flex:1; font-family:monospace; color:#6c5ce7;">${rule.urlKeyword}</span>
            <span style="background:${rule.direction==='SEND'?'#00b894':rule.direction==='RECV'?'#0984e3':'#6c5ce7'}; color:white; padding:1px 6px; border-radius:10px; font-size:9px;">${rule.direction}</span>
            <button class="btn-small del-ws-rule" style="background:#e74c3c; padding:2px 7px;">删除</button>`;
        div.querySelector('input').onchange = (e) => {
            wsModifyRules[idx].enabled = e.target.checked;
            syncWsRules();
        };
        div.querySelector('.del-ws-rule').onclick = (e) => {
            e.stopPropagation();
            wsModifyRules.splice(idx, 1);
            syncWsRules();
            renderWsRules();
        };
        list.appendChild(div);
    });
}

function syncWsRules() {
    window.postMessage({ type: 'UPDATE_WS_RULES', rules: wsModifyRules, __phantom_origin: true }, '*');
}

root.getElementById('ws-rule-add-btn').onclick = (e) => {
    e.stopPropagation();
    const kw = root.getElementById('ws-rule-url').value.trim();
    const dir = root.getElementById('ws-rule-dir').value;
    const body = root.getElementById('ws-rule-body').value.trim();
    if (!kw || !body) { alert('请填写 URL 关键字和改写 JSON'); return; }
    try { JSON.parse(body); } catch(e) { alert('改写 JSON 格式错误'); return; }
    wsModifyRules.push({ urlKeyword: kw, direction: dir, rewriteBody: body, enabled: true });
    syncWsRules();
    renderWsRules();
    root.getElementById('ws-rule-url').value = '';
    root.getElementById('ws-rule-body').value = '';
};

root.getElementById('ws-breakpoint-toggle').onchange = (e) => {
    wsBreakpointEnabled = e.target.checked;
};
root.getElementById('ws-bp-keyword').oninput = (e) => {
    wsBreakpointKeyword = e.target.value.trim();
};
root.getElementById('ws-intercept-clear').onclick = (e) => {
    e.stopPropagation();
    root.getElementById('ws-intercept-log').innerHTML = '';
};

// ══════════════════════════════════════
// 脚本编辑器升级 事件
// ══════════════════════════════════════
const scriptEditor = root.getElementById('script-editor');
const lineNumbers = root.getElementById('script-line-numbers');
const errorBar = root.getElementById('script-error-bar');

const scriptTemplates = [
    { name: '修改响应字段', code: `// 修改 JSON 响应中的字段\nif (url.includes('/api/user')) {\n  const data = JSON.parse(response);\n  data.vip = true;\n  data.level = 999;\n  return JSON.stringify(data);\n}` },
    { name: '延迟响应', code: `// 模拟网络延迟\nawait new Promise(r => setTimeout(r, 2000));\nreturn response;` },
    { name: '注入响应头字段', code: `// 在 JSON 响应顶层注入字段\nconst data = JSON.parse(response);\ndata.__phantom_injected = true;\ndata.debug_uid = 123456;\nreturn JSON.stringify(data, null, 2);` },
    { name: '过滤敏感字段', code: `// 删除响应中的敏感字段\nconst data = JSON.parse(response);\ndelete data.password;\ndelete data.token;\ndelete data.secret;\nreturn JSON.stringify(data);` },
];

root.getElementById('script-template-btn').onclick = (e) => {
    e.stopPropagation();
    const menu = document.createElement('div');
    menu.style.cssText = 'position:fixed; z-index:999999; background:#282c34; border:1px solid #444; border-radius:4px; padding:4px 0; font-size:11px; min-width:150px;';
    const rect = e.target.getBoundingClientRect();
    menu.style.left = rect.left + 'px'; menu.style.top = (rect.bottom + 4) + 'px';
    scriptTemplates.forEach(t => {
        const item = document.createElement('div');
        item.style.cssText = 'padding:8px 12px; color:#dfe6e9; cursor:pointer;';
        item.textContent = t.name;
        item.onmouseenter = () => item.style.background = '#3d4451';
        item.onmouseleave = () => item.style.background = '';
        item.onclick = (ev) => { ev.stopPropagation(); scriptEditor.value = t.code; updateLineNumbers(); menu.remove(); };
        menu.appendChild(item);
    });
    document.body.appendChild(menu);
    setTimeout(() => document.addEventListener('click', () => menu.remove(), { once: true }), 0);
};

root.getElementById('script-ai-gen-btn').onclick = (e) => {
    e.stopPropagation();
    const prompt = window.prompt('描述你想要的脚本效果（如：把所有接口响应的 code 字段改为 0）:');
    if (!prompt) return;
    if (!openAIKey) { alert('请先配置 API Key'); return; }
    e.target.textContent = '⏳...';
    sendAIMessage({
        action: 'ANALYZE_WITH_AI', apiKey: openAIKey, apiHost, model: aiModel,
        promptType: 'SCRIPT_GEN',
        content: `Generate a Phantom hook script. Context: url, method, response (string) are available. Return modified response string or original.\nRequirement: ${prompt}`
    }, (res) => {
        e.target.textContent = '🤖 AI 生成';
        if (!res) { alert('❌ Service Worker 已休眠，请刷新页面重试'); return; }
        if (res.error) { alert('❌ ' + res.error); return; }
        const code = (res.result.match(/```(?:javascript|js)?\n?([\s\S]*?)```/) || [,''])[1] || res.result;
        scriptEditor.value = code.trim();
        updateLineNumbers();
        validateScript();
    });
};

root.getElementById('script-validate-btn').onclick = (e) => {
    e.stopPropagation();
    validateScript();
};

function validateScript() {
    const code = scriptEditor.value.trim();
    if (!code) { errorBar.style.display='none'; return; }
    try {
        new Function('url', 'method', 'response', code);
        errorBar.style.display = 'none';
        root.getElementById('script-context-hint').innerHTML = '<span style="color:#00b894;">✅ 语法无误</span>';
    } catch (err) {
        errorBar.style.display = 'block';
        errorBar.textContent = `❌ 语法错误: ${err.message}`;
        root.getElementById('script-context-hint').innerHTML = `<span style="color:#d63031;">${err.message}</span>`;
    }
}

function updateLineNumbers() {
    const lines = scriptEditor.value.split('\n').length;
    lineNumbers.innerHTML = Array.from({length: lines}, (_, i) => `<div style="line-height:1.6;">${i+1}</div>`).join('');
}

scriptEditor.addEventListener('input', () => { updateLineNumbers(); validateScript(); });
scriptEditor.addEventListener('scroll', () => { lineNumbers.scrollTop = scriptEditor.scrollTop; });
scriptEditor.addEventListener('keydown', (e) => {
    if (e.key === 'Tab') {
        e.preventDefault();
        const start = scriptEditor.selectionStart;
        const end = scriptEditor.selectionEnd;
        scriptEditor.value = scriptEditor.value.substring(0, start) + '  ' + scriptEditor.value.substring(end);
        scriptEditor.selectionStart = scriptEditor.selectionEnd = start + 2;
        updateLineNumbers();
    }
});

// 初始化行号
updateLineNumbers();

// ══════════════════════════════════════
// 规则集导入 / 导出 事件
// ══════════════════════════════════════
root.getElementById('config-export-btn').onclick = (e) => {
    e.stopPropagation();
    const statusEl = root.getElementById('config-status');
    statusEl.textContent = '⏳ 导出中...';
    chrome.runtime.sendMessage({ action: 'EXPORT_CONFIG' }, (res) => {
        if (!res?.config) { statusEl.textContent = '❌ 导出失败'; return; }
        const blob = new Blob([JSON.stringify(res.config, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `phantom-config-${new Date().toISOString().slice(0,10)}.json`;
        document.body.appendChild(a); a.click(); a.remove();
        URL.revokeObjectURL(url);
        statusEl.innerHTML = '<span style="color:#00b894;">✅ 已导出配置文件</span>';
    });
};
root.getElementById('config-import-btn').onclick = (e) => {
    e.stopPropagation();
    root.getElementById('config-import-file').click();
};
root.getElementById('config-import-file').onchange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const statusEl = root.getElementById('config-status');
    statusEl.textContent = `⏳ 正在导入 ${file.name}...`;
    const reader = new FileReader();
    reader.onload = (ev) => {
        chrome.runtime.sendMessage({ action: 'IMPORT_CONFIG', configText: ev.target.result }, (res) => {
            if (res?.error) {
                statusEl.innerHTML = `<span style="color:#e74c3c;">❌ 导入失败: ${res.error}</span>`;
            } else {
                statusEl.innerHTML = '<span style="color:#00b894;">✅ 导入成功，请重新加载扩展使配置生效</span>';
                // 重新读取 storage 刷新本地状态
                chrome.storage.local.get(null, (data) => {
                    if (data.mockRules) mockRules = data.mockRules;
                    if (data.alertRules) { localAlertRules = data.alertRules; renderAlertRules(); }
                });
            }
        });
    };
    reader.readAsText(file);
    e.target.value = '';
};

// ══════════════════════════════════════
// 编解码工具箱 事件
// ══════════════════════════════════════
root.querySelectorAll('.enc-btn').forEach(btn => {
    btn.onclick = (e) => {
        e.stopPropagation();
        const input = root.getElementById('encode-input').value;
        const output = root.getElementById('encode-output');
        const op = btn.dataset.enc;
        try {
            let result = '';
            switch(op) {
                case 'base64-enc': result = btoa(unescape(encodeURIComponent(input))); break;
                case 'base64-dec': result = decodeURIComponent(escape(atob(input.trim()))); break;
                case 'url-enc': result = encodeURIComponent(input); break;
                case 'url-dec': result = decodeURIComponent(input); break;
                case 'hex-enc': result = Array.from(new TextEncoder().encode(input)).map(b => b.toString(16).padStart(2,'0')).join(' '); break;
                case 'hex-dec': result = new TextDecoder().decode(new Uint8Array(input.trim().split(/[\s,]+/).map(h => parseInt(h, 16)))); break;
                case 'unicode-enc': result = Array.from(input).map(c => '\\u' + c.charCodeAt(0).toString(16).padStart(4,'0')).join(''); break;
                case 'unicode-dec': result = input.replace(/\\u([0-9a-fA-F]{4})/g, (_, h) => String.fromCharCode(parseInt(h,16))); break;
                case 'html-enc': { const t = document.createElement('span'); t.textContent = input; result = t.innerHTML; break; }
                case 'html-dec': { const t = document.createElement('span'); t.innerHTML = input; result = t.textContent; break; }
                case 'md5': result = phantomMD5(input); break;
                case 'sha256':
                    crypto.subtle.digest('SHA-256', new TextEncoder().encode(input)).then(buf => {
                        output.value = Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2,'0')).join('');
                    });
                    output.value = '计算中...';
                    return;
            }
            output.value = result;
        } catch(err) { output.value = '错误: ' + err.message; }
    };
});
root.getElementById('encode-copy-btn').onclick = (e) => {
    e.stopPropagation();
    navigator.clipboard.writeText(root.getElementById('encode-output').value).then(() => alert('已复制'));
};
root.getElementById('encode-swap-btn').onclick = (e) => {
    e.stopPropagation();
    root.getElementById('encode-input').value = root.getElementById('encode-output').value;
    root.getElementById('encode-output').value = '';
};

// ══════════════════════════════════════
// JWT 解码器 事件
// ══════════════════════════════════════
root.getElementById('jwt-decode-btn').onclick = (e) => {
    e.stopPropagation();
    const token = root.getElementById('jwt-input').value.trim();
    const resultDiv = root.getElementById('jwt-result');
    if (!token) { resultDiv.innerHTML = '<div style="color:#e74c3c;">请输入 JWT token</div>'; return; }
    try {
        const parts = token.split('.');
        if (parts.length < 2) throw new Error('格式无效: JWT 至少需要 2 段');
        const decodeB64 = (s) => {
            let b = s.replace(/-/g,'+').replace(/_/g,'/');
            while (b.length % 4) b += '=';
            return decodeURIComponent(escape(atob(b)));
        };
        const header = JSON.parse(decodeB64(parts[0]));
        const payload = JSON.parse(decodeB64(parts[1]));
        let html = '<div style="margin-bottom:12px;">';
        html += '<div style="color:#6c5ce7; font-weight:bold; margin-bottom:4px;">Header:</div>';
        html += `<pre style="background:#1e2127; color:#abb2bf; padding:8px; border-radius:4px; margin:0; white-space:pre-wrap;">${escHtml(JSON.stringify(header, null, 2))}</pre>`;
        html += '</div>';
        html += '<div style="margin-bottom:12px;">';
        html += '<div style="color:#00b894; font-weight:bold; margin-bottom:4px;">Payload:</div>';
        html += `<pre style="background:#1e2127; color:#abb2bf; padding:8px; border-radius:4px; margin:0; white-space:pre-wrap;">${escHtml(JSON.stringify(payload, null, 2))}</pre>`;
        html += '</div>';
        // 时间字段解析
        const timeFields = ['iat','exp','nbf','auth_time'];
        timeFields.forEach(f => {
            if (payload[f]) {
                const d = new Date(payload[f] * 1000);
                const isExpired = f === 'exp' && d < new Date();
                html += `<div style="font-size:11px; margin-bottom:4px;"><span style="color:#636e72;">${f}:</span> <span style="color:${isExpired?'#e74c3c':'#2d3436'};">${d.toLocaleString()}${isExpired?' (已过期)':''}</span></div>`;
            }
        });
        if (parts[2]) {
            html += '<div style="margin-top:10px;"><div style="color:#e17055; font-weight:bold; margin-bottom:4px;">Signature:</div>';
            html += `<div style="color:#636e72; word-break:break-all; font-size:10px;">${parts[2]}</div></div>`;
        }
        resultDiv.innerHTML = html;
    } catch(err) { resultDiv.innerHTML = `<div style="color:#e74c3c;">解码失败: ${err.message}</div>`; }
};

// ══════════════════════════════════════
// 安全头检测 事件
// ══════════════════════════════════════
root.getElementById('secheader-scan-btn').onclick = (e) => {
    e.stopPropagation();
    root.getElementById('secheader-results').innerHTML = '<div style="color:#636e72; padding:8px;">扫描中...</div>';
    chrome.runtime.sendMessage({ action: 'SCAN_SECURITY_HEADERS' }, (res) => {
        const container = root.getElementById('secheader-results');
        if (!res || !res.results) { container.innerHTML = '<div style="color:#e74c3c; padding:8px;">扫描失败</div>'; return; }
        const rawResults = res.results;
        if (!rawResults.length) { root.getElementById('secheader-count').textContent = '0 条发现'; container.innerHTML = '<div style="color:#00b894; padding:8px;">未发现安全头问题</div>'; return; }
        // 拍平为逐条展示
        const items = [];
        rawResults.forEach(r => {
            r.missing.forEach(m => items.push({ header: m.label + ' (缺失)', severity: m.severity.toUpperCase(), message: m.desc, url: r.url }));
            r.leaked.forEach(l => items.push({ header: l.header + ' (泄露)', severity: 'MEDIUM', message: '值: ' + l.value, url: r.url }));
        });
        root.getElementById('secheader-count').textContent = `${items.length} 条发现 (${rawResults.length} 个URL)`;
        container.innerHTML = '';
        items.forEach(r => {
            const sev = { HIGH:'#e74c3c', MEDIUM:'#f39c12', LOW:'#636e72', INFO:'#0984e3' };
            const div = document.createElement('div');
            div.style.cssText = `padding:8px; border-bottom:1px solid #eee; font-size:11px; border-left:3px solid ${sev[r.severity]||'#999'};`;
            div.innerHTML = `<div style="display:flex; justify-content:space-between;"><b style="color:${sev[r.severity]||'#333'};">${escHtml(r.header)}</b><span style="color:#999; font-size:10px;">${escHtml(r.severity)}</span></div>
                <div style="color:#636e72; margin-top:2px;">${escHtml(r.message)}</div>
                <div style="color:#0984e3; font-size:10px; margin-top:2px; word-break:break-all;">${escHtml(r.url?.substring(0,80)||'')}</div>`;
            container.appendChild(div);
        });
    });
};

// ══════════════════════════════════════
// 端点提取 事件
// ══════════════════════════════════════
let extractedEndpoints = [];
root.getElementById('endpoint-scan-btn').onclick = (e) => {
    e.stopPropagation();
    root.getElementById('endpoint-results').innerHTML = '<div style="color:#636e72; padding:8px;">提取中...</div>';
    chrome.runtime.sendMessage({ action: 'EXTRACT_ENDPOINTS' }, (res) => {
        const container = root.getElementById('endpoint-results');
        if (!res || !res.results) { container.innerHTML = '<div style="color:#e74c3c; padding:8px;">提取失败</div>'; return; }
        extractedEndpoints = res.results;
        root.getElementById('endpoint-count').textContent = `${extractedEndpoints.length} 个端点`;
        if (!extractedEndpoints.length) { container.innerHTML = '<div style="color:#636e72; padding:8px;">未提取到端点</div>'; return; }
        container.innerHTML = '';
        extractedEndpoints.forEach(ep => {
            const div = document.createElement('div');
            div.style.cssText = 'padding:6px 8px; border-bottom:1px solid #f5f5f5; cursor:pointer; transition:background 0.2s;';
            div.onmouseenter = () => div.style.background = '#f0f0f0';
            div.onmouseleave = () => div.style.background = '';
            div.innerHTML = `<span style="color:#0984e3; word-break:break-all;">${escHtml(ep.endpoint)}</span>
                <span style="color:#999; font-size:10px; margin-left:8px;">(来自 ${escHtml((ep.sources && ep.sources[0] || 'unknown').substring(0,40))})</span>`;
            div.onclick = (ev) => { ev.stopPropagation(); navigator.clipboard.writeText(ep.endpoint).then(() => { div.style.background='#d5f5e3'; setTimeout(()=>div.style.background='',500); }); };
            container.appendChild(div);
        });
    });
};
root.getElementById('endpoint-export-btn').onclick = (e) => {
    e.stopPropagation();
    if (!extractedEndpoints.length) { alert('请先提取端点'); return; }
    const text = extractedEndpoints.map(ep => ep.endpoint).join('\n');
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `endpoints-${Date.now()}.txt`;
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
};

// ══════════════════════════════════════
// 漏洞扫描 事件
// ══════════════════════════════════════
root.getElementById('vuln-scan-btn').onclick = (e) => {
    e.stopPropagation();
    root.getElementById('vuln-results').innerHTML = '<div style="color:#636e72; padding:8px;">扫描中...</div>';
    chrome.runtime.sendMessage({ action: 'SCAN_VULNS' }, (res) => {
        const container = root.getElementById('vuln-results');
        if (!res || !res.results) { container.innerHTML = '<div style="color:#e74c3c; padding:8px;">扫描失败</div>'; return; }
        const results = res.results;
        root.getElementById('vuln-count').textContent = `${results.length} 条发现`;
        if (!results.length) { container.innerHTML = '<div style="color:#00b894; padding:8px;">未发现安全隐患</div>'; return; }
        container.innerHTML = '';
        results.forEach(v => {
            const sev = { high:'#e74c3c', medium:'#f39c12', low:'#636e72', info:'#0984e3' };
            const div = document.createElement('div');
            div.style.cssText = `padding:8px; border-bottom:1px solid #eee; font-size:11px; border-left:3px solid ${sev[v.severity]||'#999'};`;
            div.innerHTML = `<div style="display:flex; justify-content:space-between;"><b style="color:${sev[v.severity]||'#333'};">${escHtml(v.label)}</b><span style="color:#999; font-size:10px;">${escHtml(v.severity)}</span></div>
                <div style="color:#636e72; margin-top:2px; font-family:monospace; word-break:break-all;">${escHtml(v.match)}</div>
                <div style="color:#0984e3; font-size:10px; margin-top:2px; word-break:break-all;">${escHtml(v.url?.substring(0,80)||'')}</div>`;
            container.appendChild(div);
        });
    });
};

// ══════════════════════════════════════
// 参数挖掘 事件
// ══════════════════════════════════════
let minedParams = [];
root.getElementById('param-mine-btn').onclick = (e) => {
    e.stopPropagation();
    root.getElementById('param-results').innerHTML = '<div style="color:#636e72; padding:8px;">挖掘中...</div>';
    chrome.runtime.sendMessage({ action: 'MINE_PARAMS' }, (res) => {
        const container = root.getElementById('param-results');
        if (!res || !res.results) { container.innerHTML = '<div style="color:#e74c3c; padding:8px;">挖掘失败</div>'; return; }
        minedParams = res.results;
        root.getElementById('param-count').textContent = `${minedParams.length} 个参数`;
        if (!minedParams.length) { container.innerHTML = '<div style="color:#636e72; padding:8px;">未发现参数</div>'; return; }
        container.innerHTML = '';
        minedParams.forEach(p => {
            const typeColors = { Query:'#0984e3', Body:'#e17055', Header:'#6c5ce7' };
            const div = document.createElement('div');
            div.style.cssText = 'padding:6px 8px; border-bottom:1px solid #f5f5f5; font-size:11px;';
            const locBadge = `<span style="background:${typeColors[p.location]||'#636e72'}; color:#fff; padding:1px 5px; border-radius:8px; font-size:9px;">${p.location}</span>`;
            const valPreview = p.values.slice(0,3).map(v => escHtml(String(v).substring(0,30))).join(', ');
            div.innerHTML = `<div style="display:flex; justify-content:space-between; align-items:center;">
                <b style="color:#2d3436;">${escHtml(p.name)}</b>
                <span style="display:flex; gap:3px;">${locBadge} <span style="color:#999; font-size:10px;">x${p.count}</span></span>
            </div>
            <div style="color:#636e72; font-size:10px; margin-top:2px; font-family:monospace;">${valPreview}${p.values.length>3?'...':''}</div>`;
            container.appendChild(div);
        });
    });
};
root.getElementById('param-export-btn').onclick = (e) => {
    e.stopPropagation();
    if (!minedParams.length) { alert('请先挖掘参数'); return; }
    const blob = new Blob([JSON.stringify(minedParams, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `params-${Date.now()}.json`;
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
};

// ══════════════════════════════════════
// 📦 POST 缓存库 事件
// ══════════════════════════════════════
// ══════════════════════════════════════
// 📦 POST 缓存库 事件（多维度联合过滤）
// ══════════════════════════════════════

// 过滤状态
let pcFilter = { methods: new Set(['ALL']), status: 'ALL', body: 'ALL', minMs: 0 };

// Method chips（支持多选）
root.querySelectorAll('.pc-chip').forEach(btn => {
    btn.onclick = (e) => {
        e.stopPropagation();
        const m = btn.dataset.method;
        if (m === 'ALL') {
            // 点"全部"→清除其他选择
            pcFilter.methods = new Set(['ALL']);
            root.querySelectorAll('.pc-chip').forEach(b => {
                const isAll = b.dataset.method === 'ALL';
                b.style.background = isAll ? '#5b6ef5' : '#fff';
                b.style.color = isAll ? '#fff' : ({ GET:'#00b894',POST:'#e17055',PUT:'#a29bfe',PATCH:'#f59e0b',DELETE:'#d63031' }[b.dataset.method] || '#636e72');
                b.classList.toggle('active', isAll);
            });
        } else {
            // 取消"全部"选中
            pcFilter.methods.delete('ALL');
            const allBtn = root.querySelector('.pc-chip[data-method="ALL"]');
            if (allBtn) { allBtn.style.background='#fff'; allBtn.style.color='#5b6ef5'; allBtn.classList.remove('active'); }
            // 切换当前方法
            if (pcFilter.methods.has(m)) {
                pcFilter.methods.delete(m);
                btn.style.background = '#fff';
                btn.style.color = { GET:'#00b894',POST:'#e17055',PUT:'#a29bfe',PATCH:'#f59e0b',DELETE:'#d63031' }[m] || '#636e72';
                btn.classList.remove('active');
            } else {
                pcFilter.methods.add(m);
                btn.style.background = { GET:'#00b894',POST:'#e17055',PUT:'#a29bfe',PATCH:'#f59e0b',DELETE:'#d63031' }[m] || '#636e72';
                btn.style.color = '#fff';
                btn.classList.add('active');
            }
            // 若一个都没选，回到"全部"
            if (pcFilter.methods.size === 0) {
                pcFilter.methods.add('ALL');
                if (allBtn) { allBtn.style.background='#5b6ef5'; allBtn.style.color='#fff'; allBtn.classList.add('active'); }
            }
        }
        renderPostCache();
    };
});

// Status chips（单选）
root.querySelectorAll('.pc-status-chip').forEach(btn => {
    btn.onclick = (e) => {
        e.stopPropagation();
        root.querySelectorAll('.pc-status-chip').forEach(b => {
            b.style.background = '#fff';
            b.style.fontWeight = 'normal';
            b.classList.remove('active');
        });
        pcFilter.status = btn.dataset.status;
        btn.style.background = { ALL:'#5b6ef5','2xx':'#00b894','3xx':'#0984e3','4xx':'#f59e0b','5xx':'#d63031' }[btn.dataset.status] || '#5b6ef5';
        btn.style.color = '#fff';
        btn.style.fontWeight = '600';
        btn.classList.add('active');
        renderPostCache();
    };
});

// Body cache chips（单选）
root.querySelectorAll('.pc-body-chip').forEach(btn => {
    btn.onclick = (e) => {
        e.stopPropagation();
        root.querySelectorAll('.pc-body-chip').forEach(b => {
            b.style.background = '#fff';
            b.style.color = { ALL:'#5b6ef5', HAS:'#10b981', NO:'#9ca3af' }[b.dataset.body] || '#636e72';
            b.classList.remove('active');
        });
        pcFilter.body = btn.dataset.body;
        btn.style.background = { ALL:'#5b6ef5', HAS:'#10b981', NO:'#9ca3af' }[btn.dataset.body] || '#5b6ef5';
        btn.style.color = '#fff';
        btn.classList.add('active');
        renderPostCache();
    };
});

// 关键字搜索（实时）
root.getElementById('postcache-search').oninput = () => renderPostCache();
root.getElementById('postcache-search-scope').onchange = () => renderPostCache();

// 耗时过滤
root.getElementById('postcache-min-ms').oninput = (e) => {
    pcFilter.minMs = parseInt(e.target.value) || 0;
    renderPostCache();
};

// 重置全部过滤
root.getElementById('postcache-filter-reset').onclick = (e) => {
    e.stopPropagation();
    pcFilter = { methods: new Set(['ALL']), status: 'ALL', body: 'ALL', minMs: 0 };
    root.getElementById('postcache-search').value = '';
    root.getElementById('postcache-min-ms').value = '';
    root.getElementById('postcache-search-scope').value = 'url';
    // 重置 method chips
    root.querySelectorAll('.pc-chip').forEach(b => {
        const isAll = b.dataset.method === 'ALL';
        b.style.background = isAll ? '#5b6ef5' : '#fff';
        b.style.color = isAll ? '#fff' : ({ GET:'#00b894',POST:'#e17055',PUT:'#a29bfe',PATCH:'#f59e0b',DELETE:'#d63031' }[b.dataset.method]||'#636e72');
        b.classList.toggle('active', isAll);
    });
    // 重置 status chips
    root.querySelectorAll('.pc-status-chip').forEach(b => {
        const isAll = b.dataset.status === 'ALL';
        b.style.background = isAll ? '#5b6ef5' : '#fff';
        b.style.color = isAll ? '#fff' : ({ '2xx':'#00b894','3xx':'#0984e3','4xx':'#f59e0b','5xx':'#d63031' }[b.dataset.status]||'#636e72');
        b.classList.toggle('active', isAll);
    });
    // 重置 body chips
    root.querySelectorAll('.pc-body-chip').forEach(b => {
        const isAll = b.dataset.body === 'ALL';
        b.style.background = isAll ? '#5b6ef5' : '#fff';
        b.style.color = isAll ? '#fff' : ({ HAS:'#10b981', NO:'#9ca3af' }[b.dataset.body]||'#636e72');
        b.classList.toggle('active', isAll);
    });
    renderPostCache();
};

// 导出（导出当前筛选结果）
root.getElementById('postcache-export-btn').onclick = (e) => {
    e.stopPropagation();
    const toExport = getFilteredPostCache();
    if (!toExport.length) { alert('当前筛选结果为空'); return; }
    const blob = new Blob([JSON.stringify(toExport, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `phantom-postcache-${Date.now()}.json`;
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
};

root.getElementById('postcache-clear-btn').onclick = (e) => {
    e.stopPropagation();
    if (!confirm('确定清空所有缓存记录？')) return;
    postCacheStore = [];
    chrome.storage.local.set({ postCacheStore: [] });
    renderPostCache();
};

// ══════════════════════════════════════
// 🔭 函数追踪 事件
// ══════════════════════════════════════
const funcTraceInput = root.getElementById('functrace-input');
root.getElementById('functrace-add-btn').onclick = (e) => {
    e.stopPropagation();
    const val = funcTraceInput.value.trim();
    if (!val) { alert('请输入函数路径或关键字'); return; }
    const mode = root.getElementById('functrace-mode').value;
    const statusEl = root.getElementById('functrace-hook-status');
    if (statusEl) statusEl.innerHTML = '<span style="color:#f59e0b;">⏳ 挂钩中...</span>';
    window.postMessage({ type: 'TRACE_FUNCTION', target: val, keyword: val, mode }, '*');
    funcTraceInput.value = '';
};
root.getElementById('functrace-clear-btn').onclick = (e) => {
    e.stopPropagation();
    funcTraceStore = [];
    renderFuncTrace();
};

// ══════════════════════════════════════
// 🔓 解密猎手 事件
// ══════════════════════════════════════
root.getElementById('decrypt-clear-btn').onclick = (e) => {
    e.stopPropagation();
    decryptStore = [];
    renderDecryptList();
};
root.getElementById('decrypt-export-btn').onclick = (e) => {
    e.stopPropagation();
    if (!decryptStore.length) { alert('暂无解密记录'); return; }
    const blob = new Blob([JSON.stringify(decryptStore, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href=url; a.download=`phantom-decrypt-${Date.now()}.json`;
    document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
};

// ══════════════════════════════════════
// 🧪 参数加密检测 事件
// ══════════════════════════════════════
root.getElementById('paramcrypto-search').oninput = () => renderParamCryptoList();
root.getElementById('paramcrypto-clear-btn').onclick = (e) => {
    e.stopPropagation();
    paramCryptoStore = [];
    renderParamCryptoList();
};
root.getElementById('paramcrypto-export-btn').onclick = (e) => {
    e.stopPropagation();
    if (!paramCryptoStore.length) { alert('暂无检测记录'); return; }
    const blob = new Blob([JSON.stringify(paramCryptoStore, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href=url; a.download=`phantom-paramcrypto-${Date.now()}.json`;
    document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
};
root.querySelectorAll('.pcc-chip').forEach(btn => {
    btn.onclick = (e) => {
        e.stopPropagation();
        root.querySelectorAll('.pcc-chip').forEach(b => {
            b.style.background='#fff';
            b.style.color = ({ALL:'#5b6ef5',JWT:'#8b5cf6',Base64:'#0984e3',Hex:'#e17055',URLEncoded:'#00b894',AES:'#d63031'}[b.dataset.type]||'#636e72');
            b.classList.remove('active');
        });
        paramCryptoTypeFilter = btn.dataset.type;
        btn.style.background = ({ALL:'#5b6ef5',JWT:'#8b5cf6',Base64:'#0984e3',Hex:'#e17055',URLEncoded:'#00b894',AES:'#d63031'}[btn.dataset.type]||'#5b6ef5');
        btn.style.color = '#fff';
        btn.classList.add('active');
        renderParamCryptoList();
    };
});

window.onclick = (event) => {
if (event.target == modalViewer) {
modalViewer.style.display = "none";
}
};
}
// ==========================================
// 🔬 参数追踪渲染函数
// ==========================================

let tracer2Count = 0;

function buildParamResultHTML(result) {
    if (!result) return '<div style="color:#9ca3af;font-size:11px;">无结果</div>';
    const verdictMap = {
        FROM_RESPONSE: { label: '来自接口响应', color: '#ef4444', icon: '📥' },
        FROM_REQUEST:  { label: '来自其他请求参数', color: '#f59e0b', icon: '🔄' },
        JS_COMPUTED:   { label: 'JS 动态计算', color: '#6c5ce7', icon: '⚙️' }
    };
    const v = verdictMap[result.verdict] || verdictMap.JS_COMPUTED;
    let html = `<div style="background:#fff;border:1px solid #e4e7f0;border-left:3px solid ${v.color};border-radius:8px;padding:10px 12px;font-size:11px;">
        <div style="display:flex;align-items:center;gap:6px;margin-bottom:8px;">
            <span style="font-size:14px;">${v.icon}</span>
            <b style="color:${v.color};">${v.label}</b>
            <code style="background:#f1f5f9;padding:1px 6px;border-radius:4px;font-size:10px;margin-left:auto;">${escHtml(result.key)}</code>
        </div>
        <div style="font-family:monospace;word-break:break-all;color:#1a1d2e;background:#f8fafc;padding:5px 8px;border-radius:4px;margin-bottom:6px;font-size:10px;">${escHtml(result.value)}</div>`;

    if (result.fromResponse && result.fromResponse.length > 0) {
        html += `<div style="color:#ef4444;font-weight:600;margin:6px 0 4px;">📥 在以下响应中发现该值：</div>`;
        result.fromResponse.forEach(r => {
            html += `<div style="padding:4px 8px;background:#fff5f5;border-radius:4px;margin-bottom:3px;">
                <span style="color:#6b7280;font-size:10px;">[${r.source}]</span>
                <span style="color:#0984e3;font-family:monospace;word-break:break-all;font-size:10px;"> ${escHtml(r.url.substring(0,80))}</span>
                ${r.preview ? `<div style="color:#555;font-family:monospace;font-size:9px;margin-top:2px;background:#fff;padding:2px 4px;border-radius:2px;">${escHtml(r.preview)}</div>` : ''}
            </div>`;
        });
    }

    if (result.fromRequest && result.fromRequest.length > 0) {
        html += `<div style="color:#f59e0b;font-weight:600;margin:6px 0 4px;">🔄 在其他请求参数中发现：</div>`;
        result.fromRequest.forEach(r => {
            html += `<div style="padding:4px 8px;background:#fffbeb;border-radius:4px;margin-bottom:3px;font-size:10px;">
                <code style="color:#b45309;">${escHtml(r.paramKey)}</code>
                <span style="color:#6b7280;"> in ${escHtml(r.method)} ${escHtml(r.url.substring(0,60))}</span>
            </div>`;
        });
    }

    if (result.verdict === 'JS_COMPUTED') {
        html += `<div style="color:#6b7280;font-size:10px;margin-top:6px;padding:6px;background:#f5f3ff;border-radius:4px;">
            ⚙️ 未在任何响应体中找到该值，说明由 JS 动态计算生成。<br>
            建议：在「🔎 审计」Tab 查看加密拦截卡片，或在调用栈中定位生成函数。
        </div>`;
    }

    html += '</div>';
    return html;
}

function renderParamAnalysis(trace, analysis) {
    if (!panelRoot) return;
    const list = panelRoot.getElementById('tracer2-list');
    const countEl = panelRoot.getElementById('tracer2-count');
    if (!list) return;

    tracer2Count += analysis.length;
    if (countEl) countEl.textContent = tracer2Count + ' 条';

    const sourceLabel = {
        fetch_url: 'Fetch URL', fetch_body: 'Fetch Body', fetch_header: 'Fetch Header',
        xhr_url: 'XHR URL', xhr_body: 'XHR Body', xhr_header: 'XHR Header'
    };
    const verdictMap = {
        FROM_RESPONSE: { color: '#ef4444', icon: '📥', label: '接口返回' },
        FROM_REQUEST:  { color: '#f59e0b', icon: '🔄', label: '请求透传' },
        JS_COMPUTED:   { color: '#6c5ce7', icon: '⚙️', label: 'JS计算' }
    };

    // 只展示有结论的（JS_COMPUTED 或来源明确的）
    const interesting = analysis.filter(r => r.verdict !== 'JS_COMPUTED' || r.value.length > 8);
    if (!interesting.length) return;

    const wrapper = document.createElement('div');
    wrapper.style.cssText = 'background:#fff;border:1px solid #e4e7f0;border-radius:10px;margin-bottom:10px;overflow:hidden;box-shadow:0 1px 4px rgba(80,90,160,0.07);';

    // 请求头部
    wrapper.innerHTML = `<div style="padding:8px 12px;background:rgba(91,110,245,0.06);border-bottom:1px solid #e4e7f0;display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
        <span style="font-size:10px;font-weight:700;color:#5b6ef5;">${escHtml(sourceLabel[trace.source] || trace.source)}</span>
        <span style="font-family:monospace;font-size:10px;color:#374151;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="${escHtml(trace.url)}">${escHtml((trace.method||'') + ' ' + trace.url.substring(0,70))}</span>
        <span style="font-size:10px;color:#9ca3af;">${new Date(trace.time||Date.now()).toLocaleTimeString()}</span>
    </div>`;

    // 参数分析行
    const body = document.createElement('div');
    body.style.cssText = 'padding:6px 10px;';
    interesting.forEach(r => {
        const v = verdictMap[r.verdict] || verdictMap.JS_COMPUTED;
        const row = document.createElement('div');
        row.style.cssText = `display:flex;align-items:flex-start;gap:6px;padding:5px 4px;border-bottom:1px solid #f1f5f9;cursor:pointer;border-radius:4px;`;
        row.innerHTML = `
            <span title="${v.label}" style="font-size:12px;flex-shrink:0;">${v.icon}</span>
            <div style="flex:1;min-width:0;">
                <div style="display:flex;gap:5px;align-items:center;margin-bottom:2px;flex-wrap:wrap;">
                    <code style="background:#f1f5f9;padding:1px 6px;border-radius:4px;font-size:10px;color:#374151;">${escHtml(r.key)}</code>
                    <span style="color:${v.color};font-size:10px;font-weight:600;">${v.label}</span>
                </div>
                <div style="font-family:monospace;font-size:10px;color:#6b7280;word-break:break-all;background:#f8fafc;padding:2px 6px;border-radius:3px;">${escHtml(r.value.substring(0,100))}${r.value.length>100?'...':''}</div>
                ${r.fromResponse && r.fromResponse[0] ? `<div style="font-size:10px;color:#ef4444;margin-top:2px;">📍 来自: <span style="font-family:monospace;">${escHtml(r.fromResponse[0].url.substring(0,60))}</span></div>` : ''}
                ${r.verdict === 'JS_COMPUTED' && trace.stack ? `<div style="font-size:9px;color:#9ca3af;margin-top:2px;font-family:monospace;word-break:break-all;">调用栈: ${escHtml(trace.stack.substring(0,120))}</div>` : ''}
            </div>
            <button class="param-detail-btn btn-small" style="background:#5b6ef5;padding:2px 7px;font-size:9px;flex-shrink:0;">详情</button>`;

        row.querySelector('.param-detail-btn').onclick = (e) => {
            e.stopPropagation();
            chrome.runtime.sendMessage({ action: 'ANALYZE_PARAM_SOURCE', key: r.key, value: r.value }, (res) => {
                const detail = document.createElement('div');
                detail.style.cssText = 'margin:4px 0 6px 24px;';
                detail.innerHTML = buildParamResultHTML(res?.result);
                // 移除旧的详情
                const old = row.nextElementSibling;
                if (old && old.classList.contains('param-detail-expanded')) old.remove();
                detail.classList.add('param-detail-expanded');
                row.after(detail);
            });
        };
        body.appendChild(row);
    });
    wrapper.appendChild(body);

    // 调用栈折叠区
    if (trace.stack && trace.stack !== 'unknown') {
        const stackDiv = document.createElement('div');
        stackDiv.style.cssText = 'padding:4px 12px 8px;';
        stackDiv.innerHTML = `<details style="font-size:10px;">
            <summary style="color:#9ca3af;cursor:pointer;">📋 调用栈</summary>
            <div style="font-family:monospace;color:#6b7280;word-break:break-all;background:#f8fafc;padding:5px 8px;border-radius:4px;margin-top:4px;">${escHtml(trace.stack)}</div>
        </details>`;
        wrapper.appendChild(stackDiv);
    }

    list.prepend(wrapper);
    // 最多保留 100 条
    while (list.children.length > 100) list.lastElementChild.remove();
}

// ==========================================
// 🔑 密钥库（Key Vault）核心函数
// ==========================================

function addToKeyVault({ type, value, source, category, pinned = false }) {
    if (!value || String(value).length < 4) return;
    const valStr = String(value).trim();
    // 去重：同 type+value 不重复入库
    const exists = keyVault.find(k => k.type === type && k.value === valStr);
    if (exists) {
        exists.count = (exists.count || 1) + 1;
        exists.lastSeen = new Date().toLocaleTimeString();
        if (isPanelOpen && panelRoot) renderKeyVault();
        return;
    }
    const entry = {
        id: Date.now().toString(36) + Math.random().toString(36).substr(2,4),
        type,
        value: valStr,
        source: String(source || '').substring(0, 120),
        category: category || 'OTHER',
        time: new Date().toLocaleTimeString(),
        lastSeen: new Date().toLocaleTimeString(),
        count: 1,
        pinned: pinned || false,
        tag: ''
    };
    keyVault.unshift(entry);
    if (keyVault.length > 500) keyVault.pop();
    if (isPanelOpen && panelRoot) renderKeyVault();
}

function renderKeyVault() {
    if (!panelRoot) return;
    const list = panelRoot.getElementById('vault-list');
    const countEl = panelRoot.getElementById('vault-count');
    const catFilter = panelRoot.getElementById('vault-filter-cat')?.value || 'ALL';
    if (!list) return;

    const filtered = keyVault.filter(k => catFilter === 'ALL' || k.category === catFilter);
    // 置顶已标记
    const sorted = [...filtered].sort((a, b) => (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0));

    if (countEl) countEl.textContent = `${keyVault.length} 条`;
    list.innerHTML = '';

    if (!sorted.length) {
        list.innerHTML = '<div style="color:#9ca3af;font-size:12px;text-align:center;padding:30px;">暂无密钥记录，浏览页面后自动捕获</div>';
        return;
    }

    const catColors = { RESPONSE: '#ef4444', CRYPTO: '#6c5ce7', FIELD: '#f59e0b', OTHER: '#6b7280' };
    const catLabels = { RESPONSE: '响应体', CRYPTO: '加密拦截', FIELD: '敏感字段', OTHER: '其他' };

    sorted.forEach(entry => {
        const div = document.createElement('div');
        div.style.cssText = `background:#fff; border:1px solid ${entry.pinned ? '#4f6ef7' : '#e4e7f0'}; border-left:3px solid ${catColors[entry.category]||'#6b7280'}; border-radius:8px; padding:10px 12px; margin-bottom:8px; font-size:11px; box-shadow:${entry.pinned ? '0 2px 8px rgba(79,110,247,0.12)' : 'none'};`;
        div.innerHTML = `
        <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:6px; flex-wrap:wrap; gap:4px;">
            <div style="display:flex; align-items:center; gap:5px; flex-wrap:wrap;">
                ${entry.pinned ? '<span style="color:#4f6ef7;font-size:13px;" title="已标记">📌</span>' : ''}
                <span style="background:${catColors[entry.category]||'#6b7280'}; color:#fff; font-size:9px; padding:1px 7px; border-radius:10px; font-weight:700;">${catLabels[entry.category]||entry.category}</span>
                <span style="font-weight:600; color:#1a1d2e; font-size:11px; max-width:160px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="${escHtml(entry.type)}">${escHtml(entry.type)}</span>
                ${entry.count > 1 ? `<span style="background:#f1f5f9;color:#6b7280;font-size:9px;padding:1px 5px;border-radius:8px;">${entry.count}次</span>` : ''}
            </div>
            <div style="display:flex; gap:4px;">
                <button class="vault-pin-btn btn-small" style="background:${entry.pinned ? '#4f6ef7' : '#f1f5f9'}; color:${entry.pinned ? '#fff' : '#6b7280'}; padding:2px 8px; font-size:10px;" data-id="${entry.id}">${entry.pinned ? '📌 已标记' : '☆ 标记'}</button>
                <button class="vault-copy-btn btn-small" style="background:#10b981; padding:2px 8px; font-size:10px;" data-val="${escHtml(entry.value)}">复制</button>
                <button class="vault-del-btn btn-small" style="background:#ef4444; padding:2px 8px; font-size:10px;" data-id="${entry.id}">✕</button>
            </div>
        </div>
        <div style="font-family:monospace; word-break:break-all; color:#1a1d2e; background:#f8fafc; border:1px solid #e4e7f0; border-radius:4px; padding:6px 8px; margin-bottom:5px; max-height:60px; overflow:hidden; cursor:pointer; position:relative;" class="vault-val-preview" data-full="${escHtml(entry.value)}">
            ${escHtml(entry.value.substring(0, 120))}${entry.value.length > 120 ? '<span style="color:#9ca3af;">... [点击展开]</span>' : ''}
        </div>
        <div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
            <span style="color:#9ca3af; font-size:10px;" title="${escHtml(entry.source)}">📍 ${escHtml(entry.source.substring(0,60))}${entry.source.length>60?'...':''}</span>
            <span style="color:#9ca3af; font-size:10px; margin-left:auto;">🕒 ${entry.time}</span>
        </div>
        ${entry.tag ? `<div style="margin-top:4px;"><span style="background:#ede9fe;color:#6c5ce7;font-size:10px;padding:1px 8px;border-radius:10px;">🏷 ${escHtml(entry.tag)}</span></div>` : ''}
        <div class="vault-tag-row" style="display:none; margin-top:6px; display:flex; gap:4px; align-items:center;">
            <input class="vault-tag-input" placeholder="添加标签..." style="flex:1; font-size:10px; padding:3px 7px; border:1px solid #e4e7f0; border-radius:4px; outline:none;" value="${escHtml(entry.tag||'')}" data-id="${entry.id}">
            <button class="vault-tag-save btn-small" style="background:#4f6ef7; padding:2px 8px; font-size:10px;" data-id="${entry.id}">保存</button>
        </div>`;

        // 展开/收起值
        div.querySelector('.vault-val-preview').onclick = (e) => {
            e.stopPropagation();
            const el = e.currentTarget;
            if (el.style.maxHeight === 'none') {
                el.style.maxHeight = '60px';
                el.style.overflow = 'hidden';
            } else {
                el.style.maxHeight = 'none';
                el.style.overflow = 'auto';
                el.innerHTML = escHtml(entry.value);
            }
        };
        // 复制
        div.querySelector('.vault-copy-btn').onclick = (e) => {
            e.stopPropagation();
            navigator.clipboard.writeText(entry.value).then(() => {
                e.target.textContent = '✅';
                setTimeout(() => e.target.textContent = '复制', 1500);
            });
        };
        // 标记/取消标记
        div.querySelector('.vault-pin-btn').onclick = (e) => {
            e.stopPropagation();
            entry.pinned = !entry.pinned;
            renderKeyVault();
        };
        // 删除
        div.querySelector('.vault-del-btn').onclick = (e) => {
            e.stopPropagation();
            keyVault = keyVault.filter(k => k.id !== entry.id);
            renderKeyVault();
        };
        // 标签保存
        div.querySelector('.vault-tag-save').onclick = (e) => {
            e.stopPropagation();
            entry.tag = div.querySelector('.vault-tag-input').value.trim();
            renderKeyVault();
        };

        list.appendChild(div);
    });
}

// 构建审计区密钥告警 HTML（KEY_FOUND 用）
function buildKeyAlertHTML({ type, value, source, category }) {
    const catColors = { RESPONSE: '#ef4444', CRYPTO: '#6c5ce7', FIELD: '#f59e0b' };
    const color = catColors[category] || '#ef4444';
    return `<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;">
        <span>⚠️ <b>发现敏感密钥 [${escHtml(type)}]</b></span>
        <div style="display:flex;gap:4px;">
            <span style="background:${color};color:#fff;font-size:9px;padding:1px 6px;border-radius:10px;font-weight:700;">${escHtml(category)}</span>
            <button class="btn-small kv-inline-save" style="background:#10b981;padding:2px 7px;font-size:10px;" data-val="${escHtml(value)}" data-type="${escHtml(type)}">📥 入库</button>
            <button class="btn-small kv-inline-copy" style="background:#4f6ef7;padding:2px 7px;font-size:10px;" data-val="${escHtml(value)}">复制</button>
        </div>
    </div>
    <div style="font-family:monospace;word-break:break-all;color:#b91c1c;background:#fff1f2;padding:5px 8px;border-radius:4px;margin-bottom:4px;">${escHtml(value.substring(0,160))}${value.length>160?'...':''}</div>
    <small style="color:#9ca3af;word-break:break-all;">📍 ${escHtml(source)}</small>`;
}

// 绑定审计区卡片按钮事件
function bindKeyAlertEvents(div) {
    const saveBtn = div.querySelector('.kv-inline-save');
    const copyBtn = div.querySelector('.kv-inline-copy');
    if (saveBtn) {
        saveBtn.onclick = (e) => {
            e.stopPropagation();
            addToKeyVault({ type: saveBtn.dataset.type, value: saveBtn.dataset.val, source: window.location.hostname, category: 'RESPONSE', pinned: true });
            e.target.textContent = '✅ 已入库'; e.target.disabled = true;
        };
    }
    if (copyBtn) {
        copyBtn.onclick = (e) => {
            e.stopPropagation();
            navigator.clipboard.writeText(copyBtn.dataset.val).then(() => { e.target.textContent = '✅'; setTimeout(()=>e.target.textContent='复制',1500); });
        };
    }
}

// ==========================================
// 辅助与工具函数
// ==========================================
// ── 告警规则列表渲染 ──
function renderAlertRules() {
    if (!panelRoot) return;
    const list = panelRoot.getElementById('alert-rule-list');
    if (!list) return;
    list.innerHTML = '';
    if (!localAlertRules.length) { list.innerHTML = '<div style="color:#999; font-size:11px; padding:8px;">暂无规则</div>'; return; }
    localAlertRules.forEach((rule, idx) => {
        const div = document.createElement('div');
        div.style.cssText = 'display:flex; align-items:center; gap:8px; padding:8px 0; border-bottom:1px solid #eee; font-size:11px;';
        div.innerHTML = `
            <input type="checkbox" ${rule.enabled ? 'checked' : ''} style="margin:0;">
            <span style="flex:1;"><b style="color:#2d3436;">${rule.name}</b> <span style="color:#636e72;">[${rule.type}=${rule.value}]</span></span>
            <button class="btn-small del-alert" style="background:#e74c3c; padding:3px 8px;">删除</button>`;
        div.querySelector('input').onchange = (e) => {
            localAlertRules[idx].enabled = e.target.checked;
            chrome.runtime.sendMessage({ action: 'SAVE_ALERT_RULES', rules: localAlertRules });
        };
        div.querySelector('.del-alert').onclick = (e) => {
            e.stopPropagation();
            localAlertRules.splice(idx, 1);
            chrome.runtime.sendMessage({ action: 'SAVE_ALERT_RULES', rules: localAlertRules });
            renderAlertRules();
        };
        list.appendChild(div);
    });
}

// ── Schema 快照列表渲染 ──
function renderSchemaSnapshots(snapshots) {
    if (!panelRoot) return;
    const list = panelRoot.getElementById('schema-snapshot-list');
    if (!list) return;
    list.innerHTML = '';
    if (!snapshots.length) { list.innerHTML = '<div style="color:#999; font-size:11px; padding:12px;">尚无快照。当 XHR 接口有响应时，自动建立首次结构快照。</div>'; return; }
    snapshots.forEach(snap => {
        const div = document.createElement('div');
        div.style.cssText = 'border:1px solid #eee; border-radius:4px; margin-bottom:8px; font-size:11px; overflow:hidden;';
        div.innerHTML = `
            <div style="background:#f8f9fa; padding:8px 10px; display:flex; align-items:center; justify-content:space-between; cursor:pointer;">
                <span style="font-family:monospace; color:#0984e3; word-break:break-all;">${snap.url}</span>
                <div style="display:flex; gap:6px; flex-shrink:0; margin-left:8px;">
                    <button class="btn-small snap-toggle" style="background:#6c5ce7; padding:3px 8px;">展开</button>
                    <button class="btn-small snap-delete" style="background:#e74c3c; padding:3px 8px;">删除</button>
                </div>
            </div>
            <pre class="snap-body" style="display:none; background:#1e1e1e; color:#9cdcfe; padding:10px; margin:0; font-size:10px; max-height:200px; overflow-y:auto; white-space:pre-wrap;">${escHtml(snap.schema)}</pre>`;
        div.querySelector('.snap-toggle').onclick = (e) => {
            e.stopPropagation();
            const pre = div.querySelector('.snap-body');
            const isHidden = pre.style.display === 'none';
            pre.style.display = isHidden ? 'block' : 'none';
            e.target.textContent = isHidden ? '收起' : '展开';
        };
        div.querySelector('.snap-delete').onclick = (e) => {
            e.stopPropagation();
            chrome.runtime.sendMessage({ action: 'DELETE_SCHEMA_SNAPSHOT', url: snap.url }, () => {
                div.remove();
            });
        };
        list.appendChild(div);
    });
}

// ── 代码生成弹窗 ──
function showCodeGenModal(codes) {
    if (!panelRoot) return;
    const modalViewer = panelRoot.getElementById('modal-viewer');
    const codeContent = panelRoot.getElementById('code-content');
    const aiPanel = panelRoot.getElementById('ai-analysis-panel');
    if (aiPanel) aiPanel.style.display = 'none';
    const langs = Object.keys(codes);
    let activeTab = langs[0];
    const tabsHtml = langs.map(l => `<button class="codegen-tab" data-lang="${l}" style="padding:6px 12px; border:none; border-bottom:2px solid ${l===activeTab?'#0984e3':'transparent'}; background:#f8f9fa; cursor:pointer; font-size:11px; font-weight:bold;">${l}</button>`).join('');
    codeContent.innerHTML = `
        <div style="border-bottom:1px solid #eee; display:flex;">${tabsHtml}</div>
        <pre id="codegen-content" style="background:#1e1e1e; color:#9cdcfe; padding:15px; font-size:11px; margin:0; flex:1; overflow:auto; white-space:pre-wrap;">${escHtml(codes[activeTab])}</pre>`;
    codeContent.querySelectorAll('.codegen-tab').forEach(btn => {
        btn.onclick = (e) => {
            e.stopPropagation();
            codeContent.querySelectorAll('.codegen-tab').forEach(b => b.style.borderBottom = 'none');
            btn.style.borderBottom = '2px solid #0984e3';
            codeContent.querySelector('#codegen-content').textContent = codes[btn.dataset.lang];
        };
    });
    modalViewer.style.display = 'block';
}

// ── AI Fuzz 用例展示 ──
function showFuzzCases(cases) {
    if (!panelRoot) return;
    const el = panelRoot.getElementById('req-response');
    el.style.color = '#d4d4d4';
    let html = `<span style="color:#f39c12; font-weight:bold;">🤖 AI 生成了 ${cases.length} 个 Fuzz 用例</span>\n\n`;
    cases.forEach((c, i) => {
        html += `<span style="color:#a29bfe;">[${i+1}] ${c.description}</span>\n`;
        html += `  Method: ${c.method}  URL: ${c.url}\n`;
        if (c.body) html += `  Body: ${c.body.substring(0,100)}${c.body.length>100?'...':''}\n`;
        html += `  期望异常: <span style="color:#fdcb6e;">${c.expectAnomaly}</span>\n\n`;
    });
    el.innerHTML = html;
    // 自动批量发送按钮
    const sendBtn = document.createElement('button');
    sendBtn.textContent = `🚀 批量发送全部 ${cases.length} 个用例`;
    sendBtn.style.cssText = 'background:#d63031; color:white; border:none; padding:8px 14px; border-radius:4px; cursor:pointer; font-size:11px; margin-top:8px;';
    sendBtn.onclick = async () => {
        sendBtn.textContent = '⏳ 发送中...'; sendBtn.disabled = true;
        const results = [];
        for (const c of cases) {
            try {
                const opts = { method: c.method, headers: c.headers || {} };
                if (c.body) opts.body = c.body;
                const r = await fetch(c.url, opts);
                results.push({ desc: c.description, status: r.status, ok: r.ok });
            } catch (err) {
                results.push({ desc: c.description, status: 'ERR', ok: false, err: err.message });
            }
        }
        const anomalies = results.filter(r => !r.ok || r.status >= 400);
        el.innerHTML += `\n<span style="color:#00b894;">✅ 批量发送完成</span> | 异常响应: <span style="color:#d63031; font-weight:bold;">${anomalies.length}</span>/${results.length}\n`;
        results.forEach(r => {
            const color = r.ok ? '#636e72' : '#d63031';
            el.innerHTML += `<span style="color:${color};">[${r.status}] ${r.desc}</span>\n`;
        });
    };
    panelRoot.getElementById('req-response').parentElement.appendChild(sendBtn);
}

// ── WebSocket 帧渲染 ──
function appendWsFrame(container, dir, frame, requestId) {
    const d = document.createElement('div');
    const isSent = dir === 'SENT';
    d.style.cssText = `padding:8px 10px; border-bottom:1px solid #f0f0f0; font-size:11px; display:flex; gap:8px; align-items:flex-start; background:${isSent ? '#fff5f5' : '#f0fff4'};`;
    let preview = frame.data || '';
    if (preview.length > 200) preview = preview.substring(0, 200) + '...';
    d.innerHTML = `
        <span style="font-weight:bold; color:${isSent ? '#d63031' : '#00b894'}; min-width:36px;">${isSent ? '↑ TX' : '↓ RX'}</span>
        <span style="color:#999; min-width:60px;">${frame.time}</span>
        <span style="font-family:monospace; word-break:break-all; color:#2d3436; flex:1;">${preview}</span>
        <button style="background:none; border:none; cursor:pointer; color:#0984e3; font-size:10px;" onclick="navigator.clipboard.writeText(${JSON.stringify(frame.data||'')}).then(()=>alert('已复制'))">复制</button>`;
    container.prepend(d);
    if (container.children.length > 100) container.lastElementChild.remove();
}

// ── Diff 对比引擎 ──
async function runDiff(itemA, itemB) {
    const diffResult = panelRoot.getElementById('diff-result');
    diffResult.innerHTML = '<span style="color:#f39c12;">⏳ 正在加载两个请求的响应体...</span>';
    const [bodyA, bodyB] = await Promise.all([fetchBody(itemA), fetchBody(itemB)]);

    // 尝试 JSON 结构 diff（深度模式）
    let parsedA, parsedB;
    try { parsedA = JSON.parse(bodyA); } catch(e) {}
    try { parsedB = JSON.parse(bodyB); } catch(e) {}

    if (parsedA !== undefined && parsedB !== undefined) {
        // ── JSON 深度结构 Diff ──
        const changes = [];
        jsonDeepDiff(parsedA, parsedB, '', changes);
        const added = changes.filter(c=>c.type==='added').length;
        const removed = changes.filter(c=>c.type==='removed').length;
        const changed = changes.filter(c=>c.type==='changed').length;
        const typeChanged = changes.filter(c=>c.type==='type').length;

        let html = `<div style="margin-bottom:10px; font-size:12px; display:flex; gap:12px; align-items:center; flex-wrap:wrap;">
            <span style="font-weight:bold; color:#2d3436;">JSON 结构 Diff</span>
            <span style="background:#e4ffe4; color:#27ae60; padding:2px 8px; border-radius:10px; font-size:11px;">+ ${added} 新增</span>
            <span style="background:#ffe4e4; color:#c0392b; padding:2px 8px; border-radius:10px; font-size:11px;">- ${removed} 删除</span>
            <span style="background:#fff3cd; color:#b8860b; padding:2px 8px; border-radius:10px; font-size:11px;">~ ${changed} 值变更</span>
            <span style="background:#f0e6ff; color:#6c5ce7; padding:2px 8px; border-radius:10px; font-size:11px;">⚡ ${typeChanged} 类型变化</span>
            <button id="diff-switch-text" style="margin-left:auto; font-size:10px; padding:3px 8px; background:#636e72; color:white; border:none; border-radius:3px; cursor:pointer;">切换文本 Diff</button>
        </div>`;

        if (changes.length === 0) {
            html += '<div style="color:#00b894; padding:12px; text-align:center; font-size:12px;">✅ JSON 结构完全一致</div>';
        } else {
            html += changes.map(c => {
                if (c.type === 'added') return `<div style="background:#e4ffe4; padding:4px 8px; border-left:3px solid #27ae60; margin-bottom:2px; font-family:monospace; font-size:11px;"><span style="color:#27ae60; font-weight:bold;">+ 新增</span> <span style="color:#0984e3;">${escHtml(c.path)}</span> <span style="color:#636e72;">(${escHtml(jsonTypeStr(c.newVal))})</span>: <span style="color:#27ae60;">${escHtml(jsonValStr(c.newVal))}</span></div>`;
                if (c.type === 'removed') return `<div style="background:#ffe4e4; padding:4px 8px; border-left:3px solid #c0392b; margin-bottom:2px; font-family:monospace; font-size:11px;"><span style="color:#c0392b; font-weight:bold;">- 删除</span> <span style="color:#0984e3;">${escHtml(c.path)}</span> <span style="color:#636e72;">(${escHtml(jsonTypeStr(c.oldVal))})</span>: <span style="color:#c0392b;">${escHtml(jsonValStr(c.oldVal))}</span></div>`;
                if (c.type === 'changed') return `<div style="background:#fff9e6; padding:4px 8px; border-left:3px solid #f39c12; margin-bottom:2px; font-family:monospace; font-size:11px;"><span style="color:#f39c12; font-weight:bold;">~ 变更</span> <span style="color:#0984e3;">${escHtml(c.path)}</span>: <span style="color:#c0392b; text-decoration:line-through;">${escHtml(jsonValStr(c.oldVal))}</span> → <span style="color:#27ae60;">${escHtml(jsonValStr(c.newVal))}</span></div>`;
                if (c.type === 'type') return `<div style="background:#f0e6ff; padding:4px 8px; border-left:3px solid #6c5ce7; margin-bottom:2px; font-family:monospace; font-size:11px;"><span style="color:#6c5ce7; font-weight:bold;">⚡ 类型</span> <span style="color:#0984e3;">${escHtml(c.path)}</span>: <span style="color:#c0392b;">${escHtml(jsonTypeStr(c.oldVal))}</span> → <span style="color:#27ae60;">${escHtml(jsonTypeStr(c.newVal))}</span></div>`;
                return '';
            }).join('');
        }

        diffResult.innerHTML = html;
        diffResult.querySelector('#diff-switch-text')?.addEventListener('click', () => renderTextDiff(bodyA, bodyB, diffResult));
    } else {
        // 纯文本 Diff（不是有效 JSON）
        renderTextDiff(bodyA, bodyB, diffResult);
    }
}

function jsonDeepDiff(a, b, path, changes) {
    const typeA = Array.isArray(a) ? 'array' : typeof a;
    const typeB = Array.isArray(b) ? 'array' : typeof b;
    if (typeA !== typeB) { changes.push({ type: 'type', path: path||'(root)', oldVal: a, newVal: b }); return; }
    if (typeA === 'object' && a !== null && b !== null) {
        const allKeys = new Set([...Object.keys(a), ...Object.keys(b)]);
        allKeys.forEach(k => {
            const nextPath = path ? `${path}.${k}` : k;
            if (!(k in a)) { changes.push({ type: 'added', path: nextPath, newVal: b[k] }); }
            else if (!(k in b)) { changes.push({ type: 'removed', path: nextPath, oldVal: a[k] }); }
            else { jsonDeepDiff(a[k], b[k], nextPath, changes); }
        });
    } else if (typeA === 'array') {
        const maxLen = Math.max(a.length, b.length);
        for (let i = 0; i < maxLen; i++) {
            const nextPath = `${path||''}[${i}]`;
            if (i >= a.length) { changes.push({ type: 'added', path: nextPath, newVal: b[i] }); }
            else if (i >= b.length) { changes.push({ type: 'removed', path: nextPath, oldVal: a[i] }); }
            else { jsonDeepDiff(a[i], b[i], nextPath, changes); }
        }
    } else if (a !== b) {
        changes.push({ type: 'changed', path: path||'(root)', oldVal: a, newVal: b });
    }
}

function jsonTypeStr(v) {
    if (v === null) return 'null';
    if (Array.isArray(v)) return `array[${v.length}]`;
    return typeof v;
}
function jsonValStr(v) {
    if (v === null || v === undefined) return String(v);
    if (typeof v === 'object') return JSON.stringify(v).substring(0, 60) + (JSON.stringify(v).length > 60 ? '...' : '');
    return String(v).substring(0, 80);
}

function renderTextDiff(bodyA, bodyB, container) {
    const linesA = bodyA.split('\n');
    const linesB = bodyB.split('\n');
    let html = '';
    const maxLen = Math.max(linesA.length, linesB.length);
    let diffs = 0;
    for (let i = 0; i < maxLen; i++) {
        const la = linesA[i] ?? '';
        const lb = linesB[i] ?? '';
        if (la === lb) {
            html += `<div style="color:#636e72; padding:1px 4px; line-height:1.6;">&nbsp;&nbsp; ${escHtml(la)}</div>`;
        } else {
            diffs++;
            if (la) html += `<div style="background:#ffe4e4; color:#c0392b; padding:1px 4px; line-height:1.6;">- ${escHtml(la)}</div>`;
            if (lb) html += `<div style="background:#e4ffe4; color:#27ae60; padding:1px 4px; line-height:1.6;">+ ${escHtml(lb)}</div>`;
        }
    }
    container.innerHTML = `<div style="margin-bottom:8px; font-size:12px; color:#2d3436;">文本 Diff — 共 <b style="color:${diffs>0?'#d63031':'#00b894'}">${diffs}</b> 处差异</div>${html}`;
}
function fetchBody(item) {
    return new Promise(resolve => {
        if (item.content) { resolve(item.content); return; }
        chrome.runtime.sendMessage({ action: 'FETCH_BODY', requestId: item.id }, (res) => {
            if (!res || res.error) { resolve('(无法获取响应体)'); return; }
            try {
                const body = res.base64Encoded ? atob(res.body) : res.body;
                resolve(body);
            } catch (e) { resolve(res.body || ''); }
        });
    });
}
function escHtml(s) {
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

// ==========================================
// 📦 POST 缓存库核心函数
// ==========================================
function saveToPostCache(item) {
    if (!item || !item.url) return;
    const existIdx = postCacheStore.findIndex(p => p.id === item.id);
    const entry = existIdx >= 0 ? postCacheStore[existIdx] : {
        id: item.id,
        url: item.url,
        method: item.method || 'GET',
        time: item.time || new Date().toLocaleTimeString(),
        status: item.status,
        duration: item.duration,
        postData: item.postData || '',
        contentType: item.mimeType || '',
        responseHeaders: item.responseHeaders || {},
        requestHeaders: item.requestHeaders || {},
        responseBody: '',
        saved: Date.now()
    };
    if (existIdx >= 0) {
        // 更新状态字段
        if (item.status) entry.status = item.status;
        if (item.duration) entry.duration = item.duration;
    }
    if (existIdx < 0) {
        postCacheStore.unshift(entry);
        if (postCacheStore.length > MAX_POST_CACHE) postCacheStore.pop();
    }
    // 异步获取响应体
    if (!entry.responseBody) {
        chrome.runtime.sendMessage({ action: 'FETCH_BODY', requestId: item.id }, (res) => {
            if (res && res.body != null) {
                const idx = postCacheStore.findIndex(p => p.id === item.id);
                if (idx >= 0) {
                    try {
                        postCacheStore[idx].responseBody = res.base64Encoded ? atob(res.body) : res.body;
                    } catch(e) {
                        postCacheStore[idx].responseBody = res.body || '';
                    }
                    // 持久化（只存前100条节省空间）
                    chrome.storage.local.set({ postCacheStore: postCacheStore.slice(0, 100) });
                    if (isPanelOpen && panelRoot && panelRoot.getElementById('postcache-list')) {
                        renderPostCache();
                    }
                }
            }
        });
    }
    chrome.storage.local.set({ postCacheStore: postCacheStore.slice(0, 100) });
}

// ── 联合过滤核心函数 ──
function getFilteredPostCache() {
    const search = (panelRoot?.getElementById('postcache-search')?.value || '').toLowerCase().trim();
    const scope  = panelRoot?.getElementById('postcache-search-scope')?.value || 'url';

    return postCacheStore.filter(p => {
        // 1. Method 过滤（多选，ANY匹配）
        if (!pcFilter.methods.has('ALL') && !pcFilter.methods.has(p.method)) return false;

        // 2. 状态码段过滤
        if (pcFilter.status !== 'ALL') {
            const s = parseInt(p.status);
            if (pcFilter.status === '2xx' && !(s >= 200 && s < 300)) return false;
            if (pcFilter.status === '3xx' && !(s >= 300 && s < 400)) return false;
            if (pcFilter.status === '4xx' && !(s >= 400 && s < 500)) return false;
            if (pcFilter.status === '5xx' && !(s >= 500)) return false;
        }

        // 3. 响应体缓存状态
        const hasBody = !!(p.responseBody && p.responseBody.length > 0);
        if (pcFilter.body === 'HAS' && !hasBody) return false;
        if (pcFilter.body === 'NO'  && hasBody)  return false;

        // 4. 最小耗时
        if (pcFilter.minMs > 0 && (p.duration || 0) < pcFilter.minMs) return false;

        // 5. 关键字搜索（按范围）
        if (search) {
            const inUrl  = p.url?.toLowerCase().includes(search);
            const inReq  = p.postData?.toLowerCase().includes(search);
            const inResp = p.responseBody?.toLowerCase().includes(search);
            if (scope === 'url'       && !inUrl)  return false;
            if (scope === 'req_body'  && !inReq)  return false;
            if (scope === 'resp_body' && !inResp) return false;
            if (scope === 'all'       && !inUrl && !inReq && !inResp) return false;
        }

        return true;
    });
}

function renderPostCache() {
    if (!panelRoot) return;
    const list = panelRoot.getElementById('postcache-list');
    const countEl = panelRoot.getElementById('postcache-count');
    const filteredCountEl = panelRoot.getElementById('postcache-filtered-count');
    if (!list) return;

    const filtered = getFilteredPostCache();
    const total = postCacheStore.length;
    const isFiltered = filtered.length !== total;

    if (countEl) countEl.textContent = `${total} 条`;
    if (filteredCountEl) {
        filteredCountEl.textContent = `筛选: ${filtered.length} 条`;
        filteredCountEl.style.display = isFiltered ? 'inline-block' : 'none';
    }
    list.innerHTML = '';

    if (!filtered.length) {
        const keyword = panelRoot.getElementById('postcache-search')?.value;
        list.innerHTML = `<div style="color:#9ca3af;font-size:12px;text-align:center;padding:40px 20px;">
            ${total === 0 ? '暂无缓存记录<br><span style="font-size:11px;">浏览网页后会自动抓取所有请求</span>' : `<span style="font-size:22px;">🔍</span><br>没有匹配的记录<br><span style="font-size:11px;margin-top:6px;display:block;">共 ${total} 条，当前过滤条件无结果</span>`}
        </div>`;
        return;
    }

    filtered.forEach(entry => {
        const div = document.createElement('div');
        div.style.cssText = 'border-bottom:1px solid rgba(180,185,215,0.28); padding:10px 12px; background:rgba(255,255,255,0.6); cursor:pointer; transition:background 0.12s;';
        div.onmouseenter = () => div.style.background = 'rgba(91,110,245,0.05)';
        div.onmouseleave = () => div.style.background = 'rgba(255,255,255,0.6)';

        const methodBg = { POST:'#e17055', GET:'#00b894', PUT:'#a29bfe', DELETE:'#d63031', PATCH:'#f59e0b' }[entry.method] || '#636e72';
        const s = parseInt(entry.status);
        const statusBg = s >= 500 ? '#d63031' : s >= 400 ? '#f59e0b' : s >= 300 ? '#0984e3' : s >= 200 ? '#00b894' : '#636e72';
        const hasBody  = !!(entry.responseBody && entry.responseBody.length > 0);
        const bodySize = hasBody ? (entry.responseBody.length > 1024 ? (entry.responseBody.length/1024).toFixed(1)+'KB' : entry.responseBody.length+'B') : '';

        // 搜索关键字高亮
        const kw = (panelRoot.getElementById('postcache-search')?.value || '').trim();
        const scope = panelRoot.getElementById('postcache-search-scope')?.value || 'url';
        const hl = (str) => {
            if (!kw || !str) return escHtml(str || '');
            const re = new RegExp(kw.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'), 'gi');
            return escHtml(str).replace(re, m => `<mark style="background:#fef08a;color:#333;border-radius:2px;">${m}</mark>`);
        };
        const urlDisplay = (scope === 'url' || scope === 'all') ? hl(entry.url) : escHtml(entry.url);
        const reqDisplay = entry.postData ? ((scope === 'req_body' || scope === 'all') ? hl(entry.postData.substring(0,120)) : escHtml(entry.postData.substring(0,120))) : '';

        div.innerHTML = `
        <div style="display:flex; align-items:center; gap:5px; margin-bottom:5px; flex-wrap:wrap;">
            <span style="background:${methodBg}; color:#fff; font-size:9px; padding:2px 7px; border-radius:4px; font-weight:700; flex-shrink:0;">${entry.method}</span>
            <span style="background:${statusBg}; color:#fff; font-size:9px; padding:2px 6px; border-radius:4px; font-weight:700; flex-shrink:0;">${entry.status||'?'}</span>
            ${hasBody
                ? `<span style="background:#4f6ef7; color:#fff; font-size:9px; padding:1px 5px; border-radius:4px; flex-shrink:0;">✓ ${bodySize}</span>`
                : '<span style="background:#9ca3af; color:#fff; font-size:9px; padding:1px 5px; border-radius:4px; flex-shrink:0;">⏳</span>'}
            ${entry.duration ? `<span style="font-size:9px; color:${entry.duration>1000?'#d63031':entry.duration>500?'#f59e0b':'#9ca3af'}; flex-shrink:0;">⏱${entry.duration}ms</span>` : ''}
            <span style="font-family:monospace; font-size:11px; color:#333; flex:1; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; min-width:0;" title="${escHtml(entry.url)}">${urlDisplay}</span>
            <span style="color:#9ca3af; font-size:9px; flex-shrink:0;">${entry.time}</span>
        </div>
        ${entry.postData ? `<div style="font-size:10px; color:#6b7280; font-family:monospace; background:rgba(91,110,245,0.06); padding:4px 8px; border-radius:4px; margin-bottom:6px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; border-left:2px solid #5b6ef5;">📤 ${reqDisplay}${entry.postData.length>120?'…':''}</div>` : ''}
        <div style="display:flex; gap:5px; flex-wrap:wrap;">
            <button class="pc-view-btn btn-small" style="background:#5b6ef5; padding:2px 10px; font-size:10px;">👁️ 详情</button>
            <button class="pc-copy-body btn-small" style="background:#10b981; padding:2px 10px; font-size:10px;" ${!hasBody?'disabled':''}  >📋 响应体</button>
            <button class="pc-copy-req btn-small"  style="background:#f59e0b; padding:2px 10px; font-size:10px;" ${!entry.postData?'disabled':''}>📋 请求体</button>
            <button class="pc-del btn-small"        style="background:#ef4444; padding:2px 8px;  font-size:10px; margin-left:auto;">✕</button>
        </div>`;

        div.querySelector('.pc-view-btn').onclick  = (e) => { e.stopPropagation(); showPostCacheDetail(entry); };
        div.querySelector('.pc-copy-body').onclick = (e) => {
            e.stopPropagation();
            if (!hasBody) return;
            navigator.clipboard.writeText(entry.responseBody).then(() => { e.target.textContent='✅'; setTimeout(()=>e.target.textContent='📋 响应体',1500); });
        };
        div.querySelector('.pc-copy-req').onclick  = (e) => {
            e.stopPropagation();
            if (!entry.postData) return;
            navigator.clipboard.writeText(entry.postData).then(() => { e.target.textContent='✅'; setTimeout(()=>e.target.textContent='📋 请求体',1500); });
        };
        div.querySelector('.pc-del').onclick = (e) => {
            e.stopPropagation();
            postCacheStore = postCacheStore.filter(p => p.id !== entry.id);
            chrome.storage.local.set({ postCacheStore });
            renderPostCache();
        };
        div.onclick = () => showPostCacheDetail(entry);
        list.appendChild(div);
    });
}

function showPostCacheDetail(entry) {
    const modalViewer = panelRoot.getElementById('modal-viewer');
    const codeContent = panelRoot.getElementById('code-content');
    const aiPanel = panelRoot.getElementById('ai-analysis-panel');
    if (aiPanel) aiPanel.style.display = 'none';

    const methodColor = { POST:'#e17055', GET:'#00b894', PUT:'#a29bfe', DELETE:'#d63031', PATCH:'#f59e0b' }[entry.method] || '#636e72';
    const s = parseInt(entry.status);
    const statusColor = s >= 500 ? '#d63031' : s >= 400 ? '#f59e0b' : s >= 300 ? '#0984e3' : '#00b894';

    let postDisplay = entry.postData || '';
    let postLang = 'json';
    try { postDisplay = JSON.stringify(JSON.parse(postDisplay), null, 2); } catch(e) { postLang = 'text'; }

    let responseDisplay = entry.responseBody || '';
    let respLang = 'json';
    try { JSON.stringify(JSON.parse(responseDisplay)); responseDisplay = JSON.stringify(JSON.parse(responseDisplay), null, 2); }
    catch(e) { respLang = 'javascript'; }

    const highlightCode = (code, lang) => {
        if (window.Prism && window.Prism.languages[lang]) {
            try { return window.Prism.highlight(code, window.Prism.languages[lang], lang); } catch(e) {}
        }
        return escHtml(code);
    };

    const reqHeadersJson = JSON.stringify(entry.requestHeaders || {}, null, 2);
    const respHeadersJson = JSON.stringify(entry.responseHeaders || {}, null, 2);
    const bodySize = entry.responseBody ? (entry.responseBody.length > 1024 ? (entry.responseBody.length/1024).toFixed(1)+'KB' : entry.responseBody.length+'B') : '0';

    codeContent.innerHTML = `
    <div style="font-family:monospace; font-size:12px; background:#181c2e; color:#c9d1d9; height:100%; overflow-y:auto;">
        <!-- 请求概要 -->
        <div style="padding:14px 16px; border-bottom:1px solid #2d3250; background:#1a1e30;">
            <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap; margin-bottom:8px;">
                <span style="background:${methodColor}; color:#fff; padding:3px 12px; border-radius:6px; font-weight:700; font-size:12px;">${entry.method}</span>
                <span style="background:${statusColor}; color:#fff; padding:3px 10px; border-radius:6px; font-weight:700; font-size:12px;">${entry.status||'?'}</span>
                ${entry.duration ? `<span style="color:#9ca3af; font-size:11px;">⏱ ${entry.duration}ms</span>` : ''}
                <span style="color:#9ca3af; font-size:10px; margin-left:auto;">🕒 ${entry.time}</span>
            </div>
            <div style="color:#60a5fa; word-break:break-all; font-size:11px; line-height:1.5;">${escHtml(entry.url)}</div>
        </div>

        <!-- 标签页导航 -->
        <div style="display:flex; background:#12151f; border-bottom:1px solid #2d3250;" id="pcd-tabs">
            ${entry.postData ? '<button class="pcd-tab" data-tab="req" style="flex:1;padding:8px;border:none;border-bottom:2px solid #5b6ef5;background:transparent;color:#fff;cursor:pointer;font-size:11px;font-weight:bold;">📤 请求体</button>' : ''}
            ${entry.responseBody ? `<button class="pcd-tab" data-tab="resp" style="flex:1;padding:8px;border:none;${entry.postData?'border-bottom:none':'border-bottom:2px solid #5b6ef5'};background:transparent;color:${entry.postData?'#9ca3af':'#fff'};cursor:pointer;font-size:11px;font-weight:bold;">📥 响应体 <span style="font-size:9px;background:#4f6ef7;color:#fff;padding:1px 5px;border-radius:8px;">${bodySize}</span></button>` : ''}
            <button class="pcd-tab" data-tab="headers" style="flex:1;padding:8px;border:none;border-bottom:none;background:transparent;color:#9ca3af;cursor:pointer;font-size:11px;">🗂 Headers</button>
        </div>

        <!-- 请求体 -->
        ${entry.postData ? `
        <div id="pcd-req" class="pcd-content" style="padding:0;">
            <pre class="language-${postLang}" style="margin:0;padding:14px;font-size:12px;line-height:1.6;white-space:pre-wrap;word-wrap:break-word;background:transparent;"><code class="language-${postLang}">${highlightCode(postDisplay, postLang)}</code></pre>
        </div>` : ''}

        <!-- 响应体 -->
        ${entry.responseBody ? `
        <div id="pcd-resp" class="pcd-content" style="padding:0; display:${entry.postData ? 'none' : 'block'};">
            <pre class="language-${respLang}" style="margin:0;padding:14px;font-size:12px;line-height:1.6;white-space:pre-wrap;word-wrap:break-word;background:transparent;"><code class="language-${respLang}">${highlightCode(responseDisplay, respLang)}</code></pre>
        </div>` : `
        <div id="pcd-resp" class="pcd-content" style="padding:20px; display:${entry.postData?'none':'block'};">
            <div style="color:#f59e0b;font-size:12px;">⏳ 响应体尚未缓存</div>
            <div style="color:#9ca3af;font-size:11px;margin-top:6px;">请等待请求完成后重新打开，或点击抓包列表中该条目重新加载</div>
        </div>`}

        <!-- Headers -->
        <div id="pcd-headers" class="pcd-content" style="padding:14px; display:none;">
            <div style="color:#61afef;font-weight:bold;margin-bottom:8px;font-size:12px;">Request Headers</div>
            <pre class="language-json" style="margin:0 0 14px;padding:10px;border-radius:6px;font-size:11px;line-height:1.5;white-space:pre-wrap;word-break:break-all;background:#0d1117;"><code class="language-json">${highlightCode(reqHeadersJson,'json')}</code></pre>
            <div style="color:#61afef;font-weight:bold;margin-bottom:8px;font-size:12px;">Response Headers</div>
            <pre class="language-json" style="margin:0;padding:10px;border-radius:6px;font-size:11px;line-height:1.5;white-space:pre-wrap;word-break:break-all;background:#0d1117;"><code class="language-json">${highlightCode(respHeadersJson,'json')}</code></pre>
        </div>
    </div>`;

    // Tab 切换
    codeContent.querySelectorAll('.pcd-tab').forEach(btn => {
        btn.onclick = (e) => {
            e.stopPropagation();
            codeContent.querySelectorAll('.pcd-tab').forEach(b => {
                b.style.borderBottom = 'none'; b.style.color = '#9ca3af'; b.style.fontWeight = 'normal';
            });
            btn.style.borderBottom = '2px solid #5b6ef5'; btn.style.color = '#fff'; btn.style.fontWeight = 'bold';
            codeContent.querySelectorAll('.pcd-content').forEach(c => c.style.display = 'none');
            const target = codeContent.getElementById ? codeContent.getElementById(`pcd-${btn.dataset.tab}`) : codeContent.querySelector(`#pcd-${btn.dataset.tab}`);
            if (target) target.style.display = 'block';
        };
    });

    modalViewer.style.display = 'block';
}

// ==========================================
// 🔭 函数追踪渲染
// ==========================================
function renderFuncHookedList() {
    if (!panelRoot) return;
    const list = panelRoot.getElementById('functrace-hooked-list');
    if (!list) return;
    list.innerHTML = '';
    funcHookedList.forEach(label => {
        const tag = document.createElement('span');
        tag.style.cssText = 'background:#eff1fe; color:#5b6ef5; border:1px solid #c7d0fb; border-radius:10px; padding:2px 8px; font-size:10px; display:inline-flex; align-items:center; gap:4px;';
        tag.innerHTML = `🔭 ${escHtml(label)} <span style="cursor:pointer; color:#ef4444;" class="rm-hook">✕</span>`;
        tag.querySelector('.rm-hook').onclick = (e) => {
            e.stopPropagation();
            funcHookedList = funcHookedList.filter(l => l !== label);
            renderFuncHookedList();
        };
        list.appendChild(tag);
    });
}

function renderFuncTrace() {
    if (!panelRoot) return;
    const list = panelRoot.getElementById('functrace-list');
    const countEl = panelRoot.getElementById('functrace-count');
    if (!list) return;
    if (countEl) countEl.textContent = `${funcTraceStore.length} 次`;
    list.innerHTML = '';
    if (!funcTraceStore.length) {
        list.innerHTML = '<div style="color:#9ca3af;text-align:center;padding:30px;font-size:12px;">暂无追踪记录<br><span style="font-size:11px;">先挂钩目标函数，再浏览页面</span></div>';
        return;
    }
    funcTraceStore.forEach(entry => {
        const div = document.createElement('div');
        div.style.cssText = 'border-bottom:1px solid rgba(180,185,215,0.25); padding:8px 12px; background:rgba(255,255,255,0.55); cursor:pointer; transition:background 0.1s;';
        div.onmouseenter = () => div.style.background = 'rgba(91,110,245,0.05)';
        div.onmouseleave = () => div.style.background = 'rgba(255,255,255,0.55)';

        const hasErr = !!entry.error;
        const isAsync = entry.isAsync;
        const durColor = entry.durationMs > 100 ? '#d63031' : entry.durationMs > 20 ? '#f59e0b' : '#10b981';

        div.innerHTML = `
        <div style="display:flex; align-items:center; gap:6px; margin-bottom:5px; flex-wrap:wrap;">
            <span style="background:${hasErr?'#ef4444':'#5b6ef5'}; color:#fff; font-size:9px; padding:1px 7px; border-radius:4px; font-weight:700; flex-shrink:0;">${hasErr?'ERROR':isAsync?'ASYNC':'SYNC'}</span>
            <span style="font-weight:700; color:#1a1d2e; font-size:11px; flex:1; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="${escHtml(entry.label)}">${escHtml(entry.label)}</span>
            <span style="font-size:9px; color:${durColor}; flex-shrink:0;">⏱${entry.durationMs}ms</span>
            <span style="font-size:9px; color:#9ca3af; flex-shrink:0;">${entry.time}</span>
        </div>
        <div style="margin-bottom:4px;">
            <span style="font-size:10px; color:#9ca3af;">入参(${entry.args.length}):</span>
            ${entry.args.map((a,i)=>`<span style="font-family:monospace;font-size:10px;background:rgba(91,110,245,0.08);padding:1px 5px;border-radius:3px;margin-left:3px;color:#2d3436;">[${i}] ${escHtml(String(a).substring(0,80))}${String(a).length>80?'…':''}</span>`).join('')}
        </div>
        ${entry.returnVal !== undefined ? `<div style="font-size:10px;"><span style="color:#9ca3af;">返回:</span> <span style="font-family:monospace;color:#10b981;background:rgba(16,185,129,0.07);padding:1px 5px;border-radius:3px;">${escHtml(String(entry.returnVal).substring(0,100))}${String(entry.returnVal).length>100?'…':''}</span></div>` : ''}
        ${entry.error ? `<div style="font-size:10px;color:#ef4444;">❌ ${escHtml(entry.error)}</div>` : ''}
        <details style="margin-top:4px;">
            <summary style="font-size:10px;color:#9ca3af;cursor:pointer;">📋 调用链 (${entry.stack.length} 帧)</summary>
            <div style="font-family:monospace;font-size:10px;color:#6b7280;background:#f8fafc;padding:5px 8px;border-radius:4px;margin-top:3px;word-break:break-all;line-height:1.6;">
                ${entry.stack.map((f,i)=>`<div>${i+1}. ${escHtml(f)}</div>`).join('')}
            </div>
        </details>`;

        // 点击展开完整入参/返回值
        div.onclick = () => {
            const modalViewer = panelRoot.getElementById('modal-viewer');
            const codeContent = panelRoot.getElementById('code-content');
            const aiPanel = panelRoot.getElementById('ai-analysis-panel');
            if (aiPanel) aiPanel.style.display = 'none';
            const detail = {
                label: entry.label, time: entry.time, durationMs: entry.durationMs,
                args: entry.args, returnVal: entry.returnVal, error: entry.error,
                stack: entry.stack
            };
            const hl = (s) => {
                if (!s) return '';
                try { return window.Prism && window.Prism.languages.json
                    ? window.Prism.highlight(JSON.stringify(JSON.parse(s),null,2), window.Prism.languages.json,'json')
                    : escHtml(s);
                } catch(e) { return escHtml(s); }
            };
            codeContent.innerHTML = `
            <div style="font-family:monospace;font-size:12px;background:#181c2e;color:#c9d1d9;padding:16px;overflow:auto;height:100%;">
                <div style="color:#8be9fd;font-weight:bold;font-size:14px;margin-bottom:12px;">🔭 ${escHtml(entry.label)}</div>
                <div style="display:flex;gap:12px;margin-bottom:14px;flex-wrap:wrap;">
                    <span style="background:${hasErr?'#ef4444':'#5b6ef5'};color:#fff;padding:2px 10px;border-radius:6px;font-size:11px;">${hasErr?'ERROR':isAsync?'ASYNC':'SYNC'}</span>
                    <span style="color:#9ca3af;font-size:11px;">⏱ ${entry.durationMs}ms</span>
                    <span style="color:#9ca3af;font-size:11px;">🕒 ${entry.time}</span>
                </div>
                <div style="margin-bottom:14px;">
                    <div style="color:#61afef;font-weight:bold;margin-bottom:6px;">📥 入参 (${entry.args.length}个)</div>
                    ${entry.args.map((a,i) => `
                    <div style="margin-bottom:6px;">
                        <span style="color:#9ca3af;font-size:10px;">arg[${i}]</span>
                        <pre class="language-json" style="margin:3px 0 0;padding:8px;border-radius:4px;font-size:11px;background:#0d1117;white-space:pre-wrap;word-break:break-all;">${hl(a)}</pre>
                    </div>`).join('')}
                </div>
                ${entry.returnVal !== undefined ? `
                <div style="margin-bottom:14px;">
                    <div style="color:#50fa7b;font-weight:bold;margin-bottom:6px;">📤 返回值</div>
                    <pre class="language-json" style="margin:0;padding:8px;border-radius:4px;font-size:11px;background:#0d1117;white-space:pre-wrap;word-break:break-all;">${hl(entry.returnVal)}</pre>
                </div>` : ''}
                ${entry.error ? `<div style="color:#ef4444;margin-bottom:14px;">❌ 异常: ${escHtml(entry.error)}</div>` : ''}
                <div>
                    <div style="color:#61afef;font-weight:bold;margin-bottom:6px;">📋 完整调用链</div>
                    ${entry.stack.map((f,i) => `<div style="padding:3px 0;border-bottom:1px solid #1e2230;color:#9ca3af;font-size:10px;">${i+1}. ${escHtml(f)}</div>`).join('')}
                </div>
            </div>`;
            modalViewer.style.display = 'block';
        };
        list.appendChild(div);
    });
}

// ==========================================
// 🔓 解密猎手渲染
// ==========================================
function renderDecryptList() {
    if (!panelRoot) return;
    const list = panelRoot.getElementById('decrypt-list');
    const countEl = panelRoot.getElementById('decrypt-count');
    if (!list) return;
    if (countEl) countEl.textContent = `${decryptStore.length} 条`;
    list.innerHTML = '';
    if (!decryptStore.length) {
        list.innerHTML = '<div style="color:#9ca3af;text-align:center;padding:30px;font-size:12px;">等待解密操作...<br><span style="font-size:11px;">会自动拦截 CryptoJS / WebCrypto / atob</span></div>';
        return;
    }
    const algoColors = { 'AES':'#8b5cf6','DES':'#e17055','atob':'#0984e3','WebCrypto':'#d63031' };
    decryptStore.forEach(entry => {
        const div = document.createElement('div');
        div.style.cssText = 'border-bottom:1px solid rgba(180,185,215,0.28); padding:10px 12px; background:rgba(255,255,255,0.6); cursor:pointer;';
        div.onmouseenter = () => div.style.background = 'rgba(91,110,245,0.05)';
        div.onmouseleave = () => div.style.background = 'rgba(255,255,255,0.6)';
        const algoKey = Object.keys(algoColors).find(k => entry.algo.includes(k)) || 'AES';
        const algoBg = algoColors[algoKey] || '#636e72';
        const hasPlain = entry.plaintext && entry.plaintext.length > 0;

        div.innerHTML = `
        <div style="display:flex; align-items:center; gap:6px; margin-bottom:6px; flex-wrap:wrap;">
            <span style="background:${algoBg}; color:#fff; font-size:9px; padding:2px 8px; border-radius:4px; font-weight:700;">${escHtml(entry.algo)}</span>
            ${hasPlain ? '<span style="background:#10b981;color:#fff;font-size:9px;padding:1px 6px;border-radius:4px;">✓ 已还原明文</span>' : '<span style="background:#9ca3af;color:#fff;font-size:9px;padding:1px 6px;border-radius:4px;">无明文</span>'}
            <span style="color:#9ca3af;font-size:9px;margin-left:auto;">${entry.time}</span>
        </div>
        <div style="margin-bottom:5px;">
            <span style="font-size:10px;color:#9ca3af;">密钥:</span>
            <span style="font-family:monospace;font-size:10px;color:#f59e0b;background:rgba(245,158,11,0.08);padding:1px 6px;border-radius:3px;word-break:break-all;">${escHtml(String(entry.key||'').substring(0,80))}${String(entry.key||'').length>80?'…':''}</span>
            <button class="dc-copy-key btn-small" style="background:#f59e0b;padding:1px 6px;font-size:9px;" data-val="${escHtml(entry.key||'')}">复制</button>
        </div>
        <div style="margin-bottom:5px;">
            <span style="font-size:10px;color:#9ca3af;">密文:</span>
            <span style="font-family:monospace;font-size:10px;color:#9ca3af;word-break:break-all;">${escHtml(String(entry.ciphertext||'').substring(0,100))}${String(entry.ciphertext||'').length>100?'…':''}</span>
        </div>
        ${hasPlain ? `
        <div style="background:rgba(16,185,129,0.07);border:1px solid rgba(16,185,129,0.2);border-left:3px solid #10b981;padding:5px 8px;border-radius:4px;margin-bottom:5px;">
            <span style="font-size:10px;color:#10b981;font-weight:bold;">🔓 明文:</span>
            <span style="font-family:monospace;font-size:11px;color:#1a1d2e;word-break:break-all;margin-left:4px;">${escHtml(entry.plaintext.substring(0,200))}${entry.plaintext.length>200?'…':''}</span>
            <button class="dc-copy-plain btn-small" style="background:#10b981;padding:1px 6px;font-size:9px;margin-left:4px;" data-val="${escHtml(entry.plaintext)}">复制</button>
        </div>` : ''}
        <details style="margin-top:4px;">
            <summary style="font-size:10px;color:#9ca3af;cursor:pointer;">📋 调用栈</summary>
            <div style="font-family:monospace;font-size:10px;color:#6b7280;background:#f8fafc;padding:4px 8px;border-radius:3px;margin-top:3px;word-break:break-all;line-height:1.5;">
                ${(entry.stack||[]).map((f,i) => `<div>${i+1}. ${escHtml(f)}</div>`).join('') || '(不可用)'}
            </div>
        </details>`;

        div.querySelector('.dc-copy-key').onclick = (e) => {
            e.stopPropagation();
            navigator.clipboard.writeText(e.target.dataset.val).then(() => { e.target.textContent='✅'; setTimeout(()=>e.target.textContent='复制',1500); });
        };
        if (hasPlain) {
            div.querySelector('.dc-copy-plain').onclick = (e) => {
                e.stopPropagation();
                navigator.clipboard.writeText(e.target.dataset.val).then(() => { e.target.textContent='✅'; setTimeout(()=>e.target.textContent='复制',1500); });
            };
        }
        list.appendChild(div);
    });
}

// ==========================================
// 🧪 参数加密检测渲染
// ==========================================
function renderParamCryptoList() {
    if (!panelRoot) return;
    const list = panelRoot.getElementById('paramcrypto-list');
    const countEl = panelRoot.getElementById('paramcrypto-count');
    if (!list) return;

    const search = (panelRoot.getElementById('paramcrypto-search')?.value || '').toLowerCase();
    const typeFilter = paramCryptoTypeFilter;

    const typeMap = { JWT:'JWT', Base64:'Base64', AES:'AES_b64', Hex:'HexLong', URLEncoded:'URLEncoded' };
    const filtered = paramCryptoStore.filter(p => {
        if (typeFilter !== 'ALL') {
            const matchType = typeMap[typeFilter] || typeFilter;
            const ok = p.detected.some(d => d.includes(matchType) || d.includes(typeFilter));
            if (!ok) return false;
        }
        if (search && !p.url?.toLowerCase().includes(search) && !p.key?.toLowerCase().includes(search)) return false;
        return true;
    });

    if (countEl) countEl.textContent = `${paramCryptoStore.length} 条`;
    list.innerHTML = '';

    if (!filtered.length) {
        list.innerHTML = `<div style="color:#9ca3af;text-align:center;padding:30px;font-size:12px;">${paramCryptoStore.length===0?'等待请求...<br><span style="font-size:11px;">浏览页面后自动扫描所有 GET/POST 参数</span>':'当前过滤条件无结果'}</div>`;
        return;
    }

    const methodColor = { POST:'#e17055', GET:'#00b894', PUT:'#a29bfe', DELETE:'#d63031', PATCH:'#f59e0b' };
    const typeColors = { JWT:'#8b5cf6', Base64:'#0984e3', 'Hex(MD5?)':'#e17055', 'Hex(SHA1?)':'#e17055', 'Hex(SHA256?)':'#d63031', HexLong:'#e17055', URLEncoded:'#00b894', AES_b64:'#d63031' };

    filtered.forEach(entry => {
        const div = document.createElement('div');
        div.style.cssText = 'border-bottom:1px solid rgba(180,185,215,0.28); padding:9px 12px; background:rgba(255,255,255,0.6); cursor:pointer;';
        div.onmouseenter = () => div.style.background = 'rgba(91,110,245,0.05)';
        div.onmouseleave = () => div.style.background = 'rgba(255,255,255,0.6)';
        const hasDecoded = entry.decoded && entry.decoded.length > 0;

        div.innerHTML = `
        <div style="display:flex; align-items:center; gap:5px; margin-bottom:5px; flex-wrap:wrap;">
            <span style="background:${methodColor[entry.method]||'#636e72'}; color:#fff; font-size:9px; padding:1px 7px; border-radius:4px; font-weight:700;">${entry.method}</span>
            ${entry.detected.map(d => `<span style="background:${typeColors[d]||'#636e72'};color:#fff;font-size:9px;padding:1px 6px;border-radius:4px;">${d}</span>`).join('')}
            ${hasDecoded ? '<span style="background:#10b981;color:#fff;font-size:9px;padding:1px 6px;border-radius:4px;">✓ 可解码</span>' : ''}
            <span style="font-family:monospace;font-size:11px;color:#1a1d2e;font-weight:600;margin-left:2px;">${escHtml(entry.key)}</span>
            <span style="color:#9ca3af;font-size:9px;margin-left:auto;">${entry.time}</span>
        </div>
        <div style="font-size:10px;color:#9ca3af;font-family:monospace;margin-bottom:4px;word-break:break-all;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="${escHtml(entry.url)}">📍 ${escHtml(entry.url.substring(0,100))}${entry.url.length>100?'…':''}</div>
        <div style="font-family:monospace;font-size:10px;background:rgba(91,110,245,0.06);padding:4px 8px;border-radius:4px;margin-bottom:4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;border-left:2px solid #5b6ef5;" title="${escHtml(entry.value)}">
            🔒 ${escHtml(entry.value)}
        </div>
        ${hasDecoded ? entry.decoded.map(d => `
        <div style="background:rgba(16,185,129,0.07);border-left:2px solid #10b981;padding:4px 8px;border-radius:3px;margin-bottom:3px;display:flex;align-items:center;gap:6px;flex-wrap:wrap;">
            <span style="font-size:9px;background:#10b981;color:#fff;padding:1px 5px;border-radius:3px;">${escHtml(d.method)}</span>
            <span style="font-family:monospace;font-size:10px;color:#1a1d2e;word-break:break-all;flex:1;">${escHtml(d.result.substring(0,120))}${d.result.length>120?'…':''}</span>
            <button class="pcd-copy-decoded btn-small" style="background:#10b981;padding:1px 6px;font-size:9px;flex-shrink:0;" data-val="${escHtml(d.result)}">复制</button>
        </div>`).join('') : ''}`;

        div.querySelectorAll('.pcd-copy-decoded').forEach(btn => {
            btn.onclick = (e) => {
                e.stopPropagation();
                navigator.clipboard.writeText(e.target.dataset.val).then(() => { e.target.textContent='✅'; setTimeout(()=>e.target.textContent='复制',1500); });
            };
        });
        div.onclick = () => {
            const modalViewer = panelRoot.getElementById('modal-viewer');
            const codeContent = panelRoot.getElementById('code-content');
            if (panelRoot.getElementById('ai-analysis-panel')) panelRoot.getElementById('ai-analysis-panel').style.display='none';
            const hl = s => { try { return window.Prism?.languages?.json ? window.Prism.highlight(JSON.stringify(JSON.parse(s),null,2),window.Prism.languages.json,'json') : escHtml(s); } catch(e){ return escHtml(s); }};
            codeContent.innerHTML = `
            <div style="font-family:monospace;font-size:12px;background:#181c2e;color:#c9d1d9;padding:16px;overflow:auto;height:100%;">
                <div style="color:#8be9fd;font-size:13px;font-weight:bold;margin-bottom:12px;">🧪 参数加密详情</div>
                <div style="display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap;">
                    <span style="background:${methodColor[entry.method]||'#636e72'};color:#fff;padding:2px 10px;border-radius:6px;font-size:11px;">${entry.method}</span>
                    ${entry.detected.map(d=>`<span style="background:${typeColors[d]||'#636e72'};color:#fff;padding:2px 8px;border-radius:6px;font-size:11px;">${d}</span>`).join('')}
                    <span style="color:#9ca3af;font-size:11px;">🕒 ${entry.time}</span>
                </div>
                <div style="color:#60a5fa;word-break:break-all;margin-bottom:12px;font-size:11px;">${escHtml(entry.url)}</div>
                <div style="margin-bottom:12px;"><div style="color:#9ca3af;margin-bottom:4px;font-size:11px;">参数名</div><span style="color:#f1fa8c;font-size:13px;font-weight:bold;">${escHtml(entry.key)}</span></div>
                <div style="margin-bottom:14px;"><div style="color:#9ca3af;margin-bottom:4px;font-size:11px;">🔒 加密值</div><pre style="background:#0d1117;padding:10px;border-radius:5px;margin:0;white-space:pre-wrap;word-break:break-all;font-size:11px;">${escHtml(entry.value)}</pre></div>
                ${hasDecoded ? `<div style="margin-bottom:12px;"><div style="color:#50fa7b;font-weight:bold;margin-bottom:8px;font-size:12px;">🔓 解码结果</div>
                    ${entry.decoded.map(d => `<div style="background:#0d1117;border-left:3px solid #10b981;padding:8px;border-radius:4px;margin-bottom:8px;"><div style="color:#10b981;font-size:10px;margin-bottom:4px;">[${escHtml(d.method)}]</div><pre style="margin:0;white-space:pre-wrap;word-break:break-all;font-size:11px;color:#f8f8f2;">${hl(d.result)}</pre></div>`).join('')}
                </div>` : '<div style="color:#9ca3af;font-size:11px;padding:8px 0;">⚠️ 未能自动解码（可能需要密钥）</div>'}
            </div>`;
            modalViewer.style.display = 'block';
        };
        list.appendChild(div);
    });
}

// ── 本地文件替换列表渲染 ──
function renderLocalFileRules() {
    const list = panelRoot.getElementById('local-file-list');
    list.innerHTML = '';
    localFileRules.forEach((rule, idx) => {
        const div = document.createElement('div');
        div.style.cssText = 'background:#f9f9f9; border:1px solid #eee; padding:8px 10px; margin-bottom:6px; border-radius:4px; font-size:11px; display:flex; justify-content:space-between; align-items:center;';
        div.innerHTML = `<div><strong style="color:#6c5ce7;">${rule.urlKeyword}</strong> → <span style="color:#636e72;">${rule.fileName}</span></div>
            <button class="btn-small del-local" style="background:#e74c3c;">删除</button>`;
        div.querySelector('.del-local').onclick = (e) => {
            e.stopPropagation();
            localFileRules.splice(idx, 1);
            chrome.storage.local.set({ localFileRules });
            window.postMessage({ type: 'UPDATE_LOCAL_FILE_RULES', rules: localFileRules }, '*');
            renderLocalFileRules();
        };
        list.appendChild(div);
    });
}

function renderMockRules() {
const list = panelRoot.getElementById('mock-list');
list.innerHTML = '';
mockRules.forEach((rule, index) => {
const div = document.createElement('div');
div.style.cssText = 'background:#f9f9f9; border:1px solid #eee; padding:10px; margin-bottom:8px; border-radius:4px; font-size:11px; display:flex; justify-content:space-between; align-items:center;';
div.innerHTML = `<div style="flex:1; overflow:hidden;"> <strong style="color:#d35400; font-size:12px;">拦截规则: ${rule.urlKeyword}</strong> <div style="color:#666; max-height:40px; overflow:hidden; text-overflow:ellipsis; margin-top:4px; font-family:monospace;">${rule.responseBody}</div> </div> <button class="btn-small del-rule" style="background:#e74c3c; margin-left:10px;">删除</button>`;
div.querySelector('.del-rule').onclick = (e) => {
e.stopPropagation();
mockRules.splice(index, 1);
chrome.storage.local.set({mockRules});
syncRulesToPage();
renderMockRules();
};
list.appendChild(div);
});
}
function syntaxHighlight(json) {
if (typeof json !== 'string') {
json = JSON.stringify(json, undefined, 4);
}
json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
return json.replace(/("(\u[a-zA-Z0-9]{4}|\[^u]|[^\"])"(\s:)?|\b(true|false|null)\b|-?\d+(?:.\d*)?(?:[eE][+-]?\d+)?)/g, function (match) {
var cls = 'number';
if (/^"/.test(match)) {
if (/:$/.test(match)) {
cls = 'key';
} else {
cls = 'string';
}
} else if (/true|false/.test(match)) {
cls = 'boolean';
} else if (/null/.test(match)) {
cls = 'null';
}
return '<span class="' + cls + '">' + match + '</span>';
});
}

// ── Prism 语法高亮辅助函数 ──
function prismHighlight(code, lang) {
    if (window.Prism && window.Prism.languages[lang]) {
        try {
            return window.Prism.highlight(code, window.Prism.languages[lang], lang);
        } catch(e) {}
    }
    // fallback: 转义 HTML
    return code.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

function detectLang(content, type) {
    if (type === 'XHR' || (content.trim().startsWith('{') || content.trim().startsWith('['))) return 'json';
    if (type === 'SCRIPT' || content.includes('function ') || content.includes('=>')) return 'javascript';
    if (type === 'CSS' || content.includes('{') && content.includes(':')) return 'css';
    if (content.includes('<!DOCTYPE') || content.includes('<html')) return 'html';
    return 'javascript';
}

function renderContentInModal(content, type, isBase64) {
const codeContent = panelRoot.getElementById('code-content');
const highlightEnabled = panelRoot.getElementById('highlight-toggle')?.checked !== false;

if (type === 'IMAGE' && isBase64) {
codeContent.innerHTML = `<div style="text-align:center; padding:20px;"><img src="data:image/png;base64,${content}" style="max-width:100%; box-shadow:0 0 10px rgba(0,0,0,0.5);"></div>`;
return;
}
if (isBase64) {
try {
content = decodeURIComponent(escape(window.atob(content)));
} catch (e) {}
}

// M3U8 特殊渲染
if (type === 'MEDIA-M3U8') {
    const html = content.split('\n').map(line => {
        if(line.includes('#EXTINF') && line.includes('0.')) return `<span class="line-filtered" style="color:#e06c75; text-decoration:line-through;">${escHtml(line)}  &lt;-- [Ad Blocked]</span>`;
        if (line.startsWith('#')) return `<span style="color:#c678dd">${escHtml(line)}</span>`;
        return `<span style="color:#98c379">${escHtml(line)}</span>`;
    }).join('\n');
    codeContent.innerHTML = `<pre style="margin:0;padding:14px;font-family:'SF Mono',Consolas,monospace;font-size:12px;line-height:1.6;white-space:pre-wrap;word-wrap:break-word;">${html}</pre>`;
    return;
}

// JSON 美化 + 高亮
if (type === 'XHR' || (content.trim().startsWith('{')) || content.trim().startsWith('[')) {
try {
    const obj = JSON.parse(content);
    const pretty = JSON.stringify(obj, null, 2);
    if (highlightEnabled) {
        const highlighted = prismHighlight(pretty, 'json');
        codeContent.innerHTML = `<pre class="language-json" style="margin:0;padding:14px;font-family:'SF Mono',Consolas,monospace;font-size:12.5px;line-height:1.6;white-space:pre-wrap;word-wrap:break-word;background:#1e1e2e;"><code class="language-json">${highlighted}</code></pre>`;
    } else {
        codeContent.innerHTML = `<pre style="margin:0;padding:14px;font-family:'SF Mono',Consolas,monospace;font-size:12.5px;line-height:1.6;white-space:pre-wrap;word-wrap:break-word;color:#c9d1d9;">${syntaxHighlight(obj)}</pre>`;
    }
    return;
} catch (e) {}
}

// 其他代码高亮
const lang = detectLang(content, type);
if (highlightEnabled && window.Prism) {
    const highlighted = prismHighlight(content, lang);
    codeContent.innerHTML = `<pre class="language-${lang}" style="margin:0;padding:14px;font-family:'SF Mono',Consolas,monospace;font-size:12.5px;line-height:1.6;white-space:pre-wrap;word-wrap:break-word;background:#1e1e2e;"><code class="language-${lang}">${highlighted}</code></pre>`;
} else {
    const escaped = content.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    codeContent.innerHTML = `<pre style="margin:0;padding:14px;font-family:'SF Mono',Consolas,monospace;font-size:12.5px;line-height:1.6;white-space:pre-wrap;word-wrap:break-word;color:#c9d1d9;">${escaped}</pre>`;
}
}
// 适配 PC 与 手机的双端拖拽函数
function makeDraggable(element, handle) {
    let x1 = 0, y1 = 0;
    let dragging = false;

    const dragMove = (e) => {
        if (!dragging) return;
        if (e.cancelable) e.preventDefault();
        const evt = e.touches ? e.touches[0] : e;
        const dx = x1 - evt.clientX;
        const dy = y1 - evt.clientY;
        x1 = evt.clientX;
        y1 = evt.clientY;
        element.style.top    = (element.offsetTop  - dy) + 'px';
        element.style.left   = (element.offsetLeft - dx) + 'px';
        element.style.right  = 'auto';
        element.style.bottom = 'auto';
    };

    const dragEnd = () => {
        dragging = false;
        window.removeEventListener('mousemove', dragMove, true);
        window.removeEventListener('mouseup',   dragEnd,  true);
        window.removeEventListener('touchmove', dragMove, true);
        window.removeEventListener('touchend',  dragEnd,  true);
    };

    handle.addEventListener('mousedown', (e) => {
        e.preventDefault();
        dragging = true;
        x1 = e.clientX;
        y1 = e.clientY;
        window.addEventListener('mousemove', dragMove, true);
        window.addEventListener('mouseup',   dragEnd,  true);
    });

    handle.addEventListener('touchstart', (e) => {
        dragging = true;
        x1 = e.touches[0].clientX;
        y1 = e.touches[0].clientY;
        window.addEventListener('touchmove', dragMove, { capture: true, passive: false });
        window.addEventListener('touchend',  dragEnd,  true);
    }, { passive: true });
}
function processLog(item) {
if (!panelRoot) return;
const logList = panelRoot.getElementById('log-list');
logsMap.set(item.id, item);

// 如已存在则更新
const existing = logList.querySelector(`[data-id="${item.id}"]`);
if (existing) {
    if (item.status && item.status !== 'Pending') existing.dataset.status = item.status;
    if (item.duration) {
        let durEl = existing.querySelector('.duration-badge');
        if (!durEl) { durEl = document.createElement('span'); durEl.className = 'duration-badge'; durEl.style.cssText = 'font-size:9px; color:#888; margin-left:4px;'; existing.querySelector('.btn-group')?.before(durEl); }
        const color = item.duration > 1000 ? '#d63031' : item.duration > 500 ? '#e17055' : '#636e72';
        durEl.style.color = color; durEl.textContent = `${item.duration}ms`;
    }
    return;
}

const div = document.createElement('div');
div.className = 'log-item';
div.dataset.type = item.type;
div.dataset.id = item.id;
div.dataset.url = item.url.toLowerCase();
div.dataset.starred = starredSet.has(item.id) ? '1' : '0';
const isMedia = item.type.includes('MEDIA');
const colorMap = {
'MEDIA-M3U8': '#8e24aa', 'MEDIA': '#8e24aa', 'SCRIPT': '#e67e22',
'CSS': '#2980b9', 'XHR': '#16a085', 'IMAGE': '#27ae60', 'PENDING': '#f39c12'
};
const typeColor = colorMap[item.type] || '#666';
const methodColor = item.method === 'POST' ? '#e17055' : '#00b894';
const starIcon = starredSet.has(item.id) ? '⭐' : '☆';
const gqlBadge = item.isGraphQL ? `<span style="font-size:9px; background:#e040fb; color:white; padding:1px 4px; border-radius:3px; margin-right:4px;">GQL</span>` : '';
let htmlContent = `<div style="display:flex; flex-direction:column; width:100%;">
 <div style="display:flex; align-items:center; gap:6px;">
  <button class="mini-btn btn-star" style="background:none; border:none; font-size:13px; cursor:pointer; padding:0 2px;" title="收藏">${starIcon}</button>
  <span class="badge" style="background:${methodColor}; color:#fff;">${item.method || 'GET'}</span>
  ${gqlBadge}<span class="badge" style="color:${typeColor}; background:#eee; border:1px solid ${typeColor};">${item.type}</span>
  <span class="url" title="${item.url}" style="font-family:monospace; color:#333; flex:1; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${item.url}</span>
  <div class="btn-group" style="display:flex; gap:4px; flex-shrink:0;">
   <button class="mini-btn btn-diff-a" title="标为 Diff A" style="font-size:10px; background:#74b9ff; color:#fff; border:none; border-radius:3px; padding:2px 5px; cursor:pointer;">A</button>
   <button class="mini-btn btn-diff-b" title="标为 Diff B" style="font-size:10px; background:#fd79a8; color:#fff; border:none; border-radius:3px; padding:2px 5px; cursor:pointer;">B</button>
   <button class="mini-btn btn-replay" title="重放请求">🔄</button>
   <button class="mini-btn btn-copy" title="复制 URL">📋</button>
   <button class="mini-btn btn-view" title="查看源代码">👁️</button>
  </div>
 </div>`;
if (item.postData) {
let previewData = item.postData;
if (previewData.length > 80) previewData = previewData.substring(0, 80) + '...';
htmlContent += `<div style="font-size:9px; color:#888; padding-left:36px; margin-top:3px; font-family:monospace; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">Payload: ${previewData}</div>`;
}
htmlContent += `</div>`;
div.innerHTML = htmlContent;

// ── 事件绑定 ──
div.querySelector('.btn-star').onclick = (e) => {
    e.stopPropagation();
    chrome.runtime.sendMessage({ action: 'TOGGLE_STAR', id: item.id }, (res) => {
        if (res.starred) { starredSet.add(item.id); e.target.textContent = '⭐'; div.dataset.starred = '1'; }
        else { starredSet.delete(item.id); e.target.textContent = '☆'; div.dataset.starred = '0'; }
    });
};
div.querySelector('.btn-diff-a').onclick = (e) => {
    e.stopPropagation();
    diffTargetA = item;
    panelRoot.getElementById('diff-a-label').textContent = `A: ${item.url.split('/').pop() || item.url}`;
    panelRoot.getElementById('diff-a-label').style.background = '#74b9ff';
    panelRoot.getElementById('diff-a-label').style.color = '#fff';
    alert('✅ 已标记为 Diff A，请在抓包列表选择 B');
};
div.querySelector('.btn-diff-b').onclick = (e) => {
    e.stopPropagation();
    diffTargetB = item;
    panelRoot.getElementById('diff-b-label').textContent = `B: ${item.url.split('/').pop() || item.url}`;
    panelRoot.getElementById('diff-b-label').style.background = '#fd79a8';
    panelRoot.getElementById('diff-b-label').style.color = '#fff';
    alert('✅ 已标记为 Diff B，前往性能页执行对比');
};
div.querySelector('.btn-copy').onclick = (e) => {
    e.stopPropagation();
    navigator.clipboard.writeText(item.url).then(() => alert('✅ 资源 URL 已复制'));
};
div.querySelector('.btn-view').onclick = (e) => { e.stopPropagation(); showLogContent(item); };
div.querySelector('.btn-replay').onclick = (e) => {
    e.stopPropagation();
    if (confirm('是否要在当前页面重新发送（重放）此网络请求?')) {
        chrome.runtime.sendMessage({ action: 'FETCH_BODY', tabId: item.tabId, targetId: item.targetId, requestId: item.id }, (res) => {
            const body = (res && res.body) ? res.body : null;
            window.postMessage({ type: 'REPLAY_REQUEST', url: item.url, method: item.method, body: body }, '*');
            alert('🚀 重放指令已下发，请观察抓包列表是否有新请求产生。');
        });
    }
};
div.onclick = () => showLogContent(item);
logList.prepend(div);
if (logList.children.length > 300) logList.lastElementChild.remove();
applyFilterSingle(div);
// 自动写入 POST 缓存库
if (item.status && item.status !== 'Pending') {
    saveToPostCache(item);
}
}
function applyFilter() {
const items = panelRoot.querySelectorAll('.log-item');
items.forEach(item => applyFilterSingle(item));
}
function applyFilterSingle(item) {
const itemType = item.dataset.type;
const itemUrl = item.dataset.url;
const isStarred = item.dataset.starred === '1';
let typeMatch = (currentTypeFilter === 'ALL' || itemType === currentTypeFilter || (currentTypeFilter === 'MEDIA' && itemType.includes('MEDIA')));
let searchMatch = (!currentSearchText || itemUrl.includes(currentSearchText));
let starMatch = !showStarredOnly || isStarred;
item.style.display = (typeMatch && searchMatch && starMatch) ? 'flex' : 'none';
}
function showLogContent(item, fromBodyReady = false) {
const modalViewer = panelRoot.getElementById('modal-viewer');
const codeContent = panelRoot.getElementById('code-content');
const aiPanel = panelRoot.getElementById('ai-analysis-panel');
const logData = logsMap.get(item.id);
if (aiPanel) aiPanel.style.display = 'none';
modalViewer.style.display = 'block';

// 请求本身失败（网络错误）→ 直接展示请求信息，不走 FETCH_BODY
if (logData.status === 'Failed' || logData.status === 'Canceled') {
    const statusColor = logData.status === 'Canceled' ? '#f59e0b' : '#ef4444';
    const icon = logData.status === 'Canceled' ? '🚫' : '❌';
    let html = `<div style="padding:16px; font-family:monospace; font-size:12px;">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px;padding:10px 14px;background:rgba(239,68,68,0.08);border:1px solid rgba(239,68,68,0.2);border-radius:8px;">
            <span style="font-size:18px;">${icon}</span>
            <div>
                <div style="font-weight:700;color:${statusColor};">请求${logData.status === 'Canceled' ? '被取消' : '失败'}</div>
                ${logData.errorText ? `<div style="font-size:11px;color:#6b7280;margin-top:2px;">${escHtml(logData.errorText)}</div>` : ''}
            </div>
        </div>
        <div style="margin-bottom:10px;">
            <span style="color:#10b981;font-weight:bold;">${escHtml(logData.method||'GET')}</span>
            <span style="color:#3b82f6;word-break:break-all;margin-left:6px;">${escHtml(logData.url||'')}</span>
        </div>`;
    if (logData.requestHeaders && Object.keys(logData.requestHeaders).length) {
        html += '<div style="color:#61afef;font-weight:bold;margin-bottom:6px;">Request Headers:</div>';
        html += `<pre style="color:#c9d1d9;margin:0 0 12px;white-space:pre-wrap;word-break:break-all;background:#181c2e;padding:10px;border-radius:6px;font-size:11px;">${escHtml(JSON.stringify(logData.requestHeaders, null, 2))}</pre>`;
    }
    if (logData.postData) {
        let postDisplay = logData.postData;
        try { postDisplay = JSON.stringify(JSON.parse(postDisplay), null, 2); } catch(e) {}
        html += '<div style="color:#e17055;font-weight:bold;margin-bottom:6px;">Request Payload:</div>';
        html += `<pre style="color:#c9d1d9;margin:0 0 12px;white-space:pre-wrap;word-break:break-all;background:#181c2e;padding:10px;border-radius:6px;font-size:11px;">${escHtml(postDisplay)}</pre>`;
    }
    html += `<div style="color:#6b7280;font-size:11px;margin-top:8px;padding:8px 12px;background:#f8fafc;border-radius:6px;border-left:3px solid #e4e7f0;">
        💡 此请求在网络层失败，服务器未返回响应体。常见原因：DNS 解析失败、连接被拒绝、资源不存在、SSL 证书错误。
    </div></div>`;
    codeContent.innerHTML = html;
    codeContent.dataset.waitingId = '';
    return;
}

// 已有本地缓存直接渲染
if (logData.content) {
    if (logData.postData) {
        let postDisplay = logData.postData;
        try { postDisplay = JSON.stringify(JSON.parse(postDisplay), null, 2); } catch(e) {}
        const infoHtml = `<div style="padding:12px 15px; background:#1a1d23; border-bottom:2px solid #444; font-family:monospace; font-size:12px;">
            <div style="margin-bottom:8px;"><span style="color:#00b894; font-weight:bold;">${escHtml(logData.method || 'GET')}</span> <span style="color:#0984e3; word-break:break-all;">${escHtml(logData.url || '')}</span></div>
            ${logData.status && logData.status !== 'Pending' ? `<div style="margin-bottom:8px;"><span style="color:#636e72;">Status:</span> <span style="font-weight:bold; color:#abb2bf;">${logData.status}</span>${logData.duration ? ' · ' + logData.duration + 'ms' : ''}</div>` : ''}
            <div style="color:#e17055; font-weight:bold; margin-bottom:4px;">Request Payload:</div>
            <pre style="color:#abb2bf; margin:0; white-space:pre-wrap; word-break:break-all; background:#1e2127; padding:10px; border-radius:4px; max-height:300px; overflow-y:auto;">${escHtml(postDisplay)}</pre>
            <div style="color:#61afef; font-weight:bold; margin-top:10px; margin-bottom:4px;">Response Body:</div>
        </div>`;
        const wrapper = document.createElement('div');
        wrapper.innerHTML = infoHtml;
        const responseContainer = document.createElement('pre');
        responseContainer.style.cssText = 'margin:0; padding:15px; font-family:Consolas,"Courier New",monospace; font-size:13px; line-height:1.5; white-space:pre-wrap; word-wrap:break-word;';
        codeContent.innerHTML = '';
        codeContent.appendChild(wrapper);
        codeContent.appendChild(responseContainer);
        let bodyText = logData.content;
        if (logData.base64Encoded) { try { bodyText = decodeURIComponent(escape(window.atob(logData.content))); } catch(e) {} }
        const highlightEnabled = panelRoot.getElementById('highlight-toggle')?.checked !== false;
        try {
            const obj = JSON.parse(bodyText);
            const pretty = JSON.stringify(obj, null, 2);
            if (highlightEnabled && window.Prism && window.Prism.languages.json) {
                const hl = window.Prism.highlight(pretty, window.Prism.languages.json, 'json');
                responseContainer.innerHTML = hl;
            } else {
                responseContainer.innerHTML = syntaxHighlight(obj);
            }
        } catch(e) {
            responseContainer.textContent = bodyText;
        }
    } else {
        renderContentInModal(logData.content, item.type, logData.base64Encoded);
    }
    modalViewer.style.display = 'block';
    codeContent.dataset.waitingId = '';
    return;
}

// 标记正在等待的 requestId，供 BODY_READY 消息自动触发刷新
codeContent.dataset.waitingId = item.id;

// 显示等待 UI
if (!fromBodyReady) {
    codeContent.innerHTML = `
        <div style="padding:20px; font-family:monospace; font-size:12px;">
            <div style="color:#f39c12; margin-bottom:12px;">⏳ 正在等待响应体就绪...</div>
            <div style="color:#636e72; font-size:11px; line-height:1.8;">
                • 如果请求已完成，数据将在 1~2 秒内自动显示<br>
                • 如果请求仍在进行中，完成后会自动刷新<br>
                • 超大响应体（视频流等）不缓存，请直接在 Network 面板查看
            </div>
            <button onclick="(()=>{
                const item = window.__phantom_retry_item__;
                if(item) window.__phantom_retry__(item);
            })()" style="margin-top:15px; padding:8px 16px; background:#0984e3; color:white; border:none; border-radius:4px; cursor:pointer; font-size:12px;">🔄 立即重试</button>
        </div>`;
    window.__phantom_retry_item__ = item;
    window.__phantom_retry__ = (it) => showLogContent(it, false);
}

chrome.runtime.sendMessage({ action: 'FETCH_BODY', requestId: item.id }, (res) => {
    if (!res) {
        codeContent.dataset.waitingId = '';
        codeContent.innerHTML = `
            <div style="padding:20px; font-family:monospace; font-size:12px;">
                <div style="color:#e74c3c; margin-bottom:10px;">⚠️ 无法连接后台服务</div>
                <div style="color:#636e72; font-size:11px;">Service Worker 可能已重启，请刷新页面后重试。</div>
            </div>`;
        return;
    }

    if (res.fetchFailed) {
        // 后台记录了失败原因，把原因文本显示出来
        codeContent.innerHTML = `
            <div style="padding:20px; font-family:monospace; font-size:12px;">
                <div style="color:#e74c3c; margin-bottom:10px;">⚠️ 响应体获取失败</div>
                <pre style="color:#636e72; background:#f9f9f9; padding:12px; border-radius:4px; font-size:11px; white-space:pre-wrap;">${res.body}</pre>
                <div style="color:#999; font-size:11px; margin-top:10px;">
                    💡 常见原因：<br>
                    1. 请求为 <b>204 No Content</b> / <b>304 Not Modified</b>（响应体本来就是空的）<br>
                    2. 请求是 <b>流式响应</b>（EventSource / chunked），debugger 无法缓存<br>
                    3. 该请求在扩展加载<b>之前</b>就已发出（刷新页面后重试）<br>
                    4. 浏览器对 <b>ServiceWorker</b> 拦截的请求不暴露响应体
                </div>
            </div>`;
        codeContent.dataset.waitingId = '';
        return;
    }

    if (res.empty || res.body === '') {
        codeContent.dataset.waitingId = '';
        let html = '<div style="padding:15px; font-family:monospace; font-size:12px;">';
        html += '<div style="color:#636e72; margin-bottom:12px;">（空响应体 — 服务器返回了 0 字节内容）</div>';
        html += `<div style="margin-bottom:12px;"><span style="color:#00b894; font-weight:bold;">${escHtml(logData.method || 'GET')}</span> <span style="color:#0984e3; word-break:break-all;">${escHtml(logData.url || '')}</span></div>`;
        if (logData.status && logData.status !== 'Pending') {
            html += `<div style="margin-bottom:12px;"><span style="color:#636e72;">Status:</span> <span style="font-weight:bold;">${logData.status}</span>${logData.duration ? ' · ' + logData.duration + 'ms' : ''}</div>`;
        }
        if (logData.requestHeaders && Object.keys(logData.requestHeaders).length) {
            html += '<div style="color:#61afef; font-weight:bold; margin-bottom:6px;">Request Headers:</div>';
            html += `<pre style="color:#abb2bf; margin:0 0 12px; white-space:pre-wrap; word-break:break-all; background:#1e2127; padding:10px; border-radius:4px;">${escHtml(JSON.stringify(logData.requestHeaders, null, 2))}</pre>`;
        }
        if (logData.postData) {
            let postDisplay = logData.postData;
            try { postDisplay = JSON.stringify(JSON.parse(postDisplay), null, 2); } catch(e) {}
            html += '<div style="color:#e17055; font-weight:bold; margin-bottom:6px;">Request Payload:</div>';
            html += `<pre style="color:#abb2bf; margin:0 0 12px; white-space:pre-wrap; word-break:break-all; background:#1e2127; padding:10px; border-radius:4px;">${escHtml(postDisplay)}</pre>`;
        }
        html += '</div>';
        codeContent.innerHTML = html;
        return;
    }

    if (res.error) {
        // 响应体不可用 — 展示已有的请求信息作为回退
        codeContent.dataset.waitingId = '';
        let fallback = '<div style="padding:15px; font-family:monospace; font-size:12px;">';
        fallback += `<div style="margin-bottom:12px;"><span style="color:#00b894; font-weight:bold;">${escHtml(logData.method || 'GET')}</span> <span style="color:#0984e3; word-break:break-all;">${escHtml(logData.url || '')}</span></div>`;
        if (logData.status && logData.status !== 'Pending') {
            fallback += `<div style="margin-bottom:12px;"><span style="color:#636e72;">Status:</span> <span style="font-weight:bold;">${logData.status}</span>${logData.duration ? ' · ' + logData.duration + 'ms' : ''}</div>`;
        }
        if (logData.requestHeaders && Object.keys(logData.requestHeaders).length) {
            fallback += '<div style="color:#61afef; font-weight:bold; margin-bottom:6px;">Request Headers:</div>';
            fallback += `<pre style="color:#abb2bf; margin:0 0 12px; white-space:pre-wrap; word-break:break-all; background:#1e2127; padding:10px; border-radius:4px;">${escHtml(JSON.stringify(logData.requestHeaders, null, 2))}</pre>`;
        }
        if (logData.postData) {
            let postDisplay = logData.postData;
            try { postDisplay = JSON.stringify(JSON.parse(postDisplay), null, 2); } catch(e) {}
            fallback += '<div style="color:#e17055; font-weight:bold; margin-bottom:6px;">Request Payload:</div>';
            fallback += `<pre style="color:#abb2bf; margin:0 0 12px; white-space:pre-wrap; word-break:break-all; background:#1e2127; padding:10px; border-radius:4px;">${escHtml(postDisplay)}</pre>`;
        }
        fallback += '<div style="color:#636e72; font-size:11px; margin-top:10px; border-top:1px solid #444; padding-top:10px;">&#9888; 响应体缓存已过期或未就绪，以上为请求信息。刷新页面重新抓包可获取完整响应体。</div>';
        fallback += '</div>';
        codeContent.innerHTML = fallback;
        return;
    }

    // 成功拿到数据
    codeContent.dataset.waitingId = '';
    logData.content = res.body;
    logData.base64Encoded = res.base64Encoded;

    // 如果有 POST payload，在响应体上方显示请求信息
    if (logData.postData) {
        let postDisplay = logData.postData;
        try { postDisplay = JSON.stringify(JSON.parse(postDisplay), null, 2); } catch(e) {}
        const infoHtml = `<div style="padding:12px 15px; background:#1a1d23; border-bottom:2px solid #444; font-family:monospace; font-size:12px;">
            <div style="margin-bottom:8px;"><span style="color:#00b894; font-weight:bold;">${escHtml(logData.method || 'GET')}</span> <span style="color:#0984e3; word-break:break-all;">${escHtml(logData.url || '')}</span></div>
            ${logData.status && logData.status !== 'Pending' ? `<div style="margin-bottom:8px;"><span style="color:#636e72;">Status:</span> <span style="font-weight:bold; color:#abb2bf;">${logData.status}</span>${logData.duration ? ' · ' + logData.duration + 'ms' : ''}</div>` : ''}
            <div style="color:#e17055; font-weight:bold; margin-bottom:4px;">Request Payload:</div>
            <pre style="color:#abb2bf; margin:0; white-space:pre-wrap; word-break:break-all; background:#1e2127; padding:10px; border-radius:4px; max-height:300px; overflow-y:auto;">${escHtml(postDisplay)}</pre>
            <div style="color:#61afef; font-weight:bold; margin-top:10px; margin-bottom:4px;">Response Body:</div>
        </div>`;
        // 先渲染请求信息区，再追加响应体
        const wrapper = document.createElement('div');
        wrapper.innerHTML = infoHtml;
        const responseContainer = document.createElement('pre');
        responseContainer.style.cssText = 'margin:0; padding:15px; font-family:Consolas,"Courier New",monospace; font-size:13px; line-height:1.5; white-space:pre-wrap; word-wrap:break-word;';
        codeContent.innerHTML = '';
        codeContent.appendChild(wrapper);
        codeContent.appendChild(responseContainer);
        // 渲染响应体到 responseContainer
        let bodyText = res.body;
        if (res.base64Encoded) { try { bodyText = decodeURIComponent(escape(window.atob(res.body))); } catch(e) {} }
        try {
            const json = JSON.parse(bodyText);
            responseContainer.innerHTML = syntaxHighlight(json);
        } catch(e) {
            responseContainer.textContent = bodyText;
        }
    } else {
        renderContentInModal(res.body, item.type, res.base64Encoded);
    }
});
}
// Cookie 获取逻辑
function getCookies() {
chrome.runtime.sendMessage({action: 'FETCH_COOKIES'}, (cookies) => {
if (chrome.runtime.lastError || !cookies || cookies.length === 0) {
alert('⚠️ 当前域下未发现可用的 Cookie 数据');
return;
}
const modal = panelRoot.getElementById('modal-viewer');
const codeContent = panelRoot.getElementById('code-content');
const aiPanel = panelRoot.getElementById('ai-analysis-panel');
if (aiPanel) aiPanel.style.display = 'none';
let formattedCookies = cookies.map(c => `<span style="color:#0984e3; font-weight:bold;">${c.name}</span>=<span style="color:#d63031;">${c.value}</span>`).join('\n\n');
codeContent.innerHTML = formattedCookies;
modal.style.display = "block";
});
}
// 导出 JSON 数据逻辑
function exportData() {
if (logsMap.size === 0) {
alert("⚠️ 当前缓冲池中无任何网络请求数据，无法执行导出。");
return;
}
const data = Array.from(logsMap.values());
const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
const url = URL.createObjectURL(blob);
const a = document.createElement('a');
a.href = url;
a.download = `Phantom-Log-${Date.now()}.json`;
document.body.appendChild(a);
a.click();
a.remove();
}
// ==========================================
// 页面元素吸管工具逻辑
// ==========================================
let isInspecting = false;
let hoveredElement = null;
let overlayElement = null;
function togglePickerMode() {
isInspecting = !isInspecting;
if (isInspecting) {
document.body.style.cursor = 'crosshair';
document.addEventListener('mouseover', handleHover, true);
document.addEventListener('click', handleClick, true);
createOverlay();
// 隐藏主面板以免遮挡视线
if (panelHost) panelHost.style.display = 'none';
} else {
document.body.style.cursor = 'default';
document.removeEventListener('mouseover', handleHover, true);
document.removeEventListener('click', handleClick, true);
if (hoveredElement) hoveredElement.style.outline = '';
if (overlayElement) overlayElement.style.display = 'none';
// 恢复主面板
if (panelHost && isPanelOpen) panelHost.style.display = 'block';
}
}
function handleHover(e) {
if (!isInspecting || (panelHost && panelHost.contains(e.target))) return;
if (hoveredElement) hoveredElement.style.outline = '';
hoveredElement = e.target;
hoveredElement.style.outline = '3px dashed #ff4757';
}
function handleClick(e) {
if (!isInspecting || (panelHost && panelHost.contains(e.target))) return;
e.preventDefault();
e.stopPropagation();
showResult(getCssSelector(e.target), getXpath(e.target));
togglePickerMode();
}
function getCssSelector(el) {
if (!(el instanceof Element)) return;
const path = [];
while (el.nodeType === Node.ELEMENT_NODE) {
let selector = el.nodeName.toLowerCase();
if (el.id) {
selector += '#' + el.id;
path.unshift(selector);
break;
} else {
let sib = el, nth = 1;
while (sib = sib.previousElementSibling) {
if (sib.nodeName.toLowerCase() == selector) nth++;
}
if (nth != 1) selector += ":nth-of-type(" + nth + ")";
}
path.unshift(selector);
el = el.parentNode;
}
return path.join(" > ");
}
function getXpath(el) {
if (el.id) return `//*[@id="${el.id}"]`;
const paths = [];
for (; el && el.nodeType == 1; el = el.parentNode) {
let index = 0;
for (let sib = el.previousSibling; sib; sib = sib.previousSibling) {
if (sib.nodeType == Node.ELEMENT_NODE && sib.tagName == el.tagName) index++;
}
const tagName = el.tagName.toLowerCase();
const pathIndex = (index ? `[${index + 1}]` : '');
paths.splice(0, 0, `${tagName}${pathIndex}`);
}
return paths.length ? '/' + paths.join('/') : null;
}
function createOverlay() {
if (overlayElement) {
overlayElement.style.display = 'block';
return;
}
overlayElement = document.createElement('div');
overlayElement.style.cssText = 'position:fixed; top:20px; left:20px; z-index:2147483648; background:#fff; padding:15px; border-radius:8px; box-shadow:0 0 15px rgba(0,0,0,0.3); width:350px; color:#333; font-family:sans-serif; border-left:4px solid #6c5ce7;';
overlayElement.innerHTML = `<h3 style="margin:0 0 10px 0; font-size:14px; color:#333;">🎯 吸管结果截获</h3> <label style="font-size:11px; color:#666;">CSS Selector:</label> <input id="res-css" style="width:100%; padding:5px; margin-bottom:10px; border:1px solid #ddd; border-radius:4px;" readonly> <label style="font-size:11px; color:#666;">XPath:</label> <input id="res-xpath" style="width:100%; padding:5px; margin-bottom:15px; border:1px solid #ddd; border-radius:4px;" readonly> <button id="pk-close" style="width:100%; padding:8px; background:#6c5ce7; color:white; border:none; border-radius:4px; cursor:pointer; font-weight:bold;">关闭面板</button>`;
document.body.appendChild(overlayElement);
overlayElement.querySelector('#pk-close').onclick = () => overlayElement.style.display = 'none';
}
function showResult(css, xpath) {
if (!overlayElement) createOverlay();
overlayElement.style.display = 'block';
overlayElement.querySelector('#res-css').value = css;
overlayElement.querySelector('#res-xpath').value = xpath;
}
document.addEventListener('keydown', (e) => {
    if (e.ctrlKey && e.key === '`') {
        toggleDashboard();
    }
});

// ==========================================
// MD5 纯前端实现 (编解码工具箱用)
// ==========================================
function phantomMD5(str) {
    function md5cycle(x, k) {
        let a = x[0], b = x[1], c = x[2], d = x[3];
        a = ff(a, b, c, d, k[0], 7, -680876936); d = ff(d, a, b, c, k[1], 12, -389564586);
        c = ff(c, d, a, b, k[2], 17, 606105819); b = ff(b, c, d, a, k[3], 22, -1044525330);
        a = ff(a, b, c, d, k[4], 7, -176418897); d = ff(d, a, b, c, k[5], 12, 1200080426);
        c = ff(c, d, a, b, k[6], 17, -1473231341); b = ff(b, c, d, a, k[7], 22, -45705983);
        a = ff(a, b, c, d, k[8], 7, 1770035416); d = ff(d, a, b, c, k[9], 12, -1958414417);
        c = ff(c, d, a, b, k[10], 17, -42063); b = ff(b, c, d, a, k[11], 22, -1990404162);
        a = ff(a, b, c, d, k[12], 7, 1804603682); d = ff(d, a, b, c, k[13], 12, -40341101);
        c = ff(c, d, a, b, k[14], 17, -1502002290); b = ff(b, c, d, a, k[15], 22, 1236535329);
        a = gg(a, b, c, d, k[1], 5, -165796510); d = gg(d, a, b, c, k[6], 9, -1069501632);
        c = gg(c, d, a, b, k[11], 14, 643717713); b = gg(b, c, d, a, k[0], 20, -373897302);
        a = gg(a, b, c, d, k[5], 5, -701558691); d = gg(d, a, b, c, k[10], 9, 38016083);
        c = gg(c, d, a, b, k[15], 14, -660478335); b = gg(b, c, d, a, k[4], 20, -405537848);
        a = gg(a, b, c, d, k[9], 5, 568446438); d = gg(d, a, b, c, k[14], 9, -1019803690);
        c = gg(c, d, a, b, k[3], 14, -187363961); b = gg(b, c, d, a, k[8], 20, 1163531501);
        a = gg(a, b, c, d, k[13], 5, -1444681467); d = gg(d, a, b, c, k[2], 9, -51403784);
        c = gg(c, d, a, b, k[7], 14, 1735328473); b = gg(b, c, d, a, k[12], 20, -1926607734);
        a = hh(a, b, c, d, k[5], 4, -378558); d = hh(d, a, b, c, k[8], 11, -2022574463);
        c = hh(c, d, a, b, k[11], 16, 1839030562); b = hh(b, c, d, a, k[14], 23, -35309556);
        a = hh(a, b, c, d, k[1], 4, -1530992060); d = hh(d, a, b, c, k[4], 11, 1272893353);
        c = hh(c, d, a, b, k[7], 16, -155497632); b = hh(b, c, d, a, k[10], 23, -1094730640);
        a = hh(a, b, c, d, k[13], 4, 681279174); d = hh(d, a, b, c, k[0], 11, -358537222);
        c = hh(c, d, a, b, k[3], 16, -722521979); b = hh(b, c, d, a, k[6], 23, 76029189);
        a = hh(a, b, c, d, k[9], 4, -640364487); d = hh(d, a, b, c, k[12], 11, -421815835);
        c = hh(c, d, a, b, k[15], 16, 530742520); b = hh(b, c, d, a, k[2], 23, -995338651);
        a = ii(a, b, c, d, k[0], 6, -198630844); d = ii(d, a, b, c, k[7], 10, 1126891415);
        c = ii(c, d, a, b, k[14], 15, -1416354905); b = ii(b, c, d, a, k[5], 21, -57434055);
        a = ii(a, b, c, d, k[12], 6, 1700485571); d = ii(d, a, b, c, k[3], 10, -1894986606);
        c = ii(c, d, a, b, k[10], 15, -1051523); b = ii(b, c, d, a, k[1], 21, -2054922799);
        a = ii(a, b, c, d, k[8], 6, 1873313359); d = ii(d, a, b, c, k[15], 10, -30611744);
        c = ii(c, d, a, b, k[6], 15, -1560198380); b = ii(b, c, d, a, k[13], 21, 1309151649);
        a = ii(a, b, c, d, k[4], 6, -145523070); d = ii(d, a, b, c, k[11], 10, -1120210379);
        c = ii(c, d, a, b, k[2], 15, 718787259); b = ii(b, c, d, a, k[9], 21, -343485551);
        x[0] = add32(a, x[0]); x[1] = add32(b, x[1]); x[2] = add32(c, x[2]); x[3] = add32(d, x[3]);
    }
    function cmn(q, a, b, x, s, t) { a = add32(add32(a, q), add32(x, t)); return add32((a << s) | (a >>> (32 - s)), b); }
    function ff(a, b, c, d, x, s, t) { return cmn((b & c) | ((~b) & d), a, b, x, s, t); }
    function gg(a, b, c, d, x, s, t) { return cmn((b & d) | (c & (~d)), a, b, x, s, t); }
    function hh(a, b, c, d, x, s, t) { return cmn(b ^ c ^ d, a, b, x, s, t); }
    function ii(a, b, c, d, x, s, t) { return cmn(c ^ (b | (~d)), a, b, x, s, t); }
    function add32(a, b) { return (a + b) & 0xFFFFFFFF; }
    function md5blk(s) {
        const md5blks = []; for (let i = 0; i < 64; i += 4) md5blks[i >> 2] = s.charCodeAt(i) + (s.charCodeAt(i+1) << 8) + (s.charCodeAt(i+2) << 16) + (s.charCodeAt(i+3) << 24);
        return md5blks;
    }
    let n = str.length, state = [1732584193, -271733879, -1732584194, 271733878], i;
    for (i = 64; i <= n; i += 64) md5cycle(state, md5blk(str.substring(i - 64, i)));
    str = str.substring(i - 64);
    const tail = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
    for (i = 0; i < str.length; i++) tail[i >> 2] |= str.charCodeAt(i) << ((i % 4) << 3);
    tail[i >> 2] |= 0x80 << ((i % 4) << 3);
    if (i > 55) { md5cycle(state, tail); for (i = 0; i < 16; i++) tail[i] = 0; }
    tail[14] = n * 8;
    md5cycle(state, tail);
    const hex_chr = '0123456789abcdef';
    let s = '';
    for (i = 0; i < 4; i++) for (let j = 0; j < 4; j++) s += hex_chr.charAt((state[i] >> (j * 8 + 4)) & 0x0f) + hex_chr.charAt((state[i] >> (j * 8)) & 0x0f);
    return s;
}

// ══════════════════════════════════════════════════════════════════
// 📡 全流量查看器 — 核心函数（GET+POST 全持久化 + 关键字高亮定位）
// ══════════════════════════════════════════════════════════════════

function saveToTrafficCache(logData) {
    if (!logData || !logData.url) return;
    // 跳过扩展自身请求
    if (logData.url.startsWith('chrome-extension://')) return;

    const existing = trafficCacheStore.findIndex(e => e.id === logData.id);
    const entry = {
        id: logData.id || Date.now().toString(36),
        url: logData.url,
        method: logData.method || 'GET',
        status: logData.status || 'Pending',
        postData: logData.postData || '',
        requestHeaders: logData.requestHeaders || {},
        responseHeaders: logData.responseHeaders || {},
        time: logData.time || new Date().toLocaleTimeString(),
        mimeType: logData.mimeType || '',
        type: logData.type || 'OTHER',
        durationMs: logData.responseTime && logData.startTime ? logData.responseTime - logData.startTime : 0
    };

    if (existing >= 0) {
        // 合并更新（Pending → 完成）
        Object.assign(trafficCacheStore[existing], entry);
    } else {
        trafficCacheStore.unshift(entry);
        if (trafficCacheStore.length > MAX_TRAFFIC_CACHE) trafficCacheStore.pop();
    }

    // 持久化（节流：500ms 内只写一次）
    if (!saveToTrafficCache._timer) {
        saveToTrafficCache._timer = setTimeout(() => {
            chrome.storage.local.set({ trafficCacheStore: trafficCacheStore.slice(0, MAX_TRAFFIC_CACHE) });
            saveToTrafficCache._timer = null;
        }, 500);
    }

    // 实时更新面板
    if (isPanelOpen && panelRoot) renderTrafficView();
}

// 关键字高亮函数
function highlightText(text, keyword) {
    if (!keyword || !text) return escHtml(text || '');
    const escaped = keyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(`(${escaped})`, 'gi');
    return escHtml(text).replace(regex, '<mark class="phantom-hl">$1</mark>');
}

// 请求是否匹配关键字
function trafficMatchesKeyword(entry, keyword) {
    if (!keyword) return true;
    const kw = keyword.toLowerCase();
    if (entry.url && entry.url.toLowerCase().includes(kw)) return true;
    if (entry.postData && entry.postData.toLowerCase().includes(kw)) return true;
    if (entry.method && entry.method.toLowerCase().includes(kw)) return true;
    // 搜索请求头
    if (entry.requestHeaders) {
        for (const [k, v] of Object.entries(entry.requestHeaders)) {
            if (k.toLowerCase().includes(kw) || String(v).toLowerCase().includes(kw)) return true;
        }
    }
    // 搜索响应头
    if (entry.responseHeaders) {
        for (const [k, v] of Object.entries(entry.responseHeaders)) {
            if (k.toLowerCase().includes(kw) || String(v).toLowerCase().includes(kw)) return true;
        }
    }
    return false;
}

// 渲染全流量面板
function renderTrafficView() {
    if (!panelRoot) return;
    const list = panelRoot.getElementById('traffic-list');
    if (!list) return;

    const keyword = trafficSearchKeyword;
    const methodFilter = trafficMethodFilter;

    // 过滤
    const filtered = trafficCacheStore.filter(e => {
        if (methodFilter !== 'ALL' && e.method !== methodFilter) return false;
        return trafficMatchesKeyword(e, keyword);
    });

    // 更新统计
    const totalEl = panelRoot.getElementById('traffic-total');
    const getEl = panelRoot.getElementById('traffic-get-count');
    const postEl = panelRoot.getElementById('traffic-post-count');
    const filteredEl = panelRoot.getElementById('traffic-filtered-count');
    if (totalEl) totalEl.textContent = trafficCacheStore.length;
    if (getEl) getEl.textContent = trafficCacheStore.filter(e => e.method === 'GET').length;
    if (postEl) postEl.textContent = trafficCacheStore.filter(e => e.method === 'POST').length;
    if (filteredEl) filteredEl.textContent = filtered.length;

    // 渲染列表（最多显示 200 条）
    const display = filtered.slice(0, 200);
    list.innerHTML = display.map(e => {
        const mClass = 'method-' + (e.method || 'other').toLowerCase();
        const mBadge = 'm-' + (e.method || 'other').toLowerCase();
        const sClass = !e.status || e.status === 'Pending' ? 's-pend' : (e.status >= 400 ? 's-err' : 's-ok');
        const urlDisplay = keyword ? highlightText(e.url, keyword) : escHtml(e.url || '');
        return `<div class="traffic-item ${mClass}" data-tid="${e.id}">
            <span class="traffic-method ${mBadge}">${e.method || '?'}</span>
            <span class="traffic-status ${sClass}">${e.status || '⏳'}</span>
            <span class="traffic-url">${urlDisplay}</span>
            <span class="traffic-time">${e.time || ''}</span>
        </div>`;
    }).join('');

    // 绑定点击事件
    list.querySelectorAll('.traffic-item').forEach(el => {
        el.onclick = () => {
            const entry = trafficCacheStore.find(e => e.id === el.dataset.tid);
            if (entry) showTrafficDetail(entry);
        };
    });
}

// 解析 URL 参数为 key-value 数组
function parseUrlParams(url) {
    try {
        const u = new URL(url, 'http://dummy');
        const params = [];
        u.searchParams.forEach((v, k) => params.push({ key: k, value: v }));
        return params;
    } catch(e) { return []; }
}

// 解析 POST body 为 key-value 数组
function parseBodyParams(body) {
    if (!body) return [];
    // JSON
    try {
        const obj = JSON.parse(body);
        const params = [];
        const flatten = (o, prefix) => {
            for (const [k, v] of Object.entries(o)) {
                const fullKey = prefix ? prefix + '.' + k : k;
                if (v && typeof v === 'object' && !Array.isArray(v)) flatten(v, fullKey);
                else params.push({ key: fullKey, value: String(v) });
            }
        };
        flatten(obj, '');
        return params;
    } catch(e) {}
    // form-urlencoded
    try {
        const params = [];
        new URLSearchParams(body).forEach((v, k) => params.push({ key: k, value: v }));
        if (params.length > 0) return params;
    } catch(e) {}
    return [];
}

// 渲染参数表格（带高亮）
function renderParamTableHL(params, keyword) {
    if (!params || params.length === 0) return '<div style="color:#636e72; font-size:10px; padding:4px;">（无参数）</div>';
    const rows = params.map(p => {
        const kw = keyword || '';
        const matchRow = kw && (p.key.toLowerCase().includes(kw.toLowerCase()) || p.value.toLowerCase().includes(kw.toLowerCase()));
        const cls = matchRow ? ' class="phantom-hl-row"' : '';
        return `<tr${cls}><td class="param-key">${highlightText(p.key, kw)}</td><td class="param-val">${highlightText(p.value, kw)}</td></tr>`;
    }).join('');
    return `<table class="param-table"><tr><th>Key</th><th>Value</th></tr>${rows}</table>`;
}

// 渲染 headers 表格（带高亮）
function renderHeadersHL(headers, keyword) {
    if (!headers || Object.keys(headers).length === 0) return '<div style="color:#636e72; font-size:10px; padding:4px;">（无）</div>';
    const rows = Object.entries(headers).map(([k, v]) => {
        const kw = keyword || '';
        const matchRow = kw && (k.toLowerCase().includes(kw.toLowerCase()) || String(v).toLowerCase().includes(kw.toLowerCase()));
        const cls = matchRow ? ' class="phantom-hl-row"' : '';
        return `<tr${cls}><td class="param-key">${highlightText(k, kw)}</td><td class="param-val">${highlightText(String(v), kw)}</td></tr>`;
    }).join('');
    return `<table class="param-table"><tr><th>Header</th><th>Value</th></tr>${rows}</table>`;
}

// 显示请求详情模态框
function showTrafficDetail(entry) {
    if (!panelRoot) return;
    const modal = panelRoot.getElementById('traffic-detail-modal');
    const body = panelRoot.getElementById('traffic-detail-body');
    const title = panelRoot.getElementById('traffic-detail-title');
    if (!modal || !body) return;

    const kw = trafficSearchKeyword;
    const urlParams = parseUrlParams(entry.url);
    const bodyParams = parseBodyParams(entry.postData);

    title.textContent = `${entry.method} ${entry.status || 'Pending'} — ${(entry.url || '').substring(0, 60)}`;

    body.innerHTML = `
        <div class="traffic-detail-section">
            <h4>📌 请求 URL</h4>
            <div style="word-break:break-all; font-family:monospace; font-size:11px; color:#93c5fd; padding:4px 0;">${highlightText(entry.url, kw)}</div>
        </div>
        ${urlParams.length > 0 ? `<div class="traffic-detail-section">
            <h4>🔑 Query 参数 (${urlParams.length})</h4>
            ${renderParamTableHL(urlParams, kw)}
        </div>` : ''}
        ${entry.postData ? `<div class="traffic-detail-section">
            <h4>📝 请求体 (${entry.method})</h4>
            ${bodyParams.length > 0 ? renderParamTableHL(bodyParams, kw) : ''}
            <pre style="margin-top:6px; color:#f1fa8c; font-size:11px; max-height:200px; overflow:auto;">${highlightText(entry.postData, kw)}</pre>
        </div>` : ''}
        <div class="traffic-detail-section">
            <h4>📤 请求头</h4>
            ${renderHeadersHL(entry.requestHeaders, kw)}
        </div>
        <div class="traffic-detail-section">
            <h4>📥 响应头</h4>
            ${renderHeadersHL(entry.responseHeaders, kw)}
        </div>
        <div class="traffic-detail-section">
            <h4>ℹ️ 元信息</h4>
            <div style="font-size:10px; color:#9ca3af;">
                状态: ${entry.status || 'Pending'} | 类型: ${entry.mimeType || 'N/A'} | 耗时: ${entry.durationMs || 0}ms | 时间: ${entry.time || 'N/A'}
            </div>
        </div>
    `;

    modal.style.display = 'block';

    // 自动滚动到第一个高亮
    setTimeout(() => {
        const firstHL = body.querySelector('.phantom-hl');
        if (firstHL) firstHL.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 100);

    // 关闭按钮
    panelRoot.getElementById('traffic-detail-close').onclick = () => { modal.style.display = 'none'; };

    // 复制全部
    panelRoot.getElementById('traffic-detail-copy').onclick = () => {
        const text = JSON.stringify(entry, null, 2);
        navigator.clipboard.writeText(text).then(() => alert('✅ 已复制'));
    };

    // 生成 cURL
    panelRoot.getElementById('traffic-detail-curl').onclick = () => {
        let cmd = `curl '${entry.url}'`;
        if (entry.method !== 'GET') cmd += ` -X ${entry.method}`;
        if (entry.requestHeaders) {
            for (const [k, v] of Object.entries(entry.requestHeaders)) {
                cmd += ` -H '${k}: ${v}'`;
            }
        }
        if (entry.postData) cmd += ` --data-raw '${entry.postData.replace(/'/g, "'\\''")}'`;
        navigator.clipboard.writeText(cmd).then(() => alert('✅ cURL 已复制'));
    };
}

// 绑定全流量面板事件（在 createDashboardUI 末尾调用）
function bindTrafficEvents() {
    if (!panelRoot) return;

    // 搜索框
    const searchInput = panelRoot.getElementById('traffic-search');
    if (searchInput) {
        let searchTimer;
        searchInput.addEventListener('input', () => {
            clearTimeout(searchTimer);
            searchTimer = setTimeout(() => {
                trafficSearchKeyword = searchInput.value.trim();
                renderTrafficView();
            }, 300);
        });
    }

    // 方法过滤
    panelRoot.querySelectorAll('[data-tmethod]').forEach(chip => {
        chip.addEventListener('click', () => {
            panelRoot.querySelectorAll('[data-tmethod]').forEach(c => c.classList.remove('active'));
            chip.classList.add('active');
            trafficMethodFilter = chip.dataset.tmethod;
            renderTrafficView();
        });
    });

    // 清空
    const clearBtn = panelRoot.getElementById('traffic-clear-btn');
    if (clearBtn) {
        clearBtn.onclick = () => {
            trafficCacheStore = [];
            chrome.storage.local.set({ trafficCacheStore: [] });
            renderTrafficView();
        };
    }

    // 导出
    const exportBtn = panelRoot.getElementById('traffic-export-btn');
    if (exportBtn) {
        exportBtn.onclick = () => {
            const data = trafficCacheStore.filter(e => trafficMatchesKeyword(e, trafficSearchKeyword));
            const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url; a.download = `phantom-traffic-${Date.now()}.json`;
            document.body.appendChild(a); a.click(); a.remove();
            URL.revokeObjectURL(url);
        };
    }

    // 点击模态框背景关闭
    const modal = panelRoot.getElementById('traffic-detail-modal');
    if (modal) {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) modal.style.display = 'none';
        });
    }
}

// ══════════════════════════════════════════════════════════════════
// 🎬 视频链路逆向 — 核心渲染与交互
// ══════════════════════════════════════════════════════════════════

// 将一个 SCRIPT 类型的 log 注册到 scriptRegistry
function updateScriptRegistry(logData) {
    if (!logData || !logData.url) return;
    if (logData.type !== 'SCRIPT' && !(logData.mimeType && logData.mimeType.indexOf('javascript') !== -1)) return;
    if (logData.url.startsWith('chrome-extension://')) return;
    const key = logData.url.split('#')[0];
    let entry = scriptRegistry.get(key);
    if (!entry) {
        entry = { url: key, mime: logData.mimeType || '', size: 0, loadTime: logData.time || '', cryptoCount: 0, decryptCount: 0, requestCount: 0, signalCount: 0, mediaRefs: new Set(), requestId: logData.id };
        scriptRegistry.set(key, entry);
    }
    if (logData.mimeType) entry.mime = logData.mimeType;
    // 若 fromMediaChain 则刷新
}

// 把一个携带 frames 的事件归属到对应 script(计数 + 事件索引)
function attributeEventToScript(data) {
    if (!data || !Array.isArray(data.frames) || !data.frames.length) return;
    // 取第一帧作为主责文件
    const topFile = data.frames[0].file;
    if (!topFile) return;
    // 若该 URL 尚未在 registry,先占位(可能 JS 加载早于扩展或为内联脚本)
    let entry = scriptRegistry.get(topFile);
    if (!entry) {
        entry = { url: topFile, mime: 'application/javascript', size: 0, loadTime: '', cryptoCount: 0, decryptCount: 0, requestCount: 0, signalCount: 0, mediaRefs: new Set(), requestId: null, inferred: true };
        scriptRegistry.set(topFile, entry);
    }
    if (data.type === 'CRYPTO_REPORT') entry.cryptoCount++;
    else if (data.type === 'DECRYPT_FOUND') entry.decryptCount++;
    else if (data.type === 'PARAM_TRACE') entry.requestCount++;
    else if (data.type === 'SIGN_FIELD_FOUND' || data.type === 'PARAM_CRYPTO_FOUND') entry.signalCount++;
    // 索引事件
    let arr = scriptEventsByUrl.get(topFile);
    if (!arr) { arr = []; scriptEventsByUrl.set(topFile, arr); }
    const rec = { type: data.type, frames: data.frames, time: Date.now(), summary: buildEventSummary(data) };
    arr.unshift(rec);
    if (arr.length > 100) arr.pop();
}

function buildEventSummary(data) {
    switch (data.type) {
        case 'CRYPTO_REPORT':    return `${data.algo}  in=${String(data.in||'').substring(0,40)}  key=${String(data.key||'').substring(0,30)}`;
        case 'DECRYPT_FOUND':    return `${data.algo}  → ${String(data.plaintext||'').substring(0,60)}`;
        case 'PARAM_TRACE':      return `${data.method||''} ${data.url||''} (${Object.keys(data.params||{}).length} 参数)`;
        case 'PARAM_CRYPTO_FOUND': return `${data.key}=${String(data.value||'').substring(0,40)} [${(data.detected||[]).join(',')}]`;
        case 'SIGN_FIELD_FOUND': return `${data.field}=${data.value}`;
        case 'FUNC_TRACE':       return `${data.label}  ${data.durationMs}ms`;
    }
    return '';
}

// 渲染栈帧:每帧显示为 .sv-link,点击跳源码
function renderFrames(frames, maxShow) {
    if (!frames || !frames.length) return '';
    const n = Math.min(frames.length, maxShow || 3);
    let html = `<div class="vc-frames" style="margin-top:4px;">`;
    for (let i = 0; i < n; i++) {
        const f = frames[i];
        const baseName = (f.file || '').split('/').pop() || f.file;
        html += `<div style="font-family:monospace;font-size:10px;line-height:1.6;color:#6b7280;">
            <span style="color:#8b5cf6;">${escHtml(f.fn || '<anon>')}</span>
            <span class="sv-link" data-file="${escHtml(f.file)}" data-line="${f.line}" data-col="${f.col}"
                  style="color:#0984e3;cursor:pointer;text-decoration:underline;margin-left:6px;" title="点击查看源码">
                ${escHtml(baseName)}:${f.line}:${f.col}
            </span>
        </div>`;
    }
    if (frames.length > n) html += `<div style="font-size:9px;color:#9ca3af;margin-left:4px;">... 还有 ${frames.length - n} 帧</div>`;
    html += `</div>`;
    return html;
}

// ── 视频链路主渲染入口 ──
function renderVideoChain() {
    if (!panelRoot) return;
    chrome.runtime.sendMessage({ action: 'CHAIN_GET_STATE' }, (state) => {
        if (!state) return;
        const info = panelRoot.getElementById('vc-session-info');
        if (info) {
            const start = state.sessionStart ? new Date(state.sessionStart).toLocaleTimeString() : '-';
            const urlShort = state.sessionStartUrl ? state.sessionStartUrl.replace(/^https?:\/\//,'').substring(0,40) : '-';
            info.textContent = `⏱ ${start}  📍 ${urlShort}`;
        }
        // 视频区
        renderVcMediaList(state.chains || []);
        // 脚本区
        renderVcScriptsList();
        // 事件时间线(模式二选一)
        const events = videoChainMode === 'session' ? (state.sessionEvents || []) : (state.window || []);
        renderVcEvents(events);
    });
}

function renderVcMediaList(chains) {
    const list = panelRoot.getElementById('vc-media-list');
    const cnt = panelRoot.getElementById('vc-media-count');
    if (!list) return;
    if (cnt) cnt.textContent = chains.length;
    if (!chains.length) {
        list.innerHTML = '<div style="color:#9ca3af; font-size:11px; padding:10px; text-align:center;">暂无视频,播放视频后自动捕获</div>';
        return;
    }
    list.innerHTML = chains.slice(0, 10).map((chain, i) => {
        const elapsed = chain.endTime - chain.startTime;
        const urlShort = chain.mediaUrl.length > 80 ? chain.mediaUrl.substring(0, 80) + '…' : chain.mediaUrl;
        const ext = (chain.events || []).find(e => e.step === 'URL_EXTRACT');
        const apiLine = ext ? `<div style="font-size:10px;color:#0984e3;margin-top:3px;font-family:monospace;word-break:break-all;">📡 <b>API:</b> ${escHtml((ext.sourceApi||'').substring(0,90))} → 字段: <b style="color:#fdcb6e;">${escHtml(ext.field||'')}</b></div>` : '';
        return `<div class="vc-media-card" style="background:#fff;border:1px solid #e4e7f0;border-left:4px solid #e17055;border-radius:8px;padding:10px;margin-bottom:8px;">
            <div style="display:flex;align-items:center;gap:6px;margin-bottom:5px;flex-wrap:wrap;">
                <span style="background:#e17055;color:#fff;font-size:9px;padding:2px 8px;border-radius:10px;font-weight:700;">${(chain.mediaType||'other').toUpperCase()}</span>
                <span style="font-size:10px;color:#9ca3af;">${chain.events.length} 步 · ${elapsed}ms</span>
                <button class="vc-copy-url btn-small" style="margin-left:auto;background:#5b6ef5;padding:2px 8px;font-size:10px;" data-url="${escHtml(chain.mediaUrl)}">复制</button>
                <button class="vc-analyze-auth btn-small" style="background:#d63031;padding:2px 8px;font-size:10px;" data-url="${escHtml(chain.mediaUrl)}" data-idx="${i}">🔍 校验头</button>
                <button class="vc-expand-chain btn-small" style="background:#6c5ce7;padding:2px 8px;font-size:10px;" data-idx="${i}">展开事件</button>
            </div>
            <div style="font-family:monospace;font-size:10px;color:#333;word-break:break-all;background:#f8fafc;padding:5px 8px;border-radius:4px;" title="${escHtml(chain.mediaUrl)}">${escHtml(urlShort)}</div>
            ${apiLine}
            <div class="vc-media-events" data-idx="${i}" style="display:none;margin-top:8px;padding-top:8px;border-top:1px dashed #e4e7f0;"></div>
            <div class="vc-auth-result" data-idx="${i}" style="display:none;margin-top:8px;padding-top:8px;border-top:1px dashed #d63031;"></div>
        </div>`;
    }).join('');
    // 绑定操作
    list.querySelectorAll('.vc-copy-url').forEach(btn => {
        btn.onclick = (e) => {
            e.stopPropagation();
            navigator.clipboard.writeText(btn.dataset.url).then(() => { btn.textContent = '✅'; setTimeout(()=>btn.textContent='复制',1200); });
        };
    });
    list.querySelectorAll('.vc-expand-chain').forEach(btn => {
        btn.onclick = (e) => {
            e.stopPropagation();
            const idx = +btn.dataset.idx;
            const container = list.querySelector(`.vc-media-events[data-idx="${idx}"]`);
            if (!container) return;
            if (container.style.display === 'none') {
                container.innerHTML = (chains[idx].events || []).map(buildEventLineHTML).join('');
                container.style.display = 'block';
                btn.textContent = '收起';
            } else {
                container.style.display = 'none';
                btn.textContent = '展开事件';
            }
        };
    });
    list.querySelectorAll('.vc-analyze-auth').forEach(btn => {
        btn.onclick = (e) => {
            e.stopPropagation();
            const idx = +btn.dataset.idx;
            const url = btn.dataset.url;
            const container = list.querySelector(`.vc-auth-result[data-idx="${idx}"]`);
            if (!container) return;
            if (container.style.display !== 'none' && container.dataset.loaded === '1') {
                container.style.display = 'none';
                btn.textContent = '🔍 校验头';
                return;
            }
            container.style.display = 'block';
            container.innerHTML = '<div style="font-size:10px;color:#f59e0b;">⏳ 分析中…</div>';
            btn.textContent = '⏳';
            chrome.runtime.sendMessage({ action: 'ANALYZE_REQUEST_AUTH', url }, (res) => {
                btn.textContent = '🔍 校验头';
                if (!res) { container.innerHTML = '<div style="font-size:10px;color:#ef4444;">❌ 后台无响应</div>'; return; }
                if (res.error) {
                    container.innerHTML = `<div style="font-size:10px;color:#ef4444;">❌ ${escHtml(res.error)} · 该请求未在抓包列表中(可能视频 URL 是从 API 响应解析得到,浏览器尚未发起直接请求)</div>`;
                    return;
                }
                container.dataset.loaded = '1';
                container.innerHTML = renderAuthAnalysis(res);
                bindAuthAnalysisEvents(container);
            });
        };
    });
}

// ══════════════════════════════════════════════════════════════════
// 🔍 校验头溯源 — 渲染分析结果
// ══════════════════════════════════════════════════════════════════
const VERDICT_META = {
    BROWSER_AUTO:      { icon:'🌐', color:'#6b7280', label:'浏览器自动' },
    FROM_SET_COOKIE:   { icon:'🍪', color:'#10b981', label:'Set-Cookie 下发' },
    FROM_RESPONSE_BODY:{ icon:'📥', color:'#0984e3', label:'响应体透传' },
    JS_CRYPTO:         { icon:'🔐', color:'#8b5cf6', label:'JS 加密产物' },
    CLIENT_TRACKER:    { icon:'📊', color:'#f59e0b', label:'统计 SDK 生成' },
    UNKNOWN:           { icon:'❓', color:'#9ca3af', label:'未知来源' },
    UNKNOWN_JS:        { icon:'⚙️', color:'#e17055', label:'JS 设置(未溯源)' }
};

function renderAuthAnalysis(res) {
    const { headers=[], cookies=[], tally={} } = res;
    const tallyBadges = Object.entries(tally).filter(([,v])=>v>0).map(([k,v]) => {
        const meta = VERDICT_META[k] || VERDICT_META.UNKNOWN;
        return `<span style="background:${meta.color}20;color:${meta.color};border:1px solid ${meta.color}40;font-size:9px;padding:1px 6px;border-radius:10px;font-weight:600;" title="${escHtml(meta.label)}">${meta.icon} ${v}</span>`;
    }).join(' ');
    let h = `<div style="display:flex;align-items:center;gap:5px;margin-bottom:8px;flex-wrap:wrap;">
        <b style="font-size:11px;color:#1a1d2e;">🔍 校验数据溯源</b>
        ${tallyBadges}
    </div>`;
    if (cookies.length) {
        h += `<div style="margin-bottom:6px;"><div style="font-size:10px;color:#6b7280;font-weight:600;margin-bottom:3px;">🍪 Cookie (${cookies.length} 项)</div>`;
        h += cookies.map(renderAuthRow).join('');
        h += '</div>';
    }
    const nonAuto = headers.filter(h => h.verdict !== 'BROWSER_AUTO');
    const autoHdrs = headers.filter(h => h.verdict === 'BROWSER_AUTO');
    if (nonAuto.length) {
        h += `<div style="margin-bottom:6px;"><div style="font-size:10px;color:#6b7280;font-weight:600;margin-bottom:3px;">⚡ 关键自定义头 (${nonAuto.length})</div>`;
        h += nonAuto.map(renderAuthRow).join('');
        h += '</div>';
    }
    if (autoHdrs.length) {
        h += `<details style="margin-top:6px;"><summary style="font-size:10px;color:#9ca3af;cursor:pointer;">🌐 浏览器自动头 (${autoHdrs.length}) · 展开</summary><div style="margin-top:4px;">`;
        h += autoHdrs.map(renderAuthRow).join('');
        h += '</div></details>';
    }
    return h;
}

function renderAuthRow(item) {
    const meta = VERDICT_META[item.verdict] || VERDICT_META.UNKNOWN;
    const d = item.details || {};
    let sub = '';
    if (item.verdict === 'FROM_SET_COOKIE') {
        sub = `<div style="font-size:9px;color:#10b981;margin-top:2px;word-break:break-all;">↳ 由 <span style="font-family:monospace;">${escHtml((d.setFromUrl||'').substring(0,70))}</span> 在 ${escHtml(d.time||'')} 下发</div>`;
    } else if (item.verdict === 'FROM_RESPONSE_BODY') {
        const s0 = d.sources && d.sources[0];
        if (s0) sub = `<div style="font-size:9px;color:#0984e3;margin-top:2px;word-break:break-all;">↳ 命中 <span style="font-family:monospace;">${escHtml((s0.url||'').substring(0,70))}</span> [${escHtml(s0.source||'')}]${s0.preview?' · '+escHtml(s0.preview.substring(0,40)):''}</div>`;
    } else if (item.verdict === 'JS_CRYPTO') {
        const f0 = (d.frames||[])[0];
        const locStr = f0 ? `${(f0.file||'').split('/').pop()}:${f0.line}:${f0.col}` : '';
        sub = `<div style="font-size:9px;color:#8b5cf6;margin-top:2px;">↳ <b>${escHtml(d.algo||'')}</b> · ${escHtml(d.hint||'')}${f0?` · <span class="auth-src-link" data-file="${escHtml(f0.file)}" data-line="${f0.line}" data-col="${f0.col}" style="cursor:pointer;text-decoration:underline;">${escHtml(locStr)}</span>`:''}</div>`;
    } else if (item.verdict === 'CLIENT_TRACKER') {
        sub = `<div style="font-size:9px;color:#f59e0b;margin-top:2px;">↳ ${escHtml(d.tracker||'')} · ${escHtml(d.hint||'')}</div>`;
    } else if (item.verdict === 'UNKNOWN' || item.verdict === 'UNKNOWN_JS') {
        sub = `<div style="font-size:9px;color:#9ca3af;margin-top:2px;">↳ ${escHtml(d.hint||'')}</div>`;
    }
    return `<div style="padding:4px 6px;background:${meta.color}08;border-left:2px solid ${meta.color};border-radius:3px;margin-bottom:3px;">
        <div style="display:flex;gap:4px;align-items:center;font-size:10px;flex-wrap:wrap;">
            <span style="flex-shrink:0;">${meta.icon}</span>
            <code style="background:#f1f5f9;padding:0 5px;border-radius:3px;color:#1a1d2e;font-size:10px;">${escHtml(item.name)}</code>
            <span style="font-family:monospace;color:#6b7280;font-size:9px;flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="${escHtml(item.value)}">${escHtml(item.value)}</span>
            <span style="color:${meta.color};font-size:9px;font-weight:600;flex-shrink:0;">${meta.label}</span>
        </div>
        ${sub}
    </div>`;
}

function bindAuthAnalysisEvents(container) {
    container.querySelectorAll('.auth-src-link').forEach(el => {
        el.addEventListener('click', (e) => {
            e.stopPropagation();
            const file = el.dataset.file;
            const line = +el.dataset.line || 1;
            const col = +el.dataset.col || 1;
            if (file) showSourceAt(file, line, col);
        });
    });
}

function renderVcScriptsList() {
    const list = panelRoot.getElementById('vc-scripts-list');
    const cnt = panelRoot.getElementById('vc-scripts-count');
    if (!list) return;
    const filter = videoChainScriptsFilter.toLowerCase();
    const arr = [...scriptRegistry.values()]
        .filter(s => {
            if (filter && !(s.url.toLowerCase().includes(filter))) return false;
            if (videoChainScriptsOnlyActive && s.cryptoCount + s.decryptCount + s.requestCount + s.signalCount === 0) return false;
            return true;
        })
        .sort((a, b) => (b.cryptoCount + b.decryptCount * 2 + b.signalCount) - (a.cryptoCount + a.decryptCount * 2 + a.signalCount));
    if (cnt) cnt.textContent = scriptRegistry.size;
    if (!arr.length) {
        list.innerHTML = '<div style="color:#9ca3af; font-size:11px; padding:10px; text-align:center;">暂无脚本记录</div>';
        return;
    }
    list.innerHTML = arr.map((s, idx) => {
        const active = (s.cryptoCount + s.decryptCount + s.signalCount) > 0;
        const baseName = s.url.split('?')[0].split('/').pop() || s.url;
        const badges = [];
        if (s.cryptoCount) badges.push(`<span style="background:#8b5cf6;color:#fff;font-size:9px;padding:1px 7px;border-radius:10px;">🔥 加密 ${s.cryptoCount}</span>`);
        if (s.decryptCount) badges.push(`<span style="background:#d63031;color:#fff;font-size:9px;padding:1px 7px;border-radius:10px;">🔓 解密 ${s.decryptCount}</span>`);
        if (s.requestCount) badges.push(`<span style="background:#0984e3;color:#fff;font-size:9px;padding:1px 7px;border-radius:10px;">📡 网络 ${s.requestCount}</span>`);
        if (s.signalCount) badges.push(`<span style="background:#f59e0b;color:#fff;font-size:9px;padding:1px 7px;border-radius:10px;">✍️ 签名 ${s.signalCount}</span>`);
        if (s.inferred) badges.push(`<span style="background:#9ca3af;color:#fff;font-size:9px;padding:1px 7px;border-radius:10px;">推断</span>`);
        return `<div class="vc-script-card" style="background:${active?'#fff':'rgba(255,255,255,0.6)'};border:1px solid ${active?'#c7d0fb':'#e4e7f0'};border-left:3px solid ${active?'#5b6ef5':'#9ca3af'};border-radius:6px;padding:8px 10px;margin-bottom:5px;">
            <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;">
                <span style="font-family:monospace;font-size:11px;font-weight:600;color:#1a1d2e;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1;min-width:100px;" title="${escHtml(s.url)}">${escHtml(baseName)}</span>
                ${badges.join(' ')}
                <button class="vc-open-src btn-small" data-url="${escHtml(s.url)}" style="background:#6c5ce7;padding:2px 8px;font-size:9px;">📄 源码</button>
                ${active ? `<button class="vc-expand-script btn-small" data-url="${escHtml(s.url)}" style="background:#0984e3;padding:2px 8px;font-size:9px;">详情</button>` : ''}
            </div>
            <div style="font-family:monospace;font-size:9px;color:#9ca3af;margin-top:2px;word-break:break-all;">${escHtml(s.url)}</div>
            <div class="vc-script-events" data-url="${escHtml(s.url)}" style="display:none;margin-top:6px;padding-top:6px;border-top:1px dashed #e4e7f0;"></div>
        </div>`;
    }).join('');
    list.querySelectorAll('.vc-open-src').forEach(btn => {
        btn.onclick = (e) => { e.stopPropagation(); showSourceAt(btn.dataset.url, 1, 1); };
    });
    list.querySelectorAll('.vc-expand-script').forEach(btn => {
        btn.onclick = (e) => {
            e.stopPropagation();
            const container = list.querySelector(`.vc-script-events[data-url="${btn.dataset.url.replace(/"/g,'&quot;')}"]`);
            if (!container) return;
            if (container.style.display === 'none') {
                const evs = scriptEventsByUrl.get(btn.dataset.url) || [];
                container.innerHTML = evs.slice(0, 30).map(rec => {
                    const iconMap = { CRYPTO_REPORT:'🔐', DECRYPT_FOUND:'🔓', PARAM_TRACE:'📊', PARAM_CRYPTO_FOUND:'🧪', SIGN_FIELD_FOUND:'✍️', FUNC_TRACE:'🔭' };
                    return `<div style="font-size:10px;padding:4px 0;border-bottom:1px dashed #eee;">
                        <span>${iconMap[rec.type]||''} ${rec.type}</span>
                        <span style="color:#6b7280;font-family:monospace;margin-left:6px;">${escHtml(rec.summary.substring(0,100))}</span>
                        ${renderFrames(rec.frames, 2)}
                    </div>`;
                }).join('') || '<div style="font-size:10px;color:#9ca3af;">无事件</div>';
                container.style.display = 'block';
                btn.textContent = '收起';
            } else {
                container.style.display = 'none';
                btn.textContent = '详情';
            }
        };
    });
}

function renderVcEvents(events) {
    const list = panelRoot.getElementById('vc-events-list');
    const cnt = panelRoot.getElementById('vc-events-count');
    if (!list) return;
    let filtered = events || [];
    if (videoChainEventsFilter !== 'ALL') {
        filtered = filtered.filter(e => e.step === videoChainEventsFilter);
    }
    if (cnt) cnt.textContent = filtered.length;
    if (!filtered.length) {
        list.innerHTML = '<div style="color:#9ca3af; font-size:11px; padding:10px; text-align:center;">暂无事件</div>';
        return;
    }
    // 倒序展示最近 100 条
    const shown = filtered.slice(-100).reverse();
    list.innerHTML = shown.map(buildEventLineHTML).join('');
}

function buildEventLineHTML(evt) {
    const icons = { PARAM_SOURCE:'📊', CRYPTO_CALL:'🔐', SIGN_FIELD:'✍️', PARAM_CRYPTO:'🧪', REQUEST_SENT:'📡', RESPONSE_RECV:'✅', URL_EXTRACT:'🎯', DECRYPT:'🔓', MEDIA_FOUND:'📺' };
    const labels = { PARAM_SOURCE:'参数溯源', CRYPTO_CALL:'加密调用', SIGN_FIELD:'签名字段', PARAM_CRYPTO:'参数加密', REQUEST_SENT:'请求发出', RESPONSE_RECV:'响应接收', URL_EXTRACT:'URL提取', DECRYPT:'解密还原', MEDIA_FOUND:'媒体捕获' };
    const colors = { PARAM_SOURCE:'#f39c12', CRYPTO_CALL:'#8b5cf6', SIGN_FIELD:'#a29bfe', PARAM_CRYPTO:'#e17055', REQUEST_SENT:'#0984e3', RESPONSE_RECV:'#00b894', URL_EXTRACT:'#fdcb6e', DECRYPT:'#d63031', MEDIA_FOUND:'#fdcb6e' };
    const icon = icons[evt.step] || '⚪';
    const label = labels[evt.step] || evt.step;
    const color = colors[evt.step] || '#636e72';
    const time = evt.time ? new Date(evt.time).toLocaleTimeString() : '';
    let detail = '';
    if (evt.step === 'PARAM_SOURCE') detail = `参数 <b>${escHtml(evt.key||'')}</b>=${escHtml((evt.value||'').substring(0,40))} → <span style="color:#e17055;">${escHtml(evt.verdict||'?')}</span>`;
    else if (evt.step === 'CRYPTO_CALL') detail = `<b>${escHtml(evt.algo||'')}</b> 输入:<span style="color:#d63031;">${escHtml((evt.plaintext||'').substring(0,60))}</span> 密钥:<span style="color:#0984e3;">${escHtml((evt.key||'').substring(0,40))}</span>`;
    else if (evt.step === 'SIGN_FIELD') detail = `<b style="color:#a29bfe;">${escHtml(evt.field||'')}</b>=${escHtml((evt.value||'').substring(0,50))}`;
    else if (evt.step === 'PARAM_CRYPTO') detail = `<b>${escHtml(evt.key||'')}</b> 类型:${(evt.detected||[]).join(',')} ${evt.decoded && evt.decoded.length ? '→ ' + escHtml(evt.decoded[0].substring(0,40)) : ''}`;
    else if (evt.step === 'REQUEST_SENT') detail = `<span style="color:#e17055;font-weight:bold;">${escHtml(evt.method||'GET')}</span> <span style="color:#0984e3;word-break:break-all;">${escHtml((evt.url||'').substring(0,80))}</span>`;
    else if (evt.step === 'RESPONSE_RECV') detail = `<b>HTTP ${evt.status||'?'}</b> ${escHtml(evt.type||'')} ${evt.duration?evt.duration+'ms':''} <span style="color:#9ca3af;word-break:break-all;">${escHtml((evt.url||'').substring(0,60))}</span>`;
    else if (evt.step === 'URL_EXTRACT') detail = `字段:<b style="color:#fdcb6e;">${escHtml(evt.field||'')}</b> → <span style="color:#00b894;word-break:break-all;">${escHtml((evt.url||'').substring(0,80))}</span>`;
    else if (evt.step === 'DECRYPT') detail = `<b>${escHtml(evt.algo||'')}</b> → <span style="color:#00b894;">${escHtml((evt.plaintext||'').substring(0,80))}</span>`;
    else if (evt.step === 'MEDIA_FOUND') detail = `<span style="color:#fdcb6e;word-break:break-all;font-weight:bold;">${escHtml((evt.url||'').substring(0,100))}</span>`;
    return `<div class="vc-event-line" style="padding:5px 8px;border-bottom:1px solid #f1f5f9;font-size:10px;">
        <div style="display:flex;align-items:center;gap:6px;">
            <span style="width:20px;text-align:center;">${icon}</span>
            <span style="min-width:60px;font-weight:700;color:${color};">${label}</span>
            <span style="flex:1;overflow:hidden;font-family:monospace;" title="${escHtml(JSON.stringify(evt).substring(0,200))}">${detail}</span>
            <span style="color:#9ca3af;font-size:9px;flex-shrink:0;">${time}</span>
        </div>
        ${evt.frames && evt.frames.length ? renderFrames(evt.frames, 2) : ''}
    </div>`;
}

// ── 轮询 ──
function startVideoChainPolling() {
    stopVideoChainPolling();
    const interval = videoChainMode === 'session' ? 1500 : 2000;
    videoChainTimer = setInterval(renderVideoChain, interval);
}
function stopVideoChainPolling() {
    if (videoChainTimer) { clearInterval(videoChainTimer); videoChainTimer = null; }
}

// ── 源码查看器 ──
function showSourceAt(fileUrl, line, col) {
    if (!panelRoot) return;
    const modal = panelRoot.getElementById('source-viewer-modal');
    const titleEl = panelRoot.getElementById('sv-title');
    const locEl = panelRoot.getElementById('sv-loc');
    const codeEl = panelRoot.getElementById('sv-code');
    if (!modal || !codeEl) return;
    const baseName = (fileUrl || '').split('?')[0].split('/').pop() || fileUrl;
    titleEl.textContent = baseName;
    titleEl.title = fileUrl;
    locEl.textContent = (line ? `:${line}` : '') + (col ? `:${col}` : '');
    codeEl.dataset.fileUrl = fileUrl;
    codeEl.dataset.targetLine = String(line || 1);
    codeEl.innerHTML = '<div style="padding:14px;color:#f59e0b;">⏳ 加载源码中...</div>';
    modal.style.display = 'block';
    chrome.runtime.sendMessage({ action: 'GET_SOURCE_BY_URL', url: fileUrl }, (res) => {
        if (!res) {
            codeEl.innerHTML = '<div style="padding:14px;color:#ef4444;">❌ Service Worker 无响应</div>';
            return;
        }
        if (!res.found) {
            const reason = res.reason === 'body_not_cached' ? '响应体未缓存(请刷新页面让该 JS 重新加载)'
                         : res.reason === 'url_not_in_log' ? 'URL 未在抓包记录中(可能扩展加载前已下载,或为内联脚本)'
                         : res.reason || '未知原因';
            codeEl.innerHTML = `<div style="padding:14px;">
                <div style="color:#ef4444;margin-bottom:10px;">❌ 源码不可用</div>
                <div style="color:#9ca3af;font-size:11px;">原因:${escHtml(reason)}</div>
                <div style="color:#9ca3af;font-size:11px;margin-top:6px;">URL:<span style="font-family:monospace;">${escHtml(fileUrl)}</span></div>
                <div style="color:#6b7280;font-size:11px;margin-top:10px;">💡 可点击「🔗 新标签打开」在浏览器查看</div>
            </div>`;
            return;
        }
        const body = res.body || '';
        const ext = (fileUrl.split('?')[0].split('.').pop() || '').toLowerCase();
        const langMap = { js: 'javascript', mjs: 'javascript', cjs: 'javascript', ts: 'typescript', json: 'json', css: 'css', html: 'html', htm: 'html' };
        const lang = langMap[ext] || 'javascript';
        // 整体高亮后按行切分
        let htmlLines;
        if (window.Prism && window.Prism.languages[lang]) {
            try {
                htmlLines = window.Prism.highlight(body, window.Prism.languages[lang], lang).split('\n');
            } catch(e) { htmlLines = body.split('\n').map(escHtml); }
        } else {
            htmlLines = body.split('\n').map(escHtml);
        }
        const totalLines = htmlLines.length;
        // 行号 + 目标行高亮
        const lineWidth = String(totalLines).length + 1;
        const out = htmlLines.map((src, i) => {
            const n = i + 1;
            const isTarget = n === line;
            const bg = isTarget ? 'background:rgba(245,158,11,0.22);border-left:3px solid #f59e0b;' : '';
            return `<div data-ln="${n}" style="${bg}padding-left:4px;">` +
                `<span style="color:#4b5563;display:inline-block;width:${lineWidth*8}px;text-align:right;padding-right:10px;user-select:none;border-right:1px solid #2d3250;margin-right:8px;">${n}</span>` +
                `<span style="white-space:pre;">${src}</span></div>`;
        }).join('');
        codeEl.innerHTML = out;
        // 滚动居中目标行
        if (line) {
            setTimeout(() => {
                const tgt = codeEl.querySelector(`[data-ln="${line}"]`);
                if (tgt) tgt.scrollIntoView({ block: 'center' });
            }, 30);
        }
    });
}

// ── 视频链路面板按钮绑定 ──
function bindVideoChainEvents() {
    if (!panelRoot) return;
    const root = panelRoot;

    // 🎯 使用 URL 进入
    const enterInput = root.getElementById('vc-enter-url');
    const enterGoBtn = root.getElementById('vc-enter-go-btn');
    const enterCurrentBtn = root.getElementById('vc-enter-current-btn');
    const enterHint = root.getElementById('vc-enter-hint');
    function doEnter() {
        let url = (enterInput.value || '').trim();
        if (!url) { enterHint.textContent = '❌ 请输入 URL'; enterHint.style.color = '#ef4444'; return; }
        if (!/^https?:\/\//i.test(url)) url = 'https://' + url;
        enterHint.style.color = '#f59e0b';
        enterHint.textContent = '⏳ attaching debugger → 清空会话 → 导航中...';
        if (enterGoBtn) { enterGoBtn.disabled = true; enterGoBtn.textContent = '⏳'; }
        chrome.runtime.sendMessage({ action: 'ENTER_URL_IN_TAB', url: url }, (res) => {
            if (enterGoBtn) { enterGoBtn.disabled = false; enterGoBtn.textContent = '🚀 进入'; }
            if (!res) {
                enterHint.style.color = '#ef4444';
                enterHint.textContent = '❌ Service Worker 无响应,请重试';
                return;
            }
            if (res.error) {
                enterHint.style.color = '#ef4444';
                enterHint.textContent = '❌ ' + res.error;
                return;
            }
            enterHint.style.color = '#10b981';
            enterHint.textContent = '✅ debugger 已 attach 且导航已下发,全链路抓取进行中';
            // 清空本地状态,保持与 background 同步
            scriptRegistry.clear();
            scriptEventsByUrl.clear();
            logsMap.clear();
            setTimeout(renderVideoChain, 500);
        });
    }
    if (enterGoBtn) enterGoBtn.onclick = (e) => { e.stopPropagation(); doEnter(); };
    if (enterInput) enterInput.onkeydown = (e) => { if (e.key === 'Enter') { e.preventDefault(); doEnter(); } };
    if (enterCurrentBtn) enterCurrentBtn.onclick = (e) => {
        e.stopPropagation();
        enterInput.value = window.location.href;
    };

    // 模式切换
    root.querySelectorAll('.vc-mode').forEach(btn => {
        btn.onclick = (e) => {
            e.stopPropagation();
            root.querySelectorAll('.vc-mode').forEach(b => {
                b.classList.remove('active');
                b.style.background = 'transparent';
                b.style.color = '#6b7280';
            });
            btn.classList.add('active');
            btn.style.background = '#5b6ef5';
            btn.style.color = '#fff';
            videoChainMode = btn.dataset.mode;
            renderVideoChain();
            startVideoChainPolling();
        };
    });

    // 工具栏按钮
    root.getElementById('vc-refresh-btn').onclick = (e) => { e.stopPropagation(); renderVideoChain(); };
    root.getElementById('vc-reset-session-btn').onclick = (e) => {
        e.stopPropagation();
        if (!confirm('重置视频会话起点为此刻?(不清除历史事件,仅重新划分时间线起始)')) return;
        chrome.runtime.sendMessage({ action: 'RESET_VIDEO_SESSION' }, () => {
            scriptRegistry.clear();
            scriptEventsByUrl.clear();
            renderVideoChain();
        });
    };
    root.getElementById('vc-clear-btn').onclick = (e) => {
        e.stopPropagation();
        if (!confirm('清空当前会话的所有事件与脚本注册?')) return;
        scriptRegistry.clear();
        scriptEventsByUrl.clear();
        chrome.runtime.sendMessage({ action: 'CHAIN_CLEAR_ALL' }, () => renderVideoChain());
    };
    root.getElementById('vc-export-btn').onclick = (e) => {
        e.stopPropagation();
        chrome.runtime.sendMessage({ action: 'CHAIN_GET_STATE' }, (state) => {
            const exportData = {
                sessionStart: state?.sessionStart,
                sessionStartUrl: state?.sessionStartUrl,
                mode: videoChainMode,
                chains: state?.chains || [],
                events: videoChainMode === 'session' ? (state?.sessionEvents || []) : (state?.window || []),
                scripts: [...scriptRegistry.values()].map(s => ({ ...s, mediaRefs: [...s.mediaRefs] })),
                scriptEvents: Object.fromEntries([...scriptEventsByUrl.entries()].map(([k, v]) => [k, v.slice(0, 50)])),
                exportedAt: new Date().toISOString()
            };
            const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url; a.download = `phantom-videochain-${Date.now()}.json`;
            document.body.appendChild(a); a.click(); a.remove();
            URL.revokeObjectURL(url);
        });
    };

    // 脚本过滤
    const scriptsFilter = root.getElementById('vc-scripts-filter');
    if (scriptsFilter) {
        scriptsFilter.oninput = (e) => {
            videoChainScriptsFilter = e.target.value;
            renderVcScriptsList();
        };
    }
    const onlyActive = root.getElementById('vc-scripts-only-active');
    if (onlyActive) {
        onlyActive.onchange = (e) => {
            videoChainScriptsOnlyActive = e.target.checked;
            renderVcScriptsList();
        };
    }

    // 事件过滤
    const eventsFilter = root.getElementById('vc-events-filter');
    if (eventsFilter) {
        eventsFilter.onchange = (e) => {
            videoChainEventsFilter = e.target.value;
            renderVideoChain();
        };
    }

    // 源码查看器按钮
    root.getElementById('sv-close').onclick = (e) => { e.stopPropagation(); root.getElementById('source-viewer-modal').style.display = 'none'; };
    root.getElementById('sv-goto-target').onclick = (e) => {
        e.stopPropagation();
        const codeEl = root.getElementById('sv-code');
        const line = +codeEl.dataset.targetLine || 1;
        const tgt = codeEl.querySelector(`[data-ln="${line}"]`);
        if (tgt) tgt.scrollIntoView({ block: 'center' });
    };
    root.getElementById('sv-copy-line').onclick = (e) => {
        e.stopPropagation();
        const codeEl = root.getElementById('sv-code');
        const line = +codeEl.dataset.targetLine || 1;
        const tgt = codeEl.querySelector(`[data-ln="${line}"]`);
        if (tgt) navigator.clipboard.writeText(tgt.innerText.replace(/^\s*\d+\s*/, ''));
    };
    root.getElementById('sv-copy-all').onclick = (e) => {
        e.stopPropagation();
        const codeEl = root.getElementById('sv-code');
        navigator.clipboard.writeText(codeEl.innerText);
    };
    root.getElementById('sv-open-devtools').onclick = (e) => {
        e.stopPropagation();
        const codeEl = root.getElementById('sv-code');
        const url = codeEl.dataset.fileUrl;
        if (url) window.open(url, '_blank');
    };
    const svSearch = root.getElementById('sv-search');
    if (svSearch) {
        svSearch.onkeydown = (e) => {
            if (e.key !== 'Enter') return;
            e.stopPropagation();
            const kw = svSearch.value.trim();
            if (!kw) return;
            const codeEl = root.getElementById('sv-code');
            const lines = codeEl.querySelectorAll('[data-ln]');
            let lastHit = +svSearch.dataset.lastLn || 0;
            for (let i = 0; i < lines.length; i++) {
                const ln = +lines[i].dataset.ln;
                if (ln <= lastHit) continue;
                if (lines[i].innerText.toLowerCase().includes(kw.toLowerCase())) {
                    lines[i].scrollIntoView({ block: 'center' });
                    lines[i].style.outline = '2px solid #f59e0b';
                    setTimeout(() => { lines[i].style.outline = ''; }, 1500);
                    svSearch.dataset.lastLn = ln;
                    return;
                }
            }
            svSearch.dataset.lastLn = 0; // 循环回到顶
        };
    }

    // 背景点击关闭源码查看器
    const svModal = root.getElementById('source-viewer-modal');
    if (svModal) {
        svModal.addEventListener('click', (e) => { if (e.target === svModal) svModal.style.display = 'none'; });
        // 拖拽
        const svHeader = svModal.querySelector('.modal-header');
        if (svHeader) makeDraggable(svModal.querySelector('.modal-content'), svHeader);
    }

    // .sv-link 全局代理:点击栈帧跳源码
    root.addEventListener('click', (e) => {
        const t = e.target.closest('.sv-link');
        if (!t) return;
        e.stopPropagation();
        const file = t.dataset.file;
        const line = +t.dataset.line || 1;
        const col = +t.dataset.col || 1;
        if (file) showSourceAt(file, line, col);
    });

    // 🛡️ 预挂钩面板绑定 + 状态轮询
    bindPreHookEvents();
}

// ══════════════════════════════════════════════════════════════════
// 🛡️ 预挂钩引擎 UI 绑定
// ══════════════════════════════════════════════════════════════════
function bindPreHookEvents() {
    if (!panelRoot) return;
    const root = panelRoot;
    const badge = root.getElementById('prehook-badge');
    const enableCb = root.getElementById('prehook-enable');
    const pauseCb = root.getElementById('prehook-pause');
    const statusEl = root.getElementById('prehook-status');

    function refreshStatus() {
        chrome.runtime.sendMessage({ action: 'GET_PREHOOK_STATUS' }, (r) => {
            if (!r) return;
            if (enableCb) enableCb.checked = !!r.enabled;
            if (pauseCb) pauseCb.checked = !!r.pauseChild;
            if (badge) {
                badge.textContent = '🛡️ ' + (r.attachedTabs || 0);
                badge.title = `预挂钩 ${r.enabled?'已启用':'已禁用'} · 已 attach ${r.attachedTabs} 个 tab · webRequest 早期记录 ${r.earlyRequests} 条`;
                badge.style.background = r.enabled ? 'rgba(16,185,129,0.25)' : 'rgba(239,68,68,0.25)';
                badge.style.borderColor = r.enabled ? 'rgba(16,185,129,0.5)' : 'rgba(239,68,68,0.5)';
            }
            if (statusEl) {
                statusEl.innerHTML = `
                    <div><b style="color:${r.enabled?'#10b981':'#ef4444'};">●</b> ${r.enabled ? '预挂钩已启用' : '预挂钩已禁用'}</div>
                    <div style="color:#6b7280;">已 attach 标签页:<b>${r.attachedTabs}</b></div>
                    <div style="color:#6b7280;">webRequest 早期请求:<b>${r.earlyRequests}</b> 条(兜底观察池)</div>
                    <div style="color:#6b7280;">子 Target 暂停:<b>${r.pauseChild?'开':'关'}</b></div>`;
            }
        });
    }

    if (badge) {
        badge.onclick = (e) => {
            e.stopPropagation();
            // 点击 badge 跳到设置 Tab
            root.querySelectorAll('.tab, .content').forEach(el => { el.classList.remove('active'); el.style.display = ''; });
            root.querySelector('[data-target="settings-view"]').classList.add('active');
            root.getElementById('settings-view').classList.add('active');
            refreshStatus();
        };
    }

    if (enableCb) {
        enableCb.onchange = (e) => {
            chrome.runtime.sendMessage({ action: 'SET_PREHOOK', enabled: e.target.checked }, refreshStatus);
        };
    }
    if (pauseCb) {
        pauseCb.onchange = (e) => {
            chrome.runtime.sendMessage({ action: 'SET_PREHOOK', pauseChild: e.target.checked }, refreshStatus);
        };
    }

    // 每 5 秒刷新一次状态(更新 attached tab 数)
    refreshStatus();
    setInterval(refreshStatus, 5000);
}

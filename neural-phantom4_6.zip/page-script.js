// page-script.js - Neural Phantom 4.1 绝对完整版 (已打入严格模式修复补丁)

(function() {
    // 🍵 茶室核心变量 (闭包保护，外部无法访问)
    let _dynamicHandler = null;
    let _mockRules = [];
    let _localFileRules = [];      // 本地文件替换规则
    let _breakpointEnabled = false;
    let _breakpointFilter = '';
    let _breakpointResolvers = {};
    const _replaceMap = {};

    // 生成唯一 ID，用于断点请求的标识
    const generateId = () => Date.now().toString(36) + Math.random().toString(36).substr(2, 5);

    // ============================================================
    // 💀 禁忌技术：原生伪装 (Native Code Spoofing)
    // 确保劫持后的函数在被检测时返回 [native code]，防止被网页反调试检测
    // ============================================================
    function makeNative(mockFunc, originalFunc) {
        const proxy = new Proxy(mockFunc, {
            apply(target, thisArg, args) { return Reflect.apply(target, thisArg, args); },
            construct(target, args) { return Reflect.construct(target, args); },
            get(target, prop) {
                if (prop === 'toString') return originalFunc.toString.bind(originalFunc);
                return Reflect.get(target, prop);
            }
        });
        const nativeString = originalFunc.toString();
        Object.defineProperty(proxy, 'toString', {
            value: function() { return nativeString; },
            writable: true, configurable: true
        });
        return proxy;
    }

    // ============================================================
    // 📍 结构化栈帧解析(供链路追踪 file:line:col 跳转使用)
    // ============================================================
    const _PHANTOM_STACK_RE = /(?:at\s+)?(?:(.+?)\s+\()?((?:https?|file):\/\/[^\s)]+?):(\d+):(\d+)\)?/;
    function parsePhantomStack(stackStr, depth) {
        depth = depth || 0;
        const lines = (stackStr || '').split('\n');
        const out = [];
        for (let i = depth + 1; i < lines.length && out.length < 6; i++) {
            const line = lines[i].trim();
            if (!line) continue;
            if (line.indexOf('page-script.js') !== -1 || line.indexOf('inject.js') !== -1) continue;
            if (line.indexOf('chrome-extension://') !== -1 || line.indexOf('moz-extension://') !== -1) continue;
            const m = line.match(_PHANTOM_STACK_RE);
            if (!m) continue;
            out.push({ fn: (m[1] || '<anon>').trim(), file: m[2], line: +m[3], col: +m[4] });
        }
        return out;
    }

    // ============================================================
    // 🕵️‍♂️ 加密审计模块 (Crypto Audit)
    // 实时拦截前端网页的 AES 加密明文与密钥
    // ============================================================
    // ============================================================
    // 🔐 加密审计模块 v2 — 全套 Hook：CryptoJS + WebCrypto + 签名字段嗅探
    // ============================================================

    function reportCrypto(algo, plaintext, keyInfo, extra, traceDepth) {
        traceDepth = traceDepth || 2;
        let traceStr = 'unknown';
        let frames = [];
        try {
            const stack = new Error().stack;
            if (stack) {
                traceStr = stack.split('\n').slice(traceDepth, traceDepth + 3).join(' | ');
                frames = parsePhantomStack(stack, traceDepth);
            }
        } catch (e) {}
        window.postMessage({ type: 'CRYPTO_REPORT', algo: algo, in: String(plaintext).substring(0, 500), key: String(keyInfo).substring(0, 200), trace: traceStr, frames: frames, extra: extra || '' }, '*');
    }

    // ── A. CryptoJS 全套 Hook ──
    const hookCryptoJS = () => {
        if (!window.CryptoJS) return;
        const CJ = window.CryptoJS;
        if (CJ.AES && CJ.AES.encrypt && !CJ.AES.encrypt._isHooked) {
            const _orig = CJ.AES.encrypt;
            CJ.AES.encrypt = makeNative(function(msg, key, cfg) {
                reportCrypto('CryptoJS.AES.encrypt', msg, key);
                return _orig.apply(this, arguments);
            }, _orig);
            CJ.AES.encrypt._isHooked = true;
        }
        ['HmacSHA1','HmacSHA256','HmacSHA512','HmacMD5'].forEach(function(fn) {
            if (CJ[fn] && !CJ[fn]._isHooked) {
                const _orig = CJ[fn];
                CJ[fn] = makeNative(function(message, key) {
                    reportCrypto('CryptoJS.' + fn, message, key);
                    return _orig.apply(this, arguments);
                }, _orig);
                CJ[fn]._isHooked = true;
            }
        });
        ['MD5','SHA1','SHA256','SHA512'].forEach(function(fn) {
            if (CJ[fn] && !CJ[fn]._isHooked) {
                const _orig = CJ[fn];
                CJ[fn] = makeNative(function(message) {
                    reportCrypto('CryptoJS.' + fn, message, '(hash, no key)');
                    return _orig.apply(this, arguments);
                }, _orig);
                CJ[fn]._isHooked = true;
            }
        });
    };

    // ── B. WebCrypto API Hook（原生 crypto.subtle）──
    const hookWebCrypto = () => {
        if (!window.crypto || !window.crypto.subtle || window.crypto.subtle._isHooked) return;
        const _subtle = window.crypto.subtle;
        const _origSign = _subtle.sign.bind(_subtle);
        _subtle.sign = function(algorithm, key, data) {
            return _origSign(algorithm, key, data).then(function(result) {
                try {
                    const algoName = typeof algorithm === 'string' ? algorithm : algorithm.name;
                    const preview = Array.from(new Uint8Array(data).slice(0, 32)).map(function(b){return b.toString(16).padStart(2,'0');}).join('');
                    reportCrypto('WebCrypto.sign [' + algoName + ']', 'data[' + data.byteLength + ']: ' + preview + '...', 'CryptoKey type=' + key.type, '', 3);
                } catch (e) {}
                return result;
            });
        };
        const _origEncrypt = _subtle.encrypt.bind(_subtle);
        _subtle.encrypt = function(algorithm, key, data) {
            return _origEncrypt(algorithm, key, data).then(function(result) {
                try {
                    const algoName = typeof algorithm === 'string' ? algorithm : algorithm.name;
                    const iv = algorithm.iv ? Array.from(new Uint8Array(algorithm.iv)).map(function(b){return b.toString(16).padStart(2,'0');}).join('') : 'N/A';
                    reportCrypto('WebCrypto.encrypt [' + algoName + ']', 'data[' + data.byteLength + ' bytes]', 'CryptoKey algo=' + (key.algorithm && key.algorithm.name) + ', iv=' + iv, '', 3);
                } catch (e) {}
                return result;
            });
        };
        const _origDigest = _subtle.digest.bind(_subtle);
        _subtle.digest = function(algorithm, data) {
            return _origDigest(algorithm, data).then(function(result) {
                try {
                    const algoName = typeof algorithm === 'string' ? algorithm : algorithm.name;
                    const resultHex = Array.from(new Uint8Array(result)).map(function(b){return b.toString(16).padStart(2,'0');}).join('');
                    reportCrypto('WebCrypto.digest [' + algoName + ']', 'input[' + data.byteLength + ' bytes]', 'result: ' + resultHex.substring(0,32) + '...', '', 3);
                } catch (e) {}
                return result;
            });
        };
        window.crypto.subtle._isHooked = true;
    };

    // ── C. 签名字段嗅探 ──
    const SIG_PATTERNS = [
        /[?&](sign|signature|sig|nonce|timestamp|_t|_sign|hmac)=([^&\s]{4,})/gi,
        /"(sign|signature|nonce|timestamp|_sign|access_token)":\s*"([^"]{4,})"/gi
    ];
    function sniffSignatureFields(text) {
        if (!text || typeof text !== 'string') return;
        SIG_PATTERNS.forEach(function(re) {
            re.lastIndex = 0;
            var m;
            while ((m = re.exec(text)) !== null) {
                window.postMessage({ type: 'SIGN_FIELD_FOUND', field: m[1], value: m[2].substring(0, 60), context: text.substring(Math.max(0, m.index-30), m.index+80) }, '*');
            }
        });
    }

    // ============================================================
    // 🔬 参数来源追踪模块 (ParamTracer)
    // ============================================================
    const ParamTracer = {
        getStack: function() {
            try {
                return new Error().stack.split('\n')
                    .slice(3, 8)
                    .map(l => l.trim())
                    .filter(l => l && !l.includes('page-script') && !l.includes('inject.js') && !l.includes('extensions'))
                    .join(' → ') || 'unknown';
            } catch(e) { return 'unknown'; }
        },
        extractUrlParams: function(url) {
            const params = {};
            try {
                new URL(url, location.href).searchParams.forEach((v, k) => { params[k] = v; });
            } catch(e) {}
            return params;
        },
        extractBodyParams: function(body) {
            if (!body || typeof body !== 'string' || body.length > 200000) return {};
            const params = {};
            try {
                const flatten = (obj, prefix) => {
                    if (!obj || typeof obj !== 'object') return;
                    for (const [k, v] of Object.entries(obj)) {
                        const key = prefix ? prefix + '.' + k : k;
                        if (typeof v === 'object' && v !== null && !Array.isArray(v)) flatten(v, key);
                        else params[key] = String(v).substring(0, 200);
                    }
                };
                flatten(JSON.parse(body), '');
                return params;
            } catch(e) {}
            try { new URLSearchParams(body).forEach((v, k) => { params[k] = v; }); } catch(e) {}
            return params;
        },
        report: function(params, url, method, source, headers) {
            if (!params || !Object.keys(params).length) return;
            // 过滤掉不感兴趣的通用参数
            const skip = new Set(['_t','_','page','size','limit','offset','pageSize','pageNum','callback']);
            const filtered = {};
            for (const [k, v] of Object.entries(params)) {
                if (!skip.has(k) && v && String(v).length > 1) filtered[k] = v;
            }
            if (!Object.keys(filtered).length) return;
            let frames = [];
            try { frames = parsePhantomStack(new Error().stack, 2); } catch(e) {}
            window.postMessage({
                type: 'PARAM_TRACE',
                params: filtered,
                url, method, source,
                stack: this.getStack(),
                frames: frames,
                headers: headers || {},
                time: Date.now()
            }, '*');
        }
    };

    // Hook XHR.setRequestHeader
    const originalSetRequestHeader = XMLHttpRequest.prototype.setRequestHeader;
    XMLHttpRequest.prototype.setRequestHeader = function(name, value) {
        if (!this._capturedHeaders) this._capturedHeaders = {};
        this._capturedHeaders[name] = value;
        return originalSetRequestHeader.apply(this, arguments);
    };

    setInterval(function() { hookCryptoJS(); hookWebCrypto(); FunctionTracer.autoHookCrypto(); }, 2000);
    hookCryptoJS();
    hookWebCrypto();

    // ============================================================
    // 🔭 函数调用追踪引擎 (FunctionTracer)
    // 自动追踪目标函数：调用链 / 参数 / 返回值 / 耗时
    // ============================================================
    const FunctionTracer = {
        _hooks: {},

        getStack: function() {
            try {
                return new Error().stack.split('\n').slice(3, 9)
                    .map(f => f.trim())
                    .filter(f => f && !f.includes('page-script') && !f.includes('phantom') && !f.includes('extensions'))
                    .map(f => f.replace(/^\s*at\s+/, '').trim())
                    .slice(0, 5);
            } catch(e) { return ['unknown']; }
        },

        getFrames: function() {
            try { return parsePhantomStack(new Error().stack, 2); } catch(e) { return []; }
        },

        safeStr: function(v) {
            try {
                if (v === null) return 'null';
                if (v === undefined) return 'undefined';
                if (typeof v === 'function') return `[Function:${v.name||'?'}]`;
                if (typeof v === 'string') return v.length > 300 ? v.substring(0,300)+'…' : v;
                if (typeof v === 'number' || typeof v === 'boolean') return String(v);
                if (v instanceof ArrayBuffer) return `[ArrayBuffer ${v.byteLength}B]`;
                if (v instanceof Uint8Array || v instanceof Int8Array)
                    return `[TypedArray ${v.length}B: ${Array.from(v.slice(0,8)).map(b=>b.toString(16).padStart(2,'0')).join('')}...]`;
                // CryptoJS WordArray
                if (v && v.words && v.sigBytes !== undefined)
                    return `[CryptoJS WordArray: ${v.toString ? v.toString().substring(0,40) : '?'}]`;
                const s = JSON.stringify(v);
                return s.length > 300 ? s.substring(0,300)+'…' : s;
            } catch(e) { return `[${typeof v}]`; }
        },

        traceMethod: function(obj, methodPath, label) {
            const parts = methodPath.split('.');
            let target = obj;
            for (let i = 0; i < parts.length - 1; i++) {
                if (!target || typeof target !== 'object') return false;
                target = target[parts[i]];
                if (!target) return false;
            }
            const methodName = parts[parts.length - 1];
            if (!target || typeof target[methodName] !== 'function') return false;
            if (target[methodName]._phantomTraced) return false;

            const original = target[methodName];
            const self = this;
            const fullLabel = label || methodPath;

            target[methodName] = makeNative(function() {
                const args = Array.from(arguments);
                const stackFrames = self.getStack();
                const frames = self.getFrames();
                const t0 = performance.now();
                let retVal, errMsg;
                try {
                    retVal = original.apply(this, args);
                } catch(e) {
                    errMsg = e.message;
                    window.postMessage({
                        type: 'FUNC_TRACE', label: fullLabel,
                        args: args.map(a => self.safeStr(a)),
                        error: errMsg, stack: stackFrames, frames: frames,
                        durationMs: +(performance.now()-t0).toFixed(2), time: Date.now()
                    }, '*');
                    throw e;
                }
                // 异步结果
                if (retVal && typeof retVal.then === 'function') {
                    retVal.then(r => {
                        window.postMessage({
                            type: 'FUNC_TRACE', label: fullLabel,
                            args: args.map(a => self.safeStr(a)),
                            returnVal: self.safeStr(r), isAsync: true,
                            stack: stackFrames, frames: frames,
                            durationMs: +(performance.now()-t0).toFixed(2), time: Date.now()
                        }, '*');
                    }).catch(() => {});
                } else {
                    window.postMessage({
                        type: 'FUNC_TRACE', label: fullLabel,
                        args: args.map(a => self.safeStr(a)),
                        returnVal: self.safeStr(retVal), isAsync: false,
                        stack: stackFrames, frames: frames,
                        durationMs: +(performance.now()-t0).toFixed(2), time: Date.now()
                    }, '*');
                }
                return retVal;
            }, original);
            target[methodName]._phantomTraced = true;
            this._hooks[fullLabel] = { methodPath, count: 0 };
            return true;
        },

        traceGlobal: function(keyword) {
            let count = 0;
            try {
                Object.keys(window).forEach(key => {
                    if (!key.toLowerCase().includes(keyword.toLowerCase())) return;
                    if (typeof window[key] === 'function' && !window[key]._phantomTraced) {
                        this.traceMethod(window, key, `window.${key}`);
                        count++;
                    }
                });
            } catch(e) {}
            return count;
        },

        // 自动挂钩常见解密函数
        autoHookCrypto: function() {
            const self = this;
            if (window.CryptoJS) {
                ['AES','DES','TripleDES','RC4','Rabbit'].forEach(algo => {
                    const obj = window.CryptoJS[algo];
                    if (!obj || !obj.decrypt || obj.decrypt._phantomTracedDecrypt) return;
                    const _origDec = obj.decrypt;
                    obj.decrypt = makeNative(function(ciphertext, key, cfg) {
                        const result = _origDec.apply(this, arguments);
                        let plain = '';
                        try { plain = result.toString(window.CryptoJS.enc.Utf8); } catch(e) {}
                        window.postMessage({
                            type: 'DECRYPT_FOUND',
                            algo: `CryptoJS.${algo}.decrypt`,
                            ciphertext: self.safeStr(ciphertext),
                            key: self.safeStr(key),
                            cfg: cfg ? JSON.stringify(cfg).substring(0,100) : undefined,
                            plaintext: plain.substring(0, 500),
                            stack: self.getStack(),
                            frames: self.getFrames(),
                            time: Date.now()
                        }, '*');
                        return result;
                    }, _origDec);
                    obj.decrypt._phantomTracedDecrypt = true;
                });
            }
            // WebCrypto.decrypt
            if (window.crypto && window.crypto.subtle && !window.crypto.subtle._decryptHooked) {
                const _sub = window.crypto.subtle;
                const _origDec = _sub.decrypt.bind(_sub);
                _sub.decrypt = function(algorithm, key, data) {
                    return _origDec(algorithm, key, data).then(result => {
                        try {
                            let plain = '';
                            try { plain = new TextDecoder().decode(result); } catch(e) { plain = '[binary]'; }
                            window.postMessage({
                                type: 'DECRYPT_FOUND',
                                algo: `WebCrypto.decrypt[${typeof algorithm==='string'?algorithm:algorithm.name}]`,
                                ciphertext: `[ArrayBuffer ${data.byteLength}B]`,
                                key: `CryptoKey(${key.algorithm?.name||'?'})`,
                                plaintext: plain.substring(0, 500),
                                stack: self.getStack(),
                                frames: self.getFrames(),
                                time: Date.now()
                            }, '*');
                        } catch(e) {}
                        return result;
                    });
                };
                window.crypto.subtle._decryptHooked = true;
            }
            // atob 解码监控（仅长字符串，有递归保护）
            if (!window.atob._phantomTraced) {
                const _origAtob = window.atob.bind(window);
                window._origAtobPhantom = _origAtob;  // 供内部使用，避免递归
                let _atobBusy = false;
                window.atob = makeNative(function(str) {
                    const result = _origAtob(str);
                    if (!_atobBusy && str && str.length > 20) {
                        _atobBusy = true;
                        try {
                            window.postMessage({
                                type: 'DECRYPT_FOUND',
                                algo: 'atob(Base64解码)',
                                ciphertext: str.length>120 ? str.substring(0,120)+'…' : str,
                                key: '(Base64, 无密钥)',
                                plaintext: result.length>300 ? result.substring(0,300)+'…' : result,
                                stack: self.getStack(),
                                frames: self.getFrames(),
                                time: Date.now()
                            }, '*');
                        } catch(e) {}
                        _atobBusy = false;
                    }
                    return result;
                }, _origAtob);
                window.atob._phantomTraced = true;
            }
        }
    };

    // 初始挂钩
    FunctionTracer.autoHookCrypto();

    // ============================================================
    // 🔍 请求参数加密检测引擎 (ParamCryptoDetector)
    // 自动扫描 GET/POST 参数，识别加密/编码值，尝试还原明文
    // ============================================================
    const ParamCryptoDetector = {
        patterns: [
            { name: 'JWT',         test: v => /^eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\./.test(v) },
            { name: 'Base64',      test: v => v.length >= 16 && /^[A-Za-z0-9+/]{16,}={0,2}$/.test(v) && v.length%4===0 },
            { name: 'Hex(MD5?)',   test: v => /^[0-9a-fA-F]{32}$/.test(v) },
            { name: 'Hex(SHA1?)',  test: v => /^[0-9a-fA-F]{40}$/.test(v) },
            { name: 'Hex(SHA256?)',test: v => /^[0-9a-fA-F]{64}$/.test(v) },
            { name: 'HexLong',    test: v => v.length>=32 && /^[0-9a-fA-F]+$/.test(v) && v.length%2===0 },
            { name: 'URLEncoded', test: v => /%[0-9A-Fa-f]{2}/.test(v) },
            { name: 'AES_b64',    test: v => v.length>=44 && /^[A-Za-z0-9+/]{44,}={0,2}$/.test(v) },
        ],

        tryDecode: function(val) {
            // 使用原始 atob（避免触发我们 hook 的 atob 造成递归）
            const safeAtob = window._origAtobPhantom || (s => { try { return atob(s); } catch(e) { return null; }});
            const results = [];
            // Base64
            try {
                if (/^[A-Za-z0-9+/]{16,}={0,2}$/.test(val) && val.length%4===0) {
                    const d = safeAtob(val);
                    if (d && /[\x20-\x7E\u4e00-\u9fff]/.test(d)) {
                        results.push({ method:'Base64', result: d.length>200?d.substring(0,200)+'…':d });
                    }
                }
            } catch(e) {}
            // URL decode
            try {
                if (/%[0-9A-Fa-f]{2}/.test(val)) {
                    const u = decodeURIComponent(val);
                    if (u !== val) results.push({ method:'URLDecode', result: u.substring(0,300) });
                }
            } catch(e) {}
            // JWT
            try {
                if (/^eyJ/.test(val)) {
                    const parts = val.split('.');
                    if (parts.length >= 2) {
                        const pad = s => s + '='.repeat((4-s.length%4)%4);
                        const payload = JSON.parse(safeAtob(pad(parts[1].replace(/-/g,'+').replace(/_/g,'/'))));
                        results.push({ method:'JWT.payload', result: JSON.stringify(payload, null, 2).substring(0,400) });
                    }
                }
            } catch(e) {}
            // Hex → text
            try {
                if (/^[0-9a-fA-F]{32,}$/.test(val) && val.length%2===0 && val.length<=200) {
                    const bytes = val.match(/.{2}/g).map(b=>parseInt(b,16));
                    const text = bytes.map(b=>String.fromCharCode(b)).join('');
                    if (/^[\x20-\x7E]{4,}$/.test(text)) {
                        results.push({ method:'HexDecode', result: text.substring(0,200) });
                    }
                }
            } catch(e) {}
            return results;
        },

        detect: function(key, val, url, method) {
            if (!val || typeof val !== 'string' || val.length < 8) return;
            const matched = this.patterns.filter(p => { try { return p.test(val); } catch(e){ return false; } });
            if (!matched.length) return;
            const decoded = this.tryDecode(val);
            let frames = [];
            try { frames = parsePhantomStack(new Error().stack, 2); } catch(e) {}
            window.postMessage({
                type: 'PARAM_CRYPTO_FOUND',
                key, value: val.length>150 ? val.substring(0,150)+'…' : val,
                detected: matched.map(p => p.name),
                decoded,
                url, method,
                frames: frames,
                time: Date.now()
            }, '*');
        },

        scanUrl: function(url, method) {
            // 跳过静态资源和已知 CDN
            if (/\.(js|css|png|jpg|gif|svg|woff|ttf|ico)(\?|$)/.test(url)) return;
            if (/cdnjs\.cloudflare|googleapis|gstatic|jsdelivr/.test(url)) return;
            try {
                new URL(url, location.href).searchParams.forEach((v, k) => this.detect(k, v, url, method));
            } catch(e) {}
        },

        scanBody: function(body, url, method) {
            if (!body || typeof body !== 'string' || body.length > 300000) return;
            // 跳过静态资源
            if (/\.(js|css|png|jpg|gif|svg|woff|ttf|ico)(\?|$)/.test(url)) return;
            try {
                const flat = {};
                const flatten = (obj, pre) => {
                    for (const [k, v] of Object.entries(obj||{})) {
                        const kk = pre ? `${pre}.${k}` : k;
                        if (v && typeof v === 'object' && !Array.isArray(v)) flatten(v, kk);
                        else flat[kk] = String(v);
                    }
                };
                flatten(JSON.parse(body), '');
                Object.entries(flat).forEach(([k,v]) => this.detect(k, v, url, method));
                return;
            } catch(e) {}
            try {
                new URLSearchParams(body).forEach((v, k) => this.detect(k, v, url, method));
            } catch(e) {}
        }
    };

    // 监听追踪指令（来自 inject.js）
    window.addEventListener('message', function(event) {
        const msg = event.data;
        if (!msg || msg.__phantom_origin) return;
        if (msg.type === 'TRACE_FUNCTION') {
            let ok = false, count = 0, error = '';
            try {
                if (msg.mode === 'global') {
                    count = FunctionTracer.traceGlobal(msg.keyword || msg.target);
                    ok = count > 0;
                } else {
                    ok = FunctionTracer.traceMethod(window, msg.target, msg.target);
                    count = ok ? 1 : 0;
                    if (!ok) error = `找不到函数路径: ${msg.target}`;
                }
            } catch(e) { error = e.message; }
            window.postMessage({ type: 'TRACE_FUNCTION_RESULT', ok, count, error, target: msg.target || msg.keyword }, '*');
        }
    }, false);

    // ============================================================
    // 1. 内部消息通信 (监听来自 inject.js 的指令)
    // ============================================================
    window.addEventListener('message', (event) => {
        const data = event.data;
        if (!data || !data.type) return;

        // 更新静态 Mock 规则
        if (data.type === 'UPDATE_MOCK_RULES') {
            _mockRules = data.rules || [];
        }

        // 更新本地文件替换规则
        if (data.type === 'UPDATE_LOCAL_FILE_RULES') {
            _localFileRules = data.rules || [];
        }
        
        // WS 改写规则（也在这里接收，同步给 _wsModifyRules）
        if (data.type === 'UPDATE_WS_RULES') {
            // _wsModifyRules handled in WS section below
        }

        // 导出所有 Storage 数据
        if (data.type === 'DUMP_STORAGE') {
            const local = {}, session = {};
            try { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); local[k] = localStorage.getItem(k); } } catch(e) {}
            try { for (let i = 0; i < sessionStorage.length; i++) { const k = sessionStorage.key(i); session[k] = sessionStorage.getItem(k); } } catch(e) {}
            window.postMessage({ type: 'STORAGE_DUMP_RESULT', local, session, url: window.location.href }, '*');
        }

        // 中止被断点挂起的请求
        if (data.type === 'ABORT_REQUEST') {
            const resolver = _breakpointResolvers[data.requestId];
            if (resolver) {
                delete _breakpointResolvers[data.requestId];
                // 用一个 aborted response 代替
                resolver({ aborted: true, requestId: data.requestId });
            }
        }
        
        // 更新动态 Hook 脚本
        if (data.type === 'UPDATE_DYNAMIC_SCRIPT') {
            if (!data.script || data.script.trim() === '') {
                _dynamicHandler = null;
            } else {
                try {
                    // 动态构建处理函数
                    _dynamicHandler = new Function('url', 'method', 'response', data.script);
                } catch (e) {
                    console.error('[Phantom Analyzer] Script Error:', e);
                }
            }
        }
        
        // 更新断点状态和狙击关键词
        if (data.type === 'TOGGLE_BREAKPOINT') {
            _breakpointEnabled = data.enabled;
            _breakpointFilter = data.filter || ''; 
        }

        // 恢复被暂停的请求
        if (data.type === 'RESUME_REQUEST') {
            const resolver = _breakpointResolvers[data.requestId];
            if (resolver) {
                resolver(data.modifiedData); 
                delete _breakpointResolvers[data.requestId];
            }
        }

        // 添加 M3U8 重定向映射
        if (data.type === 'ADD_REDIRECT_RULE') {
            _replaceMap[data.original] = data.clean;
        }
        
        // 执行请求重放
        if (data.type === 'REPLAY_REQUEST') {
            replayRequest(data.url, data.method, data.body);
        }
    });

    // 请求重放逻辑：使用 fetch 重新发起目标请求
    function replayRequest(url, method, body) {
        console.log(`[Phantom Replay] 正在重放请求: ${method} ${url}`);
        const options = { 
            method: method, 
            headers: { 'Content-Type': 'application/json' } 
        }; 
        if (body) options.body = body;
        window.fetch(url, options)
            .then(r => r.text())
            .then(t => console.log('[Phantom Replay] 响应结果:', t))
            .catch(e => console.error('[Phantom Replay] 重放失败:', e));
    }

    // ============================================================
    // 2. 🎯 断点挂起核心：判断是否需要暂停请求
    // ============================================================
    async function waitForBreakpoint(url, method, body, type) {
        // 1. 断点总开关未开启 -> 放行
        if (!_breakpointEnabled) return null;
        
        // 2. 关键词未命中 -> 放行
        if (_breakpointFilter && !url.includes(_breakpointFilter)) return null;

        const requestId = generateId();
        // 通知 inject.js 弹出调试窗口
        window.postMessage({ 
            type: 'REQUEST_PAUSED_INTERNAL', 
            details: { requestId, url, method, body, type } 
        }, '*');

        // 返回 Promise 挂起当前线程，直到 UI 点击“放行”
        return new Promise(resolve => { 
            _breakpointResolvers[requestId] = resolve; 
        });
    }

    // ============================================================
    // 2b. Storage 全审计 — localStorage / sessionStorage 读写监控
    // ============================================================
    function hookStorage(storageObj, storageName) {
        const _origSetItem = storageObj.setItem.bind(storageObj);
        const _origRemoveItem = storageObj.removeItem.bind(storageObj);
        const _origClear = storageObj.clear.bind(storageObj);

        storageObj.setItem = function(key, value) {
            const oldVal = storageObj.getItem(key);
            _origSetItem(key, value);
            window.postMessage({ type: 'STORAGE_EVENT', storage: storageName, op: oldVal === null ? 'ADD' : 'SET', key, value: String(value).substring(0, 500), oldValue: oldVal ? String(oldVal).substring(0, 200) : null }, '*');
        };
        storageObj.removeItem = function(key) {
            const oldVal = storageObj.getItem(key);
            _origRemoveItem(key);
            window.postMessage({ type: 'STORAGE_EVENT', storage: storageName, op: 'REMOVE', key, oldValue: oldVal ? String(oldVal).substring(0, 200) : null }, '*');
        };
        storageObj.clear = function() {
            _origClear();
            window.postMessage({ type: 'STORAGE_EVENT', storage: storageName, op: 'CLEAR', key: '*' }, '*');
        };
    }

    // Hook localStorage & sessionStorage
    try { hookStorage(window.localStorage, 'localStorage'); } catch(e) {}
    try { hookStorage(window.sessionStorage, 'sessionStorage'); } catch(e) {}

    // IndexedDB 写操作监控
    const _origIDBOpen = window.indexedDB.open.bind(window.indexedDB);
    window.indexedDB.open = function(name, version) {
        const req = _origIDBOpen(name, version);
        req.addEventListener('success', function() {
            const db = req.result;
            const _origTransaction = db.transaction.bind(db);
            db.transaction = function(storeNames, mode) {
                const tx = _origTransaction(storeNames, mode);
                if (mode === 'readwrite') {
                    const names = Array.isArray(storeNames) ? storeNames : [storeNames];
                    names.forEach(storeName => {
                        try {
                            const store = tx.objectStore(storeName);
                            const _origPut = store.put.bind(store);
                            const _origDelete = store.delete.bind(store);
                            store.put = function(value, key) {
                                window.postMessage({ type: 'STORAGE_EVENT', storage: 'IndexedDB', op: 'PUT', key: `${name}/${storeName}/${key || '?'}`, value: JSON.stringify(value).substring(0, 300) }, '*');
                                return _origPut(value, key);
                            };
                            store.delete = function(key) {
                                window.postMessage({ type: 'STORAGE_EVENT', storage: 'IndexedDB', op: 'DELETE', key: `${name}/${storeName}/${key}` }, '*');
                                return _origDelete(key);
                            };
                        } catch(e) {}
                    });
                }
                return tx;
            };
        });
        return req;
    };

    // 响应 DUMP_STORAGE 消息 — 一次性导出所有 localStorage/sessionStorage
    // (在消息监听器里处理，见下方)

    // ============================================================
    // 3. 劫持 Fetch API
    // ============================================================
    const originalFetch = window.fetch;
    const hookedFetch = async function(...args) {
        let url = typeof args[0] === 'string' ? args[0] : (args[0].url || '');
        let options = args[1] || {};
        let method = options.method || 'GET';
        let body = options.body;

        // A. 静态 Mock 检查（优先级最高）
        const staticRule = _mockRules.find(r => url.includes(r.urlKeyword) && r.enabled);
        if (staticRule) {
            console.log(`[Phantom Mock] 命中静态规则: ${url}`);
            return new Response(staticRule.responseBody, { status: 200 });
        }

        // A2. 本地文件替换
        const localRule = _localFileRules.find(r => url.includes(r.urlKeyword) && r.enabled);
        if (localRule) {
            console.log(`[Phantom MapLocal] 替换为本地文件: ${url} → ${localRule.fileName}`);
            return new Response(localRule.content, { status: 200, headers: { 'Content-Type': 'text/javascript' } });
        }

        // A3. 签名字段嗅探
        sniffSignatureFields(url);
        if (body && typeof body === 'string') sniffSignatureFields(body);

        // A4. 参数来源追踪
        ParamTracer.report(ParamTracer.extractUrlParams(url), url, method, 'fetch_url');
        if (body && typeof body === 'string') {
            ParamTracer.report(ParamTracer.extractBodyParams(body), url, method, 'fetch_body');
        }
        // A5. 参数加密检测
        ParamCryptoDetector.scanUrl(url, method);
        if (body && typeof body === 'string') ParamCryptoDetector.scanBody(body, url, method);
        // 捕获请求头中的关键字段
        const fetchHeaders = {};
        try {
            const h = options.headers || {};
            const entries = h instanceof Headers ? [...h.entries()] : Object.entries(h);
            entries.forEach(([k, v]) => {
                const kl = k.toLowerCase();
                if (/auth|token|sign|key|secret|x-/i.test(kl)) fetchHeaders[k] = v;
            });
            if (Object.keys(fetchHeaders).length) {
                ParamTracer.report(fetchHeaders, url, method, 'fetch_header');
            }
        } catch(e) {}

        // B. 断点检查：请求发出前进入暂停状态
        const modifiedData = await waitForBreakpoint(url, method, body, 'fetch');
        if (modifiedData) {
            // 丢弃请求
            if (modifiedData.aborted) {
                return new Response('{"error":"request aborted by Phantom"}', { status: 0, statusText: 'Aborted' });
            }
            // 应用用户在 UI 上的修改
            if (modifiedData.url) args[0] = modifiedData.url;
            if (modifiedData.body && args[1]) args[1].body = modifiedData.body;
            if (modifiedData.headers && args[1]) {
                args[1].headers = { ...(args[1].headers || {}), ...modifiedData.headers };
            }
        }

        let response;
        try { 
            response = await originalFetch.apply(this, args); 
        } catch (err) { 
            throw err; 
        }

        // C. 动态脚本处理：响应返回后进行 Hook
        if (_dynamicHandler) {
            try {
                const contentType = response.headers.get('content-type') || '';
                // 仅处理 JSON 或文本类型，防止处理二进制流导致卡死
                if (/application\/json|text\//.test(contentType)) {
                    const clone = response.clone();
                    let bodyText = await clone.text().catch(() => '');
                    
                    // 检查响应体大小，超过 2MB 则跳过，保证性能
                    if (bodyText.length < 2 * 1024 * 1024) {
                        const modifiedBody = _dynamicHandler(url, method, bodyText);
                        if (modifiedBody !== null && modifiedBody !== undefined) {
                            return new Response(modifiedBody, {
                                status: response.status, 
                                statusText: response.statusText, 
                                headers: response.headers
                            });
                        }
                    }
                }
            } catch (e) {}
        }
        return response;
    };
    // 应用原生伪装
    window.fetch = makeNative(hookedFetch, originalFetch);

    // ============================================================
    // 4. 劫持 XMLHttpRequest (XHR)
    // ============================================================
    const originalOpen = XMLHttpRequest.prototype.open;
    const originalSend = XMLHttpRequest.prototype.send;

    const hookedOpen = function(method, url) {
        this._requestUrl = url;
        this._method = method;
        
        // [修复补丁3]：使用 Array 转换 arguments，防止在严格模式下报错失效
        let args = Array.prototype.slice.call(arguments);
        if (_replaceMap[url]) {
            args[1] = _replaceMap[url];
        }
        return originalOpen.apply(this, args);
    };
    
    const hookedSend = function(body) {
        // A. 静态 Mock 检查
        const staticRule = _mockRules.find(r => (this._requestUrl||'').includes(r.urlKeyword) && r.enabled);
        if (staticRule) {
            Object.defineProperty(this, 'responseText', { value: staticRule.responseBody });
            Object.defineProperty(this, 'response', { value: staticRule.responseBody });
            Object.defineProperty(this, 'status', { value: 200 });
            Object.defineProperty(this, 'readyState', { value: 4 });
            setTimeout(() => {
                if (this.onreadystatechange) this.onreadystatechange();
                if (this.onload) this.onload();
            }, 10);
            return;
        }
        // A2. 本地文件替换 (XHR)
        const localRule = _localFileRules.find(r => (this._requestUrl||'').includes(r.urlKeyword) && r.enabled);
        if (localRule) {
            Object.defineProperty(this, 'responseText', { value: localRule.content });
            Object.defineProperty(this, 'response', { value: localRule.content });
            Object.defineProperty(this, 'status', { value: 200 });
            Object.defineProperty(this, 'readyState', { value: 4 });
            setTimeout(() => {
                if (this.onreadystatechange) this.onreadystatechange();
                if (this.onload) this.onload();
            }, 10);
            return;
        }

        // A3. 参数来源追踪
        const _xhrUrl = this._requestUrl || '';
        ParamTracer.report(ParamTracer.extractUrlParams(_xhrUrl), _xhrUrl, this._method || 'GET', 'xhr_url');
        if (body && typeof body === 'string') {
            ParamTracer.report(ParamTracer.extractBodyParams(body), _xhrUrl, this._method || 'GET', 'xhr_body');
        }
        // A4. 参数加密检测 (XHR)
        ParamCryptoDetector.scanUrl(_xhrUrl, this._method || 'GET');
        if (body && typeof body === 'string') ParamCryptoDetector.scanBody(body, _xhrUrl, this._method || 'GET');
        if (this._capturedHeaders && Object.keys(this._capturedHeaders).length) {
            const interestingHeaders = {};
            for (const [k, v] of Object.entries(this._capturedHeaders)) {
                if (/auth|token|sign|key|secret|x-/i.test(k.toLowerCase())) interestingHeaders[k] = v;
            }
            if (Object.keys(interestingHeaders).length) {
                ParamTracer.report(interestingHeaders, _xhrUrl, this._method || 'GET', 'xhr_header');
            }
        }

        // B. 断点检查（XHR 异步等待逻辑）
        if (_breakpointEnabled) {
            waitForBreakpoint(this._requestUrl, this._method, body, 'xhr').then((modifiedData) => {
                if (modifiedData && modifiedData.body) body = modifiedData.body;
                // 如果开启了动态脚本，则设置 XHR 响应 Hook
                if (_dynamicHandler) setupXhrHook(this);
                originalSend.call(this, body);
            });
            return; // 暂停发送，直到 Promise 回调执行
        }

        // C. 普通发送：如果开启了动态脚本则注入 Hook
        if (_dynamicHandler) setupXhrHook(this);
        return originalSend.apply(this, arguments);
    };

    // 为 XHR 注入响应修改逻辑
    function setupXhrHook(xhr) {
        const originalOnReadyStateChange = xhr.onreadystatechange;
        const originalOnLoad = xhr.onload;
        
        const handleStateChange = () => {
            if (xhr.readyState === 4) { // 请求完成状态
                try {
                    // 仅当 responseType 为空或 text 时处理内容
                    if (!xhr.responseType || xhr.responseType === 'text') {
                        const originalText = xhr.responseText;
                        // 2MB 熔断保护
                        if (originalText && originalText.length < 2 * 1024 * 1024) {
                            const modifiedText = _dynamicHandler(xhr._requestUrl, xhr._method, originalText);
                            if (modifiedText !== null && modifiedText !== undefined) {
                                // 利用 Object.defineProperty 强行覆盖只读属性
                                Object.defineProperty(xhr, 'responseText', { value: modifiedText, writable: true });
                                Object.defineProperty(xhr, 'response', { value: modifiedText, writable: true });
                            }
                        }
                    }
                } catch (e) {}
            }
            if (originalOnReadyStateChange) originalOnReadyStateChange.apply(xhr, arguments);
        };

        xhr.onreadystatechange = handleStateChange;
        if (xhr.onload) {
            xhr.onload = () => { 
                handleStateChange(); 
                originalOnLoad.apply(xhr, arguments); 
            };
        }
    }

    // 应用 XHR 原生伪装
    XMLHttpRequest.prototype.open = makeNative(hookedOpen, originalOpen);
    XMLHttpRequest.prototype.send = makeNative(hookedSend, originalSend);

    // ============================================================
    // 🔌 WebSocket 拦截/改写 Hook
    // ============================================================
    const _NativeWebSocket = window.WebSocket;

    class HookedWebSocket extends _NativeWebSocket {
        constructor(url, protocols) {
            super(url, protocols);
            this._wsUrl = url;
            this._wsId = `ws_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
            this._paused = false;
            this._pendingFrames = []; // 断点时暂存待发帧

            // 上报 WS 连接建立
            window.postMessage({ type: 'WS_HOOK_CREATED', wsId: this._wsId, url }, '*');

            // 拦截接收到的消息（onmessage）
            const _origAddEventListener = this.addEventListener.bind(this);
            const self = this;

            this.addEventListener('message', function(event) {
                let data = event.data;
                // 通知页面面板，等待可能的改写指令
                window.postMessage({ type: 'WS_HOOK_RECV', wsId: self._wsId, url, data: typeof data === 'string' ? data.substring(0, 2000) : '[binary]' }, '*');
                // 改写拦截：如果当前帧有对应改写规则，替换数据
                const rule = _wsModifyRules.find(r => r.enabled && url.includes(r.urlKeyword));
                if (rule && typeof data === 'string') {
                    try {
                        const parsed = JSON.parse(data);
                        const newData = JSON.parse(rule.rewriteBody);
                        Object.assign(parsed, newData);
                        // 构造一个新的 MessageEvent 替换原始的
                        Object.defineProperty(event, 'data', { value: JSON.stringify(parsed), writable: false });
                    } catch (e) {}
                }
            }, false);
        }

        send(data) {
            const self = this;
            // 上报发出帧
            window.postMessage({ type: 'WS_HOOK_SENT', wsId: this._wsId, url: this._wsUrl, data: typeof data === 'string' ? data.substring(0, 2000) : '[binary]' }, '*');

            // 断点暂停模式
            if (this._paused) {
                this._pendingFrames.push(data);
                window.postMessage({ type: 'WS_FRAME_PAUSED', wsId: this._wsId, url: this._wsUrl, data: typeof data === 'string' ? data : '[binary]' }, '*');
                return;
            }

            // 改写规则
            let finalData = data;
            const rule = _wsModifyRules.find(r => r.enabled && this._wsUrl.includes(r.urlKeyword) && r.direction !== 'RECV');
            if (rule && typeof data === 'string') {
                try {
                    const parsed = JSON.parse(data);
                    const patch = JSON.parse(rule.rewriteBody);
                    finalData = JSON.stringify({ ...parsed, ...patch });
                    window.postMessage({ type: 'WS_HOOK_MODIFIED', wsId: this._wsId, original: data.substring(0, 200), modified: finalData.substring(0, 200) }, '*');
                } catch (e) {}
            }

            super.send(finalData);
        }

        // 解除断点，放行暂存帧
        _resumeFrames(modifiedData) {
            this._paused = false;
            const frames = this._pendingFrames.splice(0);
            frames.forEach(frame => {
                super.send(modifiedData !== undefined ? modifiedData : frame);
            });
        }
    }

    // WS 改写规则存储（由 inject.js 通过 UPDATE_WS_RULES 消息下发）
    let _wsModifyRules = [];

    window.addEventListener('message', function(event) {
        if (!event.data || event.data.__phantom_origin) return;
        const msg = event.data;
        if (msg.type === 'UPDATE_WS_RULES') {
            _wsModifyRules = msg.rules || [];
        }
        // 断点放行/丢弃 WS 帧
        if (msg.type === 'WS_FRAME_RESUME' || msg.type === 'WS_FRAME_ABORT') {
            // 找到对应的 HookedWebSocket 实例（通过 wsId 标记）
            // 实例在 window.__phantom_ws_instances 中管理
            const inst = (window.__phantom_ws_instances || {})[msg.wsId];
            if (inst) {
                if (msg.type === 'WS_FRAME_RESUME') inst._resumeFrames(msg.modifiedData);
                else inst._pendingFrames = [];
            }
        }
    }, false);

    // 实例注册表
    if (!window.__phantom_ws_instances) window.__phantom_ws_instances = {};
    const _OrigHookedWS = HookedWebSocket;
    window.WebSocket = new Proxy(_NativeWebSocket, {
        construct(target, args) {
            const inst = new _OrigHookedWS(...args);
            window.__phantom_ws_instances[inst._wsId] = inst;
            inst.addEventListener('close', () => { delete window.__phantom_ws_instances[inst._wsId]; }, { once: true });
            return inst;
        }
    });

})();



    // ============================================================
    // 🎵 音频全链路追踪模块 (AudioChain Tracker)
    // 覆盖: AudioContext / MediaRecorder / getUserMedia / decodeAudioData
    // ============================================================
    (function hookAudio() {

        // ── A. AudioContext 生命周期 & 解码追踪 ──
        const _NativeAudioContext = window.AudioContext || window.webkitAudioContext;
        if (_NativeAudioContext && !_NativeAudioContext._phantomAudioHooked) {

            // Hook decodeAudioData — 捕获解码的原始音频二进制
            const _origDecode = _NativeAudioContext.prototype.decodeAudioData;
            _NativeAudioContext.prototype.decodeAudioData = function(arrayBuffer, successCb, errorCb) {
                const byteLen = arrayBuffer ? arrayBuffer.byteLength : 0;
                const preview = arrayBuffer ? Array.from(new Uint8Array(arrayBuffer).slice(0, 8))
                    .map(b => b.toString(16).padStart(2,'0')).join('') : '';
                window.postMessage({
                    type: 'AUDIO_TRACK',
                    step: 'DECODE_AUDIO_DATA',
                    byteLength: byteLen,
                    headerHex: preview,
                    sampleRate: this.sampleRate,
                    state: this.state,
                    frames: parsePhantomStack(new Error().stack, 1),
                    time: Date.now()
                }, '*');
                const wrappedSuccess = successCb ? function(buffer) {
                    window.postMessage({
                        type: 'AUDIO_TRACK',
                        step: 'DECODE_DONE',
                        duration: buffer.duration,
                        sampleRate: buffer.sampleRate,
                        channels: buffer.numberOfChannels,
                        length: buffer.length,
                        frames: parsePhantomStack(new Error().stack, 1),
                        time: Date.now()
                    }, '*');
                    successCb(buffer);
                } : undefined;
                return _origDecode.call(this, arrayBuffer, wrappedSuccess, errorCb);
            };

            // Hook createMediaElementSource — 追踪 <audio>/<video> 接入 AudioGraph
            const _origCreateMES = _NativeAudioContext.prototype.createMediaElementSource;
            _NativeAudioContext.prototype.createMediaElementSource = function(mediaElement) {
                window.postMessage({
                    type: 'AUDIO_TRACK',
                    step: 'MEDIA_ELEMENT_SOURCE',
                    src: mediaElement ? (mediaElement.src || mediaElement.currentSrc || '') : '',
                    tagName: mediaElement ? mediaElement.tagName : '',
                    frames: parsePhantomStack(new Error().stack, 1),
                    time: Date.now()
                }, '*');
                return _origCreateMES.call(this, mediaElement);
            };

            // Hook createMediaStreamSource — 追踪麦克风/摄像头流接入 AudioGraph
            const _origCreateMSS = _NativeAudioContext.prototype.createMediaStreamSource;
            _NativeAudioContext.prototype.createMediaStreamSource = function(stream) {
                const tracks = stream ? stream.getAudioTracks().map(t => ({
                    label: t.label, kind: t.kind, enabled: t.enabled, readyState: t.readyState
                })) : [];
                window.postMessage({
                    type: 'AUDIO_TRACK',
                    step: 'MEDIA_STREAM_SOURCE',
                    audioTracks: tracks,
                    streamId: stream ? stream.id : '',
                    frames: parsePhantomStack(new Error().stack, 1),
                    time: Date.now()
                }, '*');
                return _origCreateMSS.call(this, stream);
            };

            _NativeAudioContext._phantomAudioHooked = true;
        }

        // ── B. getUserMedia — 麦克风/摄像头请求捕获 ──
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia && !navigator.mediaDevices.getUserMedia._phantomHooked) {
            const _origGUM = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
            navigator.mediaDevices.getUserMedia = function(constraints) {
                window.postMessage({
                    type: 'AUDIO_TRACK',
                    step: 'GET_USER_MEDIA_REQUEST',
                    constraints: JSON.stringify(constraints || {}),
                    frames: parsePhantomStack(new Error().stack, 1),
                    time: Date.now()
                }, '*');
                return _origGUM(constraints).then(function(stream) {
                    const audioTracks = stream.getAudioTracks().map(t => ({ label: t.label, kind: t.kind }));
                    const videoTracks = stream.getVideoTracks().map(t => ({ label: t.label, kind: t.kind }));
                    window.postMessage({
                        type: 'AUDIO_TRACK',
                        step: 'GET_USER_MEDIA_GRANTED',
                        audioTracks, videoTracks,
                        streamId: stream.id,
                        frames: parsePhantomStack(new Error().stack, 1),
                        time: Date.now()
                    }, '*');
                    return stream;
                });
            };
            navigator.mediaDevices.getUserMedia._phantomHooked = true;
        }

        // ── C. MediaRecorder — 录音/录像全程追踪 ──
        if (window.MediaRecorder && !window.MediaRecorder._phantomHooked) {
            const _NativeMR = window.MediaRecorder;
            window.MediaRecorder = new Proxy(_NativeMR, {
                construct(target, args) {
                    const inst = new target(...args);
                    const stream = args[0];
                    const options = args[1] || {};
                    window.postMessage({
                        type: 'AUDIO_TRACK',
                        step: 'MEDIA_RECORDER_CREATED',
                        mimeType: inst.mimeType || options.mimeType || '',
                        audioBitsPerSecond: inst.audioBitsPerSecond,
                        videoBitsPerSecond: inst.videoBitsPerSecond,
                        streamId: stream ? stream.id : '',
                        frames: parsePhantomStack(new Error().stack, 1),
                        time: Date.now()
                    }, '*');

                    // 劫持 start/stop/pause/resume
                    ['start','stop','pause','resume'].forEach(method => {
                        const _orig = inst[method].bind(inst);
                        inst[method] = function(...a) {
                            window.postMessage({
                                type: 'AUDIO_TRACK',
                                step: `RECORDER_${method.toUpperCase()}`,
                                state: inst.state,
                                mimeType: inst.mimeType,
                                time: Date.now()
                            }, '*');
                            return _orig(...a);
                        };
                    });

                    // 捕获录制数据块
                    inst.addEventListener('dataavailable', function(e) {
                        if (e.data && e.data.size > 0) {
                            window.postMessage({
                                type: 'AUDIO_TRACK',
                                step: 'RECORDER_DATA',
                                blobSize: e.data.size,
                                mimeType: e.data.type,
                                time: Date.now()
                            }, '*');
                        }
                    });

                    return inst;
                }
            });
            window.MediaRecorder._phantomHooked = true;
        }

    })();

    // ============================================================
    // 📝 文字全链路追踪模块 (TextChain Tracker)
    // 覆盖: Clipboard API / Selection / MutationObserver(敏感节点)
    // ============================================================
    (function hookText() {

        // ── A. Clipboard API ──
        if (navigator.clipboard && !navigator.clipboard._phantomHooked) {
            const _origWriteText = navigator.clipboard.writeText.bind(navigator.clipboard);
            navigator.clipboard.writeText = function(text) {
                window.postMessage({
                    type: 'TEXT_TRACK',
                    step: 'CLIPBOARD_WRITE',
                    preview: typeof text === 'string' ? text.substring(0, 300) : String(text),
                    length: typeof text === 'string' ? text.length : 0,
                    frames: parsePhantomStack(new Error().stack, 1),
                    time: Date.now()
                }, '*');
                return _origWriteText(text);
            };

            const _origWrite = navigator.clipboard.write ? navigator.clipboard.write.bind(navigator.clipboard) : null;
            if (_origWrite) {
                navigator.clipboard.write = function(data) {
                    window.postMessage({
                        type: 'TEXT_TRACK',
                        step: 'CLIPBOARD_WRITE_RICH',
                        itemCount: Array.isArray(data) ? data.length : 1,
                        frames: parsePhantomStack(new Error().stack, 1),
                        time: Date.now()
                    }, '*');
                    return _origWrite(data);
                };
            }

            const _origReadText = navigator.clipboard.readText ? navigator.clipboard.readText.bind(navigator.clipboard) : null;
            if (_origReadText) {
                navigator.clipboard.readText = function() {
                    return _origReadText().then(function(text) {
                        window.postMessage({
                            type: 'TEXT_TRACK',
                            step: 'CLIPBOARD_READ',
                            preview: text ? text.substring(0, 300) : '',
                            length: text ? text.length : 0,
                            frames: parsePhantomStack(new Error().stack, 1),
                            time: Date.now()
                        }, '*');
                        return text;
                    });
                };
            }
            navigator.clipboard._phantomHooked = true;
        }

        // ── B. document.execCommand copy/cut/paste (旧版 API) ──
        const _origExecCmd = document.execCommand.bind(document);
        if (!document.execCommand._phantomHooked) {
            document.execCommand = function(cmd, showUI, value) {
                if (/^(copy|cut|paste)$/i.test(cmd)) {
                    const sel = window.getSelection();
                    const selectedText = sel ? sel.toString().substring(0, 300) : '';
                    window.postMessage({
                        type: 'TEXT_TRACK',
                        step: 'EXEC_CMD_' + cmd.toUpperCase(),
                        selectedText,
                        frames: parsePhantomStack(new Error().stack, 1),
                        time: Date.now()
                    }, '*');
                }
                return _origExecCmd(cmd, showUI, value);
            };
            document.execCommand._phantomHooked = true;
        }

        // ── C. Selection 变化监控 (用户选中文本) ──
        document.addEventListener('selectionchange', function() {
            const sel = window.getSelection();
            if (!sel || sel.isCollapsed) return;
            const text = sel.toString();
            if (text.length < 4) return; // 忽略误触
            window.postMessage({
                type: 'TEXT_TRACK',
                step: 'SELECTION_CHANGED',
                text: text.substring(0, 300),
                length: text.length,
                time: Date.now()
            }, '*');
        }, { passive: true });

        // ── D. MutationObserver — 监控动态插入的敏感文本节点 ──
        // 只关注包含 token/key/password 类关键词的文本内容
        const _SENSITIVE_TEXT_RE = /(?:token|access_token|api[_-]?key|secret|password|passwd|authorization|bearer\s+[a-zA-Z0-9._-]{20,})/i;
        const _textObserver = new MutationObserver(function(mutations) {
            mutations.forEach(function(m) {
                m.addedNodes.forEach(function(node) {
                    if (node.nodeType !== Node.TEXT_NODE) return;
                    const text = node.textContent || '';
                    if (text.length < 8 || !_SENSITIVE_TEXT_RE.test(text)) return;
                    window.postMessage({
                        type: 'TEXT_TRACK',
                        step: 'DOM_SENSITIVE_TEXT',
                        preview: text.substring(0, 200),
                        parentTag: node.parentElement ? node.parentElement.tagName : '',
                        time: Date.now()
                    }, '*');
                });
            });
        });
        // 延迟挂载，等 DOM ready
        if (document.body) {
            _textObserver.observe(document.body, { childList: true, subtree: true });
        } else {
            document.addEventListener('DOMContentLoaded', function() {
                _textObserver.observe(document.body, { childList: true, subtree: true });
            }, { once: true });
        }

    })();

    // ============================================================
    // 🖼️ 图片全链路追踪模块 (ImageChain Tracker)
    // 覆盖: Canvas toDataURL/toBlob/getImageData / drawImage
    //       Image src / createObjectURL / fetch blob
    // ============================================================
    (function hookImage() {

        // ── A. Canvas 2D — toDataURL / toBlob / getImageData ──
        const _origToDataURL = HTMLCanvasElement.prototype.toDataURL;
        if (!HTMLCanvasElement.prototype.toDataURL._phantomHooked) {
            HTMLCanvasElement.prototype.toDataURL = function(type, quality) {
                const result = _origToDataURL.call(this, type, quality);
                window.postMessage({
                    type: 'IMAGE_TRACK',
                    step: 'CANVAS_TO_DATA_URL',
                    mimeType: type || 'image/png',
                    width: this.width, height: this.height,
                    dataLength: result ? result.length : 0,
                    preview: result ? result.substring(0, 80) : '',
                    frames: parsePhantomStack(new Error().stack, 1),
                    time: Date.now()
                }, '*');
                return result;
            };
            HTMLCanvasElement.prototype.toDataURL._phantomHooked = true;
        }

        const _origToBlob = HTMLCanvasElement.prototype.toBlob;
        if (_origToBlob && !HTMLCanvasElement.prototype.toBlob._phantomHooked) {
            HTMLCanvasElement.prototype.toBlob = function(callback, type, quality) {
                const self = this;
                return _origToBlob.call(this, function(blob) {
                    window.postMessage({
                        type: 'IMAGE_TRACK',
                        step: 'CANVAS_TO_BLOB',
                        mimeType: (blob && blob.type) || type || 'image/png',
                        width: self.width, height: self.height,
                        blobSize: blob ? blob.size : 0,
                        frames: parsePhantomStack(new Error().stack, 1),
                        time: Date.now()
                    }, '*');
                    if (callback) callback(blob);
                }, type, quality);
            };
            HTMLCanvasElement.prototype.toBlob._phantomHooked = true;
        }

        // getImageData — 捕获像素数据读取（常见于指纹识别/水印）
        const _origGetImageData = CanvasRenderingContext2D.prototype.getImageData;
        if (!CanvasRenderingContext2D.prototype.getImageData._phantomHooked) {
            CanvasRenderingContext2D.prototype.getImageData = function(sx, sy, sw, sh) {
                const result = _origGetImageData.call(this, sx, sy, sw, sh);
                window.postMessage({
                    type: 'IMAGE_TRACK',
                    step: 'CANVAS_GET_IMAGE_DATA',
                    region: { x: sx, y: sy, w: sw, h: sh },
                    pixelCount: sw * sh,
                    canvasSize: { w: this.canvas ? this.canvas.width : 0, h: this.canvas ? this.canvas.height : 0 },
                    frames: parsePhantomStack(new Error().stack, 1),
                    time: Date.now()
                }, '*');
                return result;
            };
            CanvasRenderingContext2D.prototype.getImageData._phantomHooked = true;
        }

        // drawImage — 追踪图片资源被绘制到 Canvas
        const _origDrawImage = CanvasRenderingContext2D.prototype.drawImage;
        if (!CanvasRenderingContext2D.prototype.drawImage._phantomHooked) {
            CanvasRenderingContext2D.prototype.drawImage = function(image) {
                let src = '';
                if (image instanceof HTMLImageElement) src = image.src || image.currentSrc || '';
                else if (image instanceof HTMLVideoElement) src = image.currentSrc || image.src || '';
                else if (image instanceof HTMLCanvasElement) src = '[Canvas]';
                else if (image instanceof ImageBitmap) src = '[ImageBitmap]';
                if (src) {
                    window.postMessage({
                        type: 'IMAGE_TRACK',
                        step: 'CANVAS_DRAW_IMAGE',
                        src: src.length > 120 ? src.substring(0, 120) + '…' : src,
                        frames: parsePhantomStack(new Error().stack, 1),
                        time: Date.now()
                    }, '*');
                }
                return _origDrawImage.apply(this, arguments);
            };
            CanvasRenderingContext2D.prototype.drawImage._phantomHooked = true;
        }

        // ── B. URL.createObjectURL — 追踪 Blob/File 对象 URL 创建 ──
        const _origCreateObjectURL = URL.createObjectURL.bind(URL);
        if (!URL.createObjectURL._phantomHooked) {
            URL.createObjectURL = makeNative(function(obj) {
                const result = _origCreateObjectURL(obj);
                if (obj instanceof Blob || obj instanceof File) {
                    window.postMessage({
                        type: 'IMAGE_TRACK',
                        step: 'CREATE_OBJECT_URL',
                        mimeType: obj.type || '',
                        size: obj.size || 0,
                        isFile: obj instanceof File,
                        fileName: obj instanceof File ? obj.name : '',
                        objectUrl: result,
                        frames: parsePhantomStack(new Error().stack, 1),
                        time: Date.now()
                    }, '*');
                }
                return result;
            }, _origCreateObjectURL);
            URL.createObjectURL._phantomHooked = true;
        }

        // ── C. Image src 赋值拦截（动态图片加载追踪）──
        const _origImageSrcDesc = Object.getOwnPropertyDescriptor(HTMLImageElement.prototype, 'src');
        if (_origImageSrcDesc && _origImageSrcDesc.set && !_origImageSrcDesc.set._phantomHooked) {
            Object.defineProperty(HTMLImageElement.prototype, 'src', {
                set: function(val) {
                    if (val && typeof val === 'string' && val.length > 4 && !val.startsWith('data:')) {
                        window.postMessage({
                            type: 'IMAGE_TRACK',
                            step: 'IMAGE_SRC_SET',
                            src: val.length > 200 ? val.substring(0, 200) + '…' : val,
                            frames: parsePhantomStack(new Error().stack, 1),
                            time: Date.now()
                        }, '*');
                    }
                    _origImageSrcDesc.set.call(this, val);
                },
                get: function() { return _origImageSrcDesc.get.call(this); },
                configurable: true
            });
            _origImageSrcDesc.set._phantomHooked = true;
        }

    })();

    // ============================================================
    // 🔑 解密补全模块 (CryptoKey Tracker)
    // 补充 WebCrypto: importKey / deriveKey / generateKey / exportKey / unwrapKey
    // ============================================================
    (function hookCryptoKeys() {
        if (!window.crypto || !window.crypto.subtle) return;
        const _sub = window.crypto.subtle;

        // ── importKey ── 捕获密钥导入（密钥格式、用途）
        if (!_sub.importKey._phantomKeyHooked) {
            const _origImport = _sub.importKey.bind(_sub);
            _sub.importKey = function(format, keyData, algorithm, extractable, keyUsages) {
                return _origImport(format, keyData, algorithm, extractable, keyUsages).then(function(key) {
                    let rawPreview = '';
                    try {
                        if (format === 'raw' && keyData instanceof ArrayBuffer) {
                            rawPreview = Array.from(new Uint8Array(keyData).slice(0, 16))
                                .map(b => b.toString(16).padStart(2,'0')).join('');
                        } else if (format === 'jwk' && keyData && keyData.k) {
                            rawPreview = '[JWK k=' + String(keyData.k).substring(0, 40) + ']';
                        }
                    } catch(e) {}
                    window.postMessage({
                        type: 'DECRYPT_KEY_TRACK',
                        step: 'IMPORT_KEY',
                        format,
                        algo: typeof algorithm === 'string' ? algorithm : (algorithm && algorithm.name),
                        keyUsages: keyUsages || [],
                        extractable,
                        rawPreview,
                        keyType: key.type,
                        frames: parsePhantomStack(new Error().stack, 1),
                        time: Date.now()
                    }, '*');
                    return key;
                });
            };
            _sub.importKey._phantomKeyHooked = true;
        }

        // ── deriveKey ── 密钥派生（PBKDF2 / HKDF / ECDH）
        if (!_sub.deriveKey._phantomKeyHooked) {
            const _origDerive = _sub.deriveKey.bind(_sub);
            _sub.deriveKey = function(algorithm, baseKey, derivedKeyType, extractable, keyUsages) {
                return _origDerive(algorithm, baseKey, derivedKeyType, extractable, keyUsages).then(function(key) {
                    window.postMessage({
                        type: 'DECRYPT_KEY_TRACK',
                        step: 'DERIVE_KEY',
                        algo: typeof algorithm === 'string' ? algorithm : (algorithm && algorithm.name),
                        algoParams: algorithm && algorithm.salt ? {
                            saltLen: algorithm.salt.byteLength,
                            iterations: algorithm.iterations,
                            hash: algorithm.hash
                        } : {},
                        derivedType: typeof derivedKeyType === 'string' ? derivedKeyType : (derivedKeyType && derivedKeyType.name),
                        keyUsages: keyUsages || [],
                        extractable,
                        baseKeyType: baseKey ? baseKey.type : '',
                        frames: parsePhantomStack(new Error().stack, 1),
                        time: Date.now()
                    }, '*');
                    return key;
                });
            };
            _sub.deriveKey._phantomKeyHooked = true;
        }

        // ── deriveBits ── 比 deriveKey 更底层的派生
        if (_sub.deriveBits && !_sub.deriveBits._phantomKeyHooked) {
            const _origDerBits = _sub.deriveBits.bind(_sub);
            _sub.deriveBits = function(algorithm, baseKey, length) {
                return _origDerBits(algorithm, baseKey, length).then(function(bits) {
                    const hex = Array.from(new Uint8Array(bits).slice(0, 16))
                        .map(b => b.toString(16).padStart(2,'0')).join('');
                    window.postMessage({
                        type: 'DECRYPT_KEY_TRACK',
                        step: 'DERIVE_BITS',
                        algo: typeof algorithm === 'string' ? algorithm : (algorithm && algorithm.name),
                        length,
                        resultPreviewHex: hex,
                        frames: parsePhantomStack(new Error().stack, 1),
                        time: Date.now()
                    }, '*');
                    return bits;
                });
            };
            _sub.deriveBits._phantomKeyHooked = true;
        }

        // ── generateKey ── 密钥生成（RSA/EC/AES 等）
        if (!_sub.generateKey._phantomKeyHooked) {
            const _origGenKey = _sub.generateKey.bind(_sub);
            _sub.generateKey = function(algorithm, extractable, keyUsages) {
                return _origGenKey(algorithm, extractable, keyUsages).then(function(result) {
                    const algoName = typeof algorithm === 'string' ? algorithm : (algorithm && algorithm.name);
                    const keyInfo = result.privateKey
                        ? { type: 'CryptoKeyPair', publicType: result.publicKey.type, privateType: result.privateKey.type }
                        : { type: result.type, usages: result.usages };
                    window.postMessage({
                        type: 'DECRYPT_KEY_TRACK',
                        step: 'GENERATE_KEY',
                        algo: algoName,
                        modulusLength: algorithm && algorithm.modulusLength,
                        namedCurve: algorithm && algorithm.namedCurve,
                        keyLength: algorithm && algorithm.length,
                        extractable,
                        keyUsages: keyUsages || [],
                        keyInfo,
                        frames: parsePhantomStack(new Error().stack, 1),
                        time: Date.now()
                    }, '*');
                    return result;
                });
            };
            _sub.generateKey._phantomKeyHooked = true;
        }

        // ── exportKey ── 密钥导出（可以拿到原始密钥材料！）
        if (!_sub.exportKey._phantomKeyHooked) {
            const _origExport = _sub.exportKey.bind(_sub);
            _sub.exportKey = function(format, key) {
                return _origExport(format, key).then(function(exported) {
                    let rawPreview = '';
                    try {
                        if (exported instanceof ArrayBuffer) {
                            rawPreview = Array.from(new Uint8Array(exported).slice(0, 32))
                                .map(b => b.toString(16).padStart(2,'0')).join('');
                        } else if (typeof exported === 'object') {
                            rawPreview = JSON.stringify(exported).substring(0, 100);
                        }
                    } catch(e) {}
                    window.postMessage({
                        type: 'DECRYPT_KEY_TRACK',
                        step: 'EXPORT_KEY',
                        format,
                        keyType: key ? key.type : '',
                        algoName: key && key.algorithm ? key.algorithm.name : '',
                        keyUsages: key ? key.usages : [],
                        rawPreview,  // ⚠️ 可能包含完整密钥材料
                        frames: parsePhantomStack(new Error().stack, 1),
                        time: Date.now()
                    }, '*');
                    return exported;
                });
            };
            _sub.exportKey._phantomKeyHooked = true;
        }

        // ── unwrapKey ── 解包加密密钥（最隐蔽的密钥分发方式）
        if (_sub.unwrapKey && !_sub.unwrapKey._phantomKeyHooked) {
            const _origUnwrap = _sub.unwrapKey.bind(_sub);
            _sub.unwrapKey = function(format, wrappedKey, unwrappingKey, unwrapAlgo, unwrappedKeyAlgo, extractable, keyUsages) {
                return _origUnwrap(format, wrappedKey, unwrappingKey, unwrapAlgo, unwrappedKeyAlgo, extractable, keyUsages).then(function(key) {
                    const wrappedHex = wrappedKey instanceof ArrayBuffer
                        ? Array.from(new Uint8Array(wrappedKey).slice(0, 16)).map(b => b.toString(16).padStart(2,'0')).join('')
                        : '';
                    window.postMessage({
                        type: 'DECRYPT_KEY_TRACK',
                        step: 'UNWRAP_KEY',
                        format,
                        unwrapAlgo: typeof unwrapAlgo === 'string' ? unwrapAlgo : (unwrapAlgo && unwrapAlgo.name),
                        unwrappedKeyAlgo: typeof unwrappedKeyAlgo === 'string' ? unwrappedKeyAlgo : (unwrappedKeyAlgo && unwrappedKeyAlgo.name),
                        wrappedKeyLen: wrappedKey instanceof ArrayBuffer ? wrappedKey.byteLength : 0,
                        wrappedKeyPreviewHex: wrappedHex,
                        extractable,
                        keyUsages: keyUsages || [],
                        unwrappedKeyType: key ? key.type : '',
                        frames: parsePhantomStack(new Error().stack, 1),
                        time: Date.now()
                    }, '*');
                    return key;
                });
            };
            _sub.unwrapKey._phantomKeyHooked = true;
        }

    })();


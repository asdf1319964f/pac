(() => {
  'use strict';

  if (window.__GV_CONTROL_BAR_EXT_LOADED__) {
    return;
  }
  window.__GV_CONTROL_BAR_EXT_LOADED__ = true;

  const CONFIG = {
    HOLD_SEEK_INITIAL_DELAY: 400,
    HOLD_SEEK_REPEAT_INTERVAL: 100,
    HOLD_SEEK_ACCELERATION: 1.5,
    HOLD_SEEK_MAX_SPEED: 20,
    HOLD_SEEK_INITIAL_SPEED: 2,
    HINT_FADE_DELAY: 1200
  };

  const DEFAULT_SETTINGS = {
    enableControls: true,
    enableHoldSeek: true,
    enableHints: true,
    forceOverlay: true,
    seekStep: 10
  };

  const Utils = {
    clamp(value, min, max) {
      return Math.min(Math.max(value, min), max);
    },

    seekVideo(video, delta) {
      if (!(video instanceof HTMLVideoElement)) return video?.currentTime ?? 0;
      const duration = Number.isFinite(video.duration) ? video.duration : Number.MAX_SAFE_INTEGER;
      const target = Math.min(Math.max(video.currentTime + delta, 0), duration);
      video.currentTime = target;
      return target;
    },

    formatTime(seconds) {
      if (!Number.isFinite(seconds) || seconds < 0) return '--:--';
      const whole = Math.floor(seconds);
      const mins = Math.floor(whole / 60);
      const secs = whole % 60;
      return `${mins}:${secs.toString().padStart(2, '0')}`;
    },

    formatTimeLabel(current, duration) {
      const currentLabel = this.formatTime(current);
      if (!Number.isFinite(duration) || duration <= 0) return currentLabel;
      return `${currentLabel} / ${this.formatTime(duration)}`;
    },

    getPlayerContainer(video) {
      if (!(video instanceof HTMLElement)) return null;
      const selectors = [
        '.video-player',
        '.player',
        '.video-container',
        '.vp-player',
        '.bpx-player-container',
        '.bilibili-player',
        '.html5-video-player',
        '[data-player]',
        '[class*="player"]',
        '[class*="video"]',
        'div:has(> video)'
      ];
      for (const selector of selectors) {
        try {
          const container = video.closest(selector);
          if (container && container !== video && container instanceof HTMLElement) {
            return container;
          }
        } catch (e) {
          // 某些选择器可能不被支持，继续尝试下一个
          continue;
        }
      }
      return video.parentElement instanceof HTMLElement ? video.parentElement : video;
    }
  };

  class HoldSeekManager {
    constructor(getSettings) {
      this.getSettings = getSettings;
      this.repeatTimers = new Map();
      this.speeds = new Map();
    }

    startHoldSeek(video, direction, onProgress) {
      const settings = this.getSettings();
      if (!settings.enableHoldSeek) return;
      this.stopHoldSeek(video);

      let speed = CONFIG.HOLD_SEEK_INITIAL_SPEED;
      let lastTime = Date.now();

      const performSeek = () => {
        const now = Date.now();
        const deltaTime = Math.max((now - lastTime) / 1000, 0.01); // 防止除零或负值
        lastTime = now;
        const seekAmount = direction * speed * deltaTime;
        const target = Utils.seekVideo(video, seekAmount);
        speed = Math.min(speed * CONFIG.HOLD_SEEK_ACCELERATION, CONFIG.HOLD_SEEK_MAX_SPEED);
        this.speeds.set(video, speed);
        if (typeof onProgress === 'function') {
          onProgress(seekAmount, speed, target);
        }
      };

      const intervalId = setInterval(performSeek, CONFIG.HOLD_SEEK_REPEAT_INTERVAL);
      this.repeatTimers.set(video, intervalId);
      this.speeds.set(video, speed);
    }

    stopHoldSeek(video) {
      const timer = this.repeatTimers.get(video);
      if (timer) {
        clearInterval(timer);
        this.repeatTimers.delete(video);
      }
      this.speeds.delete(video);
    }

    getCurrentSpeed(video) {
      return this.speeds.get(video) || 0;
    }
  }

  class ControlManager {
    constructor(holdManager, getSettings) {
      this.holdManager = holdManager;
      this.getSettings = getSettings;
      this.bound = new Map();
      this.lastScanRoot = null;
    }

    updateSettings() {
      const settings = this.getSettings();

      if (!settings.enableControls) {
        for (const video of Array.from(this.bound.keys())) {
          this.teardown(video);
        }
        this.bound.clear();
        return;
      }

      for (const [video, entry] of this.bound.entries()) {
        if (!document.contains(video)) {
          this.teardown(video);
          this.bound.delete(video);
          continue;
        }

        if (entry.container) {
          if (settings.forceOverlay) {
            this.forceContainerStyle(entry.container);
          } else {
            this.restoreContainerStyle(entry.container);
          }
        }

        if (entry.buttons && entry.buttons.playButton) {
          this.updatePlayButtonIcon(entry.buttons.playButton, video);
        }
      }

      this.scan(this.lastScanRoot || document);
    }

    scan(root = document) {
      if (!root) return;
      const settings = this.getSettings();
      if (!settings.enableControls) return;

      if (root instanceof HTMLVideoElement) {
        this.ensure(root);
      }

      if (root && typeof root.querySelectorAll === 'function') {
        root.querySelectorAll('video').forEach((video) => this.ensure(video));
      }

      if (root instanceof Document || root === document) {
        this.lastScanRoot = document;
      }
    }

    ensure(video) {
      if (!(video instanceof HTMLVideoElement)) return;
      if (this.bound.has(video)) return;
      const settings = this.getSettings();
      if (!settings.enableControls) return;

      const container = Utils.getPlayerContainer(video);
      if (!(container instanceof HTMLElement)) return;

      const existingOverlay = container.querySelector('.tm-mobile-overlay');
      if (existingOverlay && existingOverlay.dataset.tmOverlayFor === 'control-bar') {
        existingOverlay.remove();
      }

      if (settings.forceOverlay) {
        this.forceContainerStyle(container);
      }

      const { overlay, hint, controlBar } = this.buildOverlay();
      overlay.dataset.tmOverlayFor = 'control-bar';

      container.appendChild(overlay);

      const cleanup = [];
      const pushCleanup = (fn) => {
        if (typeof fn === 'function') cleanup.push(fn);
      };

      const register = (target, type, handler, options) => {
        if (!target || typeof target.addEventListener !== 'function') return;
        target.addEventListener(type, handler, options);
        pushCleanup(() => {
          try {
            target.removeEventListener(type, handler, options);
          } catch (err) {
            // ignore
          }
        });
      };

      const visibility = this.createVisibilityController(controlBar);
      visibility.attachHoverHandlers(pushCleanup);
      visibility.hideImmediate();

      const showHint = this.makeHintHandler(hint);
      const buttons = this.createControlButtons(video, controlBar);

      this.setupSeekButton(video, buttons.backButton, -1, showHint, visibility, register);
      this.setupPlayButton(video, buttons.playButton, showHint, visibility, register);
      this.setupSeekButton(video, buttons.forwardButton, 1, showHint, visibility, register);

      const showControls = () => visibility.showTemporarily();
      ['pointerdown', 'pointermove', 'touchstart', 'click', 'keydown'].forEach((eventName) => {
        register(video, eventName, showControls, { passive: true, capture: false });
      });

      const updateIcon = () => this.updatePlayButtonIcon(buttons.playButton, video);
      register(video, 'play', updateIcon);
      register(video, 'pause', updateIcon);
      register(video, 'loadedmetadata', updateIcon);

      visibility.showTemporarily();

      const entry = {
        container,
        overlay,
        hint,
        controlBar,
        visibility,
        buttons,
        cleanup
      };

      this.bound.set(video, entry);
    }

    teardown(video) {
      const entry = this.bound.get(video);
      if (!entry) return;

      this.holdManager.stopHoldSeek(video);

      if (entry.cleanup) {
        for (const disposer of entry.cleanup) {
          try {
            disposer();
          } catch (err) {
            // ignore disposer errors
          }
        }
      }

      if (entry.overlay && entry.overlay.isConnected) {
        entry.overlay.remove();
      }

      if (entry.container) {
        this.restoreContainerStyle(entry.container);
      }

      this.bound.delete(video);
    }

    cleanupWithin(root) {
      if (!root || typeof root.querySelectorAll !== 'function') return;
      root.querySelectorAll('video').forEach((video) => {
        this.teardown(video);
        this.bound.delete(video);
      });
    }

    buildOverlay() {
      const overlay = document.createElement('div');
      overlay.className = 'tm-mobile-overlay';
      overlay.style.cssText = `
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        pointer-events: none;
        z-index: 9999;
      `;

      const hint = document.createElement('div');
      hint.className = 'tm-mobile-control-hint';
      hint.style.cssText = `
        position: absolute;
        bottom: 80px;
        left: 50%;
        transform: translateX(-50%);
        background: rgba(0, 0, 0, 0.7);
        color: white;
        padding: 8px 16px;
        border-radius: 24px;
        font-size: 14px;
        white-space: pre-line;
        text-align: center;
        pointer-events: none;
        opacity: 0;
        transition: opacity 0.2s ease;
        z-index: 10000;
        max-width: 80vw;
        backdrop-filter: blur(4px);
      `;

      const controlBar = document.createElement('div');
      controlBar.className = 'tm-mobile-control-bar';
      controlBar.style.cssText = `
        position: absolute;
        bottom: 20px;
        left: 50%;
        transform: translate(-50%, 0);
        display: flex;
        gap: 16px;
        padding: 8px 16px;
        background: rgba(0, 0, 0, 0.5);
        border-radius: 48px;
        backdrop-filter: blur(8px);
        pointer-events: auto;
        opacity: 0;
        transition: opacity 0.25s ease, transform 0.25s ease;
        z-index: 10001;
      `;

      overlay.append(hint, controlBar);
      return { overlay, hint, controlBar };
    }

    createControlButtons(video, container) {
      const backButton = this.createControlButton('⏪', '点击后退，按住持续快退');
      const playButton = this.createControlButton(video.paused ? '▶️' : '⏸', '播放 / 暂停');
      const forwardButton = this.createControlButton('⏩', '点击快进，按住持续快进');
      container.append(backButton, playButton, forwardButton);
      return { backButton, playButton, forwardButton };
    }

    createControlButton(label, title) {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'tm-mobile-control-button';
      button.textContent = label;
      button.style.cssText = `
        width: 56px;
        height: 56px;
        border-radius: 50%;
        border: none;
        background: rgba(255, 255, 255, 0.08);
        color: white;
        font-size: 24px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.15s ease;
        user-select: none;
        -webkit-tap-highlight-color: transparent;
        backdrop-filter: blur(4px);
        padding: 0;
        line-height: 1;
      `;
      if (title) {
        button.title = title;
        button.setAttribute('aria-label', title);
      }
      return button;
    }

    setButtonPressed(button, pressed) {
      if (!button) return;
      button.style.background = pressed ? 'rgba(255,255,255,0.22)' : 'rgba(255,255,255,0.08)';
      button.style.transform = pressed ? 'scale(0.95)' : 'scale(1)';
    }

    getSeekStep() {
      const settings = this.getSettings();
      if (settings && Number.isFinite(settings.seekStep) && settings.seekStep > 0) {
        return settings.seekStep;
      }
      return DEFAULT_SETTINGS.seekStep;
    }

    setupPlayButton(video, button, showHint, visibility, register) {
      const handleClick = (event) => {
        event.preventDefault();
        event.stopPropagation();
        visibility.showTemporarily();
        this.togglePlayback(video, showHint);
      };

      register(button, 'click', handleClick, false);

      register(button, 'pointerdown', (event) => {
        if (event.pointerType === 'mouse' && event.button !== 0) return;
        event.stopPropagation();
        visibility.showTemporarily();
        this.setButtonPressed(button, true);
      });

      const reset = () => this.setButtonPressed(button, false);
      register(button, 'pointerup', reset, false);
      register(button, 'pointerleave', reset, false);
      register(button, 'pointercancel', reset, false);
    }

    setupSeekButton(video, button, direction, showHint, visibility, register) {
      const state = {
        pointerId: null,
        holdTimer: null,
        holding: false
      };

      const clearHoldTimer = () => {
        if (state.holdTimer) {
          clearTimeout(state.holdTimer);
          state.holdTimer = null;
        }
      };

      const stopHold = (withMessage) => {
        const wasHolding = state.holding;
        const peakSpeed = this.holdManager.getCurrentSpeed(video);
        this.holdManager.stopHoldSeek(video);
        state.holding = false;

        if (withMessage && wasHolding && typeof showHint === 'function') {
          const label = Utils.formatTimeLabel(video.currentTime, video.duration);
          const suffix = peakSpeed > 0 ? `\n最高速度: ${peakSpeed.toFixed(1)}x` : '';
          const action = direction > 0 ? '快进结束' : '快退结束';
          showHint(`✅ ${action}${suffix}\n${label}`);
          visibility.showTemporarily();
        }
      };

      const startHold = () => {
        const settings = this.getSettings();
        if (!settings || !settings.enableHoldSeek) return;
        state.holding = true;
        const action = direction > 0 ? '快进' : '快退';
        const icon = direction > 0 ? '⏩' : '⏪';
        if (typeof showHint === 'function') {
          showHint(`${icon} ${action}中...\n${Utils.formatTimeLabel(video.currentTime, video.duration)}`);
        }
        visibility.showTemporarily();
        this.holdManager.startHoldSeek(video, direction, (seekAmount, speed, target) => {
          if (typeof showHint === 'function') {
            const label = Utils.formatTimeLabel(target, video.duration);
            showHint(`${icon} ${action} ${speed.toFixed(1)}x\n${label}`);
          }
        });
      };

      const finish = (event, canceled) => {
        if (state.pointerId === null || (event && event.pointerId !== state.pointerId)) return;

        clearHoldTimer();

        if (!state.holding && !canceled) {
          const step = this.getSeekStep();
          const delta = direction * step;
          const target = Utils.seekVideo(video, delta);
          const label = Utils.formatTimeLabel(target, video.duration);
          const icon = direction > 0 ? '▶▶' : '◀◀';
          const action = direction > 0 ? '快进' : '快退';
          if (typeof showHint === 'function') {
            showHint(`${icon} ${action} ${Math.abs(delta)}s\n${label}`);
          }
          visibility.showTemporarily();
        }

        stopHold(!canceled);
        this.setButtonPressed(button, false);

        if (event && event.pointerId) {
          try {
            button.releasePointerCapture(event.pointerId);
          } catch (err) {
            // ignore
          }
        }

        state.pointerId = null;
      };

      register(button, 'pointerdown', (event) => {
        if (event.pointerType === 'mouse' && event.button !== 0) return;
        if (state.pointerId !== null) return;

        event.preventDefault();
        event.stopPropagation();

        state.pointerId = event.pointerId;
        this.setButtonPressed(button, true);
        visibility.showTemporarily();

        clearHoldTimer();
        const settings = this.getSettings();
        if (settings && settings.enableHoldSeek) {
          state.holdTimer = setTimeout(() => {
            state.holdTimer = null;
            startHold();
          }, CONFIG.HOLD_SEEK_INITIAL_DELAY);
        }

        try {
          button.setPointerCapture(event.pointerId);
        } catch (err) {
          // ignore
        }
      }, { passive: false });

      register(button, 'pointerup', (event) => finish(event, false), { passive: false });
      register(button, 'pointercancel', (event) => finish(event, true), { passive: false });
      register(button, 'pointerleave', (event) => {
        if (state.pointerId !== null && event.pointerId === state.pointerId) {
          finish(event, true);
        }
      }, { passive: false });
    }

    togglePlayback(video, showHint) {
      if (video.paused) {
        const result = video.play();
        if (result && typeof result.catch === 'function') {
          result.then(() => {
            this.showPlaybackHint(video, showHint, 'play');
          }).catch((err) => {
            console.debug('Video play failed:', err);
            // 尝试通过模拟点击来触发播放
            video.dispatchEvent(new MouseEvent('click', { bubbles: true }));
          });
        } else {
          this.showPlaybackHint(video, showHint, 'play');
        }
      } else {
        video.pause();
        this.showPlaybackHint(video, showHint, 'pause');
      }
    }

    showPlaybackHint(video, showHint, state) {
      if (!showHint || typeof showHint !== 'function') return;
      const label = Utils.formatTimeLabel(video.currentTime, video.duration);
      if (state === 'play') {
        showHint(`▶️ 播放\n${label}`);
      } else {
        showHint(`⏸ 暂停\n${label}`);
      }
    }

    updatePlayButtonIcon(button, video) {
      if (!button) return;
      button.textContent = video.paused ? '▶️' : '⏸';
    }

    makeHintHandler(hint) {
      let hideTimer = null;
      return (text) => {
        const settings = this.getSettings();
        if (!settings || !settings.enableHints) return;
        if (!hint) return;
        
        hint.textContent = text;
        hint.style.opacity = '1';
        clearTimeout(hideTimer);
        hideTimer = setTimeout(() => {
          hint.style.opacity = '0';
        }, CONFIG.HINT_FADE_DELAY);
      };
    }

    createVisibilityController(controlBar) {
      let hideTimer = null;
      const SHOW_DURATION = 2500;

      const show = () => {
        controlBar.style.opacity = '1';
        controlBar.style.transform = 'translate(-50%, 0)';
      };

      const hide = () => {
        controlBar.style.opacity = '0';
        controlBar.style.transform = 'translate(-50%, 12px)';
      };

      const hideWithTransition = () => {
        clearTimeout(hideTimer);
        hideTimer = setTimeout(hide, SHOW_DURATION);
      };

      return {
        showTemporarily() {
          clearTimeout(hideTimer);
          show();
          hideTimer = setTimeout(hide, SHOW_DURATION);
        },
        hideImmediate() {
          clearTimeout(hideTimer);
          const previousTransition = controlBar.style.transition;
          controlBar.style.transition = 'none';
          hide();
          requestAnimationFrame(() => {
            controlBar.style.transition = previousTransition || 'opacity 0.25s ease, transform 0.25s ease';
          });
        },
        attachHoverHandlers(pushCleanup) {
          const onEnter = () => {
            clearTimeout(hideTimer);
            show();
          };
          const onLeave = () => hideWithTransition();
          controlBar.addEventListener('pointerenter', onEnter);
          controlBar.addEventListener('pointerleave', onLeave);
          pushCleanup(() => controlBar.removeEventListener('pointerenter', onEnter));
          pushCleanup(() => controlBar.removeEventListener('pointerleave', onLeave));
        }
      };
    }

    forceContainerStyle(container) {
      if (!container || !(container instanceof HTMLElement)) return;
      if (!container.dataset.tmControlOriginalPosition) {
        container.dataset.tmControlOriginalPosition = container.style.position || '';
      }
      if (getComputedStyle(container).position === 'static') {
        container.style.position = 'relative';
      }
    }

    restoreContainerStyle(container) {
      if (!container || !(container instanceof HTMLElement)) return;
      const original = container.dataset.tmControlOriginalPosition;
      if (original !== undefined) {
        container.style.position = original;
        delete container.dataset.tmControlOriginalPosition;
      }
    }
  }

  let currentSettings = { ...DEFAULT_SETTINGS };
  const holdManager = new HoldSeekManager(() => currentSettings);
  const controlManager = new ControlManager(holdManager, () => currentSettings);

  function observeDocument() {
    controlManager.scan(document);

    const observer = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType !== 1) return;
          if (node instanceof HTMLVideoElement) {
            controlManager.ensure(node);
          } else if (node.nodeType === 1) {
            controlManager.scan(node);
          }
        });

        mutation.removedNodes.forEach((node) => {
          if (node.nodeType !== 1) return;
          if (node instanceof HTMLVideoElement) {
            controlManager.teardown(node);
            controlManager.bound.delete(node);
          } else if (node.nodeType === 1) {
            controlManager.cleanupWithin(node);
          }
        });
      }
    });

    observer.observe(document.documentElement, {
      childList: true,
      subtree: true
    });
  }

  function applySettings(newValues) {
    currentSettings = { ...currentSettings, ...newValues };
    controlManager.updateSettings();
  }

  // 检查是否在扩展环境中
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get(DEFAULT_SETTINGS, (stored) => {
      if (chrome.runtime.lastError) {
        console.debug('Failed to load settings:', chrome.runtime.lastError);
        applySettings(DEFAULT_SETTINGS);
      } else {
        applySettings(stored || DEFAULT_SETTINGS);
      }
      observeDocument();
    });

    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local') return;
      const updates = {};
      for (const [key, { newValue }] of Object.entries(changes)) {
        if (key in DEFAULT_SETTINGS) {
          updates[key] = newValue;
        }
      }
      if (Object.keys(updates).length > 0) {
        applySettings(updates);
      }
    });
  } else {
    // 非扩展环境，使用默认设置
    console.debug('Running in non-extension environment');
    applySettings(DEFAULT_SETTINGS);
    observeDocument();
  }

})();
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const settings = await getSettings();
  switch (info.menuItemId) {
    case MENU_IDS.enableControls:
      chrome.storage.local.set({ enableControls: !settings.enableControls });
      break;
    case MENU_IDS.enableHoldSeek:
      chrome.storage.local.set({ enableHoldSeek: !settings.enableHoldSeek });
      break;
    case MENU_IDS.enableHints:
      chrome.storage.local.set({ enableHints: !settings.enableHints });
      break;
    case MENU_IDS.forceOverlay:
      chrome.storage.local.set({ forceOverlay: !settings.forceOverlay });
      break;
    case MENU_IDS.setSeekStep:
      promptSeekStep(settings.seekStep, tab);
      break;
  }
});

function promptSeekStep(currentStep, tab) {
  const targetTabsPromise = tab?.id != null
    ? Promise.resolve([tab])
    : chrome.tabs.query({ active: true, currentWindow: true });

  targetTabsPromise.then((tabs) => {
    const target = tabs && tabs[0];
    if (!target || target.id == null) return;

    chrome.scripting.executeScript({
      target: { tabId: target.id, frameIds: target.frameId != null ? [target.frameId] : undefined },
      func: (current) => {
        const value = window.prompt('请输入每次快进/快退的秒数 (1 - 120)', String(current));
        if (value === null) return null;
        const next = Number(value);
        if (!Number.isFinite(next) || next < 1 || next > 120) {
          alert('请输入 1-120 范围内的有效数字');
          return null;
        }
        return Math.round(next);
      },
      args: [currentStep]
    }, (results) => {
      const result = results && results[0];
      if (chrome.runtime.lastError || !result || result.result == null) {
        return;
      }
      chrome.storage.local.set({ seekStep: result.result });
    });
  });
}

function buildMenus(settings) {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: MENU_IDS.enableControls,
      title: `控制栏：${settings.enableControls ? '开启' : '关闭'}`,
      contexts: ['page', 'frame']
    });
    chrome.contextMenus.create({
      id: MENU_IDS.enableHoldSeek,
      title: `长按加速：${settings.enableHoldSeek ? '开启' : '关闭'}`,
      contexts: ['page', 'frame']
    });
    chrome.contextMenus.create({
      id: MENU_IDS.enableHints,
      title: `提示信息：${settings.enableHints ? '开启' : '关闭'}`,
      contexts: ['page', 'frame']
    });
    chrome.contextMenus.create({
      id: MENU_IDS.forceOverlay,
      title: `置顶浮层：${settings.forceOverlay ? '开启' : '关闭'}`,
      contexts: ['page', 'frame']
    });
    chrome.contextMenus.create({
      id: MENU_IDS.setSeekStep,
      title: `设置快进/快退秒数（当前 ${settings.seekStep}s）`,
      contexts: ['page', 'frame']
    });
  });
}
